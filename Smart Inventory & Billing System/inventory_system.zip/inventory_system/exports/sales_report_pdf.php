<?php
// exports/sales_report_pdf.php

session_start();
require_once __DIR__ . '/../config/db.php';

// Get Date Range
$date_from = isset($_GET['date_from']) ? $_GET['date_from'] : date('Y-m-01');
$date_to   = isset($_GET['date_to']) ? $_GET['date_to'] : date('Y-m-d');

// Get Sales Data
$sales_query = mysqli_query($conn, 
    "SELECT 
        COUNT(*) as total_bills,
        COALESCE(SUM(total_amount), 0) as total_revenue
     FROM bills 
     WHERE bill_date BETWEEN '$date_from' AND '$date_to'"
);
$sales_data = mysqli_fetch_assoc($sales_query);

// Top Selling Products
$top_products = mysqli_query($conn, 
    "SELECT 
        p.product_name,
        COALESCE(SUM(bi.quantity), 0) as total_sold,
        COALESCE(SUM(bi.quantity * bi.price), 0) as revenue
     FROM bill_items bi
     LEFT JOIN products p ON bi.product_id = p.id
     LEFT JOIN bills b ON bi.bill_id = b.id
     WHERE b.bill_date BETWEEN '$date_from' AND '$date_to'
     GROUP BY bi.product_id
     ORDER BY total_sold DESC
     LIMIT 10"
);

// Payment Mode Breakdown
$payment_query = mysqli_query($conn, 
    "SELECT 
        payment_mode,
        COUNT(*) as count,
        COALESCE(SUM(total_amount), 0) as total
     FROM bills 
     WHERE bill_date BETWEEN '$date_from' AND '$date_to'
     GROUP BY payment_mode"
);

// Recent Bills
$recent_bills = mysqli_query($conn, 
    "SELECT * FROM bills 
     WHERE bill_date BETWEEN '$date_from' AND '$date_to'
     ORDER BY id DESC 
     LIMIT 20"
);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Sales Report - <?= date('d M Y', strtotime($date_from)) ?> to <?= date('d M Y', strtotime($date_to)) ?></title>
    <style>
        @page { 
            size: A4; 
            margin: 15mm; 
        }
        
        body {
            font-family: 'Arial', sans-serif;
            font-size: 12px;
            line-height: 1.4;
            color: #333;
            margin: 0;
            padding: 20px;
        }
        
        .header {
            text-align: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 3px solid #6366f1;
        }
        
        .header h1 {
            margin: 0;
            font-size: 28px;
            color: #0f172a;
        }
        
        .header h2 {
            margin: 5px 0 0;
            font-size: 18px;
            color: #6366f1;
            font-weight: normal;
        }
        
        .header .period {
            margin-top: 10px;
            font-size: 13px;
            color: #64748b;
        }
        
        .summary-cards {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 15px;
            margin-bottom: 30px;
        }
        
        .summary-card {
            background: #f8fafc;
            padding: 15px;
            border-radius: 8px;
            border-left: 4px solid #6366f1;
        }
        
        .summary-card h3 {
            margin: 0 0 5px;
            font-size: 24px;
            color: #0f172a;
        }
        
        .summary-card p {
            margin: 0;
            font-size: 11px;
            color: #64748b;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .section {
            margin-bottom: 25px;
        }
        
        .section-title {
            font-size: 16px;
            font-weight: bold;
            color: #0f172a;
            margin-bottom: 10px;
            padding-bottom: 5px;
            border-bottom: 2px solid #e2e8f0;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        
        table thead {
            background: #f1f5f9;
        }
        
        table th {
            padding: 10px;
            text-align: left;
            font-size: 11px;
            font-weight: bold;
            color: #475569;
            border-bottom: 2px solid #cbd5e1;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        table td {
            padding: 8px 10px;
            border-bottom: 1px solid #e2e8f0;
            font-size: 12px;
        }
        
        table tbody tr:hover {
            background: #f8fafc;
        }
        
        .text-right {
            text-align: right;
        }
        
        .text-center {
            text-align: center;
        }
        
        .badge {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 12px;
            font-size: 10px;
            font-weight: bold;
        }
        
        .badge-success {
            background: #d1fae5;
            color: #065f46;
        }
        
        .footer {
            margin-top: 40px;
            padding-top: 20px;
            border-top: 2px solid #e2e8f0;
            text-align: center;
            font-size: 11px;
            color: #94a3b8;
        }
        
        @media print {
            body {
                padding: 0;
            }
            
            .no-print {
                display: none !important;
            }
        }
    </style>
</head>
<body>

<!-- Print Button -->
<div class="no-print" style="text-align:right; margin-bottom:20px;">
    <button onclick="window.print()" style="padding:10px 20px; background:#6366f1; color:white; border:none; border-radius:8px; cursor:pointer; font-size:14px;">
        🖨️ Print / Save as PDF
    </button>
    <button onclick="window.close()" style="padding:10px 20px; background:#64748b; color:white; border:none; border-radius:8px; cursor:pointer; font-size:14px; margin-left:10px;">
        ✖️ Close
    </button>
</div>

<!-- Header -->
<div class="header">
    <h1>📊 Sales Report</h1>
    <h2>Smart Inventory & Billing System</h2>
    <div class="period">
        <strong>Report Period:</strong> 
        <?= date('d M Y', strtotime($date_from)) ?> to <?= date('d M Y', strtotime($date_to)) ?>
    </div>
    <div class="period">
        <strong>Generated On:</strong> <?= date('d M Y, h:i A') ?>
    </div>
</div>

<!-- Summary Cards -->
<div class="summary-cards">
    <div class="summary-card">
        <h3><?= $sales_data['total_bills'] ?></h3>
        <p>Total Bills</p>
    </div>
    <div class="summary-card">
        <h3>₹<?= number_format($sales_data['total_revenue'], 2) ?></h3>
        <p>Total Revenue</p>
    </div>
    <div class="summary-card">
        <h3>₹<?= $sales_data['total_bills'] > 0 ? number_format($sales_data['total_revenue'] / $sales_data['total_bills'], 2) : '0.00' ?></h3>
        <p>Average Bill Value</p>
    </div>
</div>

<!-- Top Selling Products -->
<div class="section">
    <div class="section-title">🏆 Top Selling Products</div>
    <table>
        <thead>
            <tr>
                <th width="10%">Rank</th>
                <th width="50%">Product Name</th>
                <th width="20%" class="text-right">Quantity Sold</th>
                <th width="20%" class="text-right">Revenue</th>
            </tr>
        </thead>
        <tbody>
            <?php if (mysqli_num_rows($top_products) > 0) : ?>
                <?php $rank = 1; ?>
                <?php while ($product = mysqli_fetch_assoc($top_products)) : ?>
                    <tr>
                        <td class="text-center"><strong><?= $rank++ ?></strong></td>
                        <td><?= htmlspecialchars($product['product_name']) ?></td>
                        <td class="text-right"><strong><?= $product['total_sold'] ?></strong></td>
                        <td class="text-right"><strong>₹<?= number_format($product['revenue'], 2) ?></strong></td>
                    </tr>
                <?php endwhile; ?>
            <?php else : ?>
                <tr>
                    <td colspan="4" class="text-center" style="padding:20px; color:#94a3b8;">
                        No sales data available for this period
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<!-- Payment Mode Breakdown -->
<div class="section">
    <div class="section-title">💳 Payment Mode Breakdown</div>
    <table>
        <thead>
            <tr>
                <th width="40%">Payment Mode</th>
                <th width="30%" class="text-center">Number of Bills</th>
                <th width="30%" class="text-right">Total Amount</th>
            </tr>
        </thead>
        <tbody>
            <?php if (mysqli_num_rows($payment_query) > 0) : ?>
                <?php while ($payment = mysqli_fetch_assoc($payment_query)) : ?>
                    <tr>
                        <td><strong><?= $payment['payment_mode'] ?></strong></td>
                        <td class="text-center"><?= $payment['count'] ?></td>
                        <td class="text-right"><strong>₹<?= number_format($payment['total'], 2) ?></strong></td>
                    </tr>
                <?php endwhile; ?>
            <?php else : ?>
                <tr>
                    <td colspan="3" class="text-center" style="padding:20px; color:#94a3b8;">
                        No payment data available
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<!-- Recent Bills -->
<div class="section">
    <div class="section-title">📋 Recent Bills (Last 20)</div>
    <table>
        <thead>
            <tr>
                <th width="10%">Bill ID</th>
                <th width="30%">Customer Name</th>
                <th width="20%">Payment Mode</th>
                <th width="20%" class="text-right">Amount</th>
                <th width="20%">Date</th>
            </tr>
        </thead>
        <tbody>
            <?php if (mysqli_num_rows($recent_bills) > 0) : ?>
                <?php while ($bill = mysqli_fetch_assoc($recent_bills)) : ?>
                    <tr>
                        <td><strong>#<?= str_pad($bill['id'], 4, '0', STR_PAD_LEFT) ?></strong></td>
                        <td><?= htmlspecialchars($bill['customer_name']) ?></td>
                        <td>
                            <span class="badge badge-success"><?= htmlspecialchars($bill['payment_mode']) ?></span>
                        </td>
                        <td class="text-right"><strong>₹<?= number_format($bill['total_amount'], 2) ?></strong></td>
                        <td><?= date('d M Y', strtotime($bill['bill_date'])) ?></td>
                    </tr>
                <?php endwhile; ?>
            <?php else : ?>
                <tr>
                    <td colspan="5" class="text-center" style="padding:20px; color:#94a3b8;">
                        No bills found in this period
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<!-- Footer -->
<div class="footer">
    <p><strong>Smart Inventory & Billing System</strong></p>
    <p>This is a computer-generated report. No signature required.</p>
    <p>© <?= date('Y') ?> All Rights Reserved</p>
</div>

<script>
// Auto-print when opened (optional)
// window.onload = function() { window.print(); }
</script>

</body>
</html>