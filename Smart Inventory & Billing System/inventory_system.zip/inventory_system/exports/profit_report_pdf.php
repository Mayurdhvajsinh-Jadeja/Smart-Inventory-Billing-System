<?php
// exports/profit_report_pdf.php

session_start();
require_once __DIR__ . '/../config/db.php';

// Get Date Range
$date_from = isset($_GET['date_from']) ? $_GET['date_from'] : date('Y-m-01');
$date_to   = isset($_GET['date_to']) ? $_GET['date_to'] : date('Y-m-d');

// Total Sales & Profit
$sales_query = mysqli_query($conn, 
    "SELECT 
        COALESCE(SUM(bi.quantity * bi.price), 0) as total_revenue,
        COALESCE(SUM(bi.quantity * p.cost_price), 0) as total_cost
     FROM bill_items bi
     LEFT JOIN products p ON bi.product_id = p.id
     LEFT JOIN bills b ON bi.bill_id = b.id
     WHERE b.bill_date BETWEEN '$date_from' AND '$date_to'"
);
$sales_data = mysqli_fetch_assoc($sales_query);

$total_revenue = $sales_data['total_revenue'];
$total_cost = $sales_data['total_cost'];
$total_profit = $total_revenue - $total_cost;
$profit_margin = $total_revenue > 0 ? ($total_profit / $total_revenue) * 100 : 0;

// Product-wise Profit
$product_profit = mysqli_query($conn, 
    "SELECT 
        p.product_name,
        p.cost_price,
        p.price as selling_price,
        (p.price - p.cost_price) as profit_per_unit,
        COALESCE(SUM(bi.quantity), 0) as total_sold,
        COALESCE(SUM(bi.quantity * bi.price), 0) as revenue,
        COALESCE(SUM(bi.quantity * p.cost_price), 0) as cost,
        COALESCE(SUM(bi.quantity * (bi.price - p.cost_price)), 0) as total_profit
     FROM products p
     LEFT JOIN bill_items bi ON p.id = bi.product_id
     LEFT JOIN bills b ON bi.bill_id = b.id
     WHERE b.bill_date BETWEEN '$date_from' AND '$date_to'
     GROUP BY p.id
     HAVING total_sold > 0
     ORDER BY total_profit DESC
     LIMIT 15"
);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Profit Analysis Report</title>
    <style>
        @page { 
            size: A4; 
            margin: 15mm; 
        }
        
        body {
            font-family: 'Arial', sans-serif;
            font-size: 11px;
            line-height: 1.4;
            color: #333;
            margin: 0;
            padding: 20px;
        }
        
        .header {
            text-align: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 3px solid #10b981;
        }
        
        .header h1 {
            margin: 0;
            font-size: 26px;
            color: #0f172a;
        }
        
        .header h2 {
            margin: 5px 0 0;
            font-size: 16px;
            color: #10b981;
            font-weight: normal;
        }
        
        .summary-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 12px;
            margin-bottom: 25px;
        }
        
        .summary-box {
            background: #f8fafc;
            padding: 12px;
            border-radius: 6px;
            border-left: 4px solid #10b981;
            text-align: center;
        }
        
        .summary-box h3 {
            margin: 0 0 5px;
            font-size: 20px;
            color: #0f172a;
        }
        
        .summary-box p {
            margin: 0;
            font-size: 10px;
            color: #64748b;
            text-transform: uppercase;
        }
        
        .formula-box {
            background: #ecfdf5;
            border: 1px solid #10b981;
            border-radius: 6px;
            padding: 12px;
            margin-bottom: 20px;
        }
        
        .formula-box strong {
            color: #065f46;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        
        table thead {
            background: #f1f5f9;
        }
        
        table th {
            padding: 8px;
            text-align: left;
            font-size: 10px;
            font-weight: bold;
            color: #475569;
            border-bottom: 2px solid #cbd5e1;
            text-transform: uppercase;
        }
        
        table td {
            padding: 6px 8px;
            border-bottom: 1px solid #e2e8f0;
            font-size: 11px;
        }
        
        .text-right {
            text-align: right;
        }
        
        .text-center {
            text-align: center;
        }
        
        .section-title {
            font-size: 14px;
            font-weight: bold;
            color: #0f172a;
            margin: 20px 0 10px;
            padding-bottom: 5px;
            border-bottom: 2px solid #e2e8f0;
        }
        
        .footer {
            margin-top: 30px;
            padding-top: 15px;
            border-top: 2px solid #e2e8f0;
            text-align: center;
            font-size: 10px;
            color: #94a3b8;
        }
        
        @media print {
            .no-print { display: none !important; }
        }
    </style>
</head>
<body>

<!-- Print Button -->
<div class="no-print" style="text-align:right; margin-bottom:20px;">
    <button onclick="window.print()" style="padding:10px 20px; background:#10b981; color:white; border:none; border-radius:8px; cursor:pointer;">
        🖨️ Print / Save as PDF
    </button>
    <button onclick="window.close()" style="padding:10px 20px; background:#64748b; color:white; border:none; border-radius:8px; cursor:pointer; margin-left:10px;">
        ✖️ Close
    </button>
</div>

<!-- Header -->
<div class="header">
    <h1>💰 Profit Analysis Report</h1>
    <h2>Smart Inventory & Billing System</h2>
    <div style="margin-top:10px; font-size:12px; color:#64748b;">
        <strong>Report Period:</strong> 
        <?= date('d M Y', strtotime($date_from)) ?> to <?= date('d M Y', strtotime($date_to)) ?>
        &nbsp;|&nbsp;
        <strong>Generated:</strong> <?= date('d M Y, h:i A') ?>
    </div>
</div>

<!-- Summary Grid -->
<div class="summary-grid">
    <div class="summary-box">
        <h3>₹<?= number_format($total_revenue, 0) ?></h3>
        <p>Total Revenue</p>
    </div>
    <div class="summary-box">
        <h3>₹<?= number_format($total_cost, 0) ?></h3>
        <p>Total Cost</p>
    </div>
    <div class="summary-box" style="border-left-color: #10b981;">
        <h3 style="color:#10b981;">₹<?= number_format($total_profit, 0) ?></h3>
        <p>Net Profit</p>
    </div>
    <div class="summary-box" style="border-left-color: #f59e0b;">
        <h3 style="color:#f59e0b;"><?= number_format($profit_margin, 1) ?>%</h3>
        <p>Profit Margin</p>
    </div>
</div>

<!-- Formula -->
<div class="formula-box">
    <strong>Profit Calculation Formula:</strong>
    Net Profit = Total Revenue - Total Cost | 
    Profit Margin % = (Net Profit ÷ Total Revenue) × 100
</div>

<!-- Product-wise Profit Table -->
<div class="section-title">Product-wise Profit Analysis</div>
<table>
    <thead>
        <tr>
            <th width="5%">#</th>
            <th width="25%">Product</th>
            <th width="10%" class="text-right">Cost/Unit</th>
            <th width="10%" class="text-right">Sell/Unit</th>
            <th width="10%" class="text-right">Profit/Unit</th>
            <th width="8%" class="text-center">Qty</th>
            <th width="12%" class="text-right">Revenue</th>
            <th width="10%" class="text-right">Cost</th>
            <th width="10%" class="text-right">Profit</th>
        </tr>
    </thead>
    <tbody>
        <?php if (mysqli_num_rows($product_profit) > 0) : ?>
            <?php $rank = 1; ?>
            <?php while ($product = mysqli_fetch_assoc($product_profit)) : ?>
                <tr>
                    <td class="text-center"><strong><?= $rank++ ?></strong></td>
                    <td><?= htmlspecialchars($product['product_name']) ?></td>
                    <td class="text-right">₹<?= number_format($product['cost_price'], 2) ?></td>
                    <td class="text-right">₹<?= number_format($product['selling_price'], 2) ?></td>
                    <td class="text-right" style="color:#10b981; font-weight:bold;">
                        ₹<?= number_format($product['profit_per_unit'], 2) ?>
                    </td>
                    <td class="text-center"><?= $product['total_sold'] ?></td>
                    <td class="text-right">₹<?= number_format($product['revenue'], 2) ?></td>
                    <td class="text-right" style="color:#ef4444;">₹<?= number_format($product['cost'], 2) ?></td>
                    <td class="text-right" style="color:#10b981; font-weight:bold;">
                        ₹<?= number_format($product['total_profit'], 2) ?>
                    </td>
                </tr>
            <?php endwhile; ?>
        <?php else : ?>
            <tr>
                <td colspan="9" class="text-center" style="padding:20px; color:#94a3b8;">
                    No sales data available for this period
                </td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>

<!-- Footer -->
<div class="footer">
    <p><strong>Smart Inventory & Billing System</strong></p>
    <p>This is a computer-generated profit analysis report.</p>
    <p>© <?= date('Y') ?> All Rights Reserved</p>
</div>

</body>
</html>