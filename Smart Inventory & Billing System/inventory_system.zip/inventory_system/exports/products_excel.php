<?php
// exports/products_excel.php

session_start();
require_once __DIR__ . '/../config/db.php';

// Get all products with profit calculation
$products = mysqli_query($conn, 
    "SELECT 
        p.*,
        c.category_name,
        (p.price - p.cost_price) as profit_amount,
        CASE 
            WHEN p.cost_price > 0 THEN ((p.price - p.cost_price) / p.cost_price * 100)
            ELSE 0 
        END as profit_margin
     FROM products p 
     LEFT JOIN categories c ON p.category_id = c.id 
     ORDER BY p.id"
);

// Set headers for Excel download
header('Content-Type: application/vnd.ms-excel');
header('Content-Disposition: attachment; filename="Products_List_' . date('Y-m-d') . '.xls"');
header('Cache-Control: max-age=0');
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }
        th, td {
            border: 1px solid #000;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #4472C4;
            color: white;
            font-weight: bold;
        }
        .text-right {
            text-align: right;
        }
        .text-center {
            text-align: center;
        }
    </style>
</head>
<body>

<h2>Products Inventory List</h2>
<p><strong>Generated On:</strong> <?= date('d M Y, h:i A') ?></p>
<br>

<table>
    <thead>
        <tr>
            <th>Sr. No.</th>
            <th>Product Name</th>
            <th>Category</th>
            <th>Cost Price (₹)</th>
            <th>Selling Price (₹)</th>
            <th>Profit (₹)</th>
            <th>Profit Margin (%)</th>
            <th>Stock Quantity</th>
            <th>Stock Status</th>
        </tr>
    </thead>
    <tbody>
        <?php 
        $sr = 1;
        $total_stock_value = 0;
        while ($product = mysqli_fetch_assoc($products)) : 
            $stock_value = $product['cost_price'] * $product['quantity'];
            $total_stock_value += $stock_value;
            
            // Stock status
            if ($product['quantity'] == 0) {
                $status = 'Out of Stock';
            } elseif ($product['quantity'] < 5) {
                $status = 'Low Stock';
            } else {
                $status = 'In Stock';
            }
        ?>
            <tr>
                <td class="text-center"><?= $sr++ ?></td>
                <td><?= htmlspecialchars($product['product_name']) ?></td>
                <td><?= htmlspecialchars($product['category_name']) ?></td>
                <td class="text-right"><?= number_format($product['cost_price'], 2) ?></td>
                <td class="text-right"><?= number_format($product['price'], 2) ?></td>
                <td class="text-right"><?= number_format($product['profit_amount'], 2) ?></td>
                <td class="text-right"><?= number_format($product['profit_margin'], 2) ?>%</td>
                <td class="text-center"><?= $product['quantity'] ?></td>
                <td><?= $status ?></td>
            </tr>
        <?php endwhile; ?>
        <tr style="background-color: #E7E6E6; font-weight: bold;">
            <td colspan="7" class="text-right">Total Stock Value:</td>
            <td class="text-right">₹<?= number_format($total_stock_value, 2) ?></td>
            <td></td>
        </tr>
    </tbody>
</table>

</body>
</html>