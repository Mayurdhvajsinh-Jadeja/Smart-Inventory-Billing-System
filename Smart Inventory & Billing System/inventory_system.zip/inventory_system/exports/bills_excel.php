<?php
// exports/bills_excel.php

session_start();
require_once __DIR__ . '/../config/db.php';

// Get date range
$date_from = isset($_GET['date_from']) ? $_GET['date_from'] : date('Y-m-01');
$date_to   = isset($_GET['date_to']) ? $_GET['date_to'] : date('Y-m-d');

// Get all bills in date range
$bills = mysqli_query($conn, 
    "SELECT * FROM bills 
     WHERE bill_date BETWEEN '$date_from' AND '$date_to'
     ORDER BY id DESC"
);

// Set headers for Excel download
header('Content-Type: application/vnd.ms-excel');
header('Content-Disposition: attachment; filename="Bills_Report_' . date('Y-m-d') . '.xls"');
header('Cache-Control: max-age=0');
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }
        th, td {
            border: 1px solid #000;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #4472C4;
            color: white;
            font-weight: bold;
        }
        .text-right {
            text-align: right;
        }
        .text-center {
            text-align: center;
        }
    </style>
</head>
<body>

<h2>Bills Report</h2>
<p><strong>Period:</strong> <?= date('d M Y', strtotime($date_from)) ?> to <?= date('d M Y', strtotime($date_to)) ?></p>
<p><strong>Generated On:</strong> <?= date('d M Y, h:i A') ?></p>
<br>

<table>
    <thead>
        <tr>
            <th>Bill ID</th>
            <th>Customer Name</th>
            <th>Total Amount (₹)</th>
            <th>Payment Mode</th>
            <th>Bill Date</th>
            <th>Created At</th>
        </tr>
    </thead>
    <tbody>
        <?php 
        $total_revenue = 0;
        $total_bills = 0;
        while ($bill = mysqli_fetch_assoc($bills)) : 
            $total_revenue += $bill['total_amount'];
            $total_bills++;
        ?>
            <tr>
                <td class="text-center">#<?= str_pad($bill['id'], 4, '0', STR_PAD_LEFT) ?></td>
                <td><?= htmlspecialchars($bill['customer_name']) ?></td>
                <td class="text-right"><?= number_format($bill['total_amount'], 2) ?></td>
                <td><?= htmlspecialchars($bill['payment_mode']) ?></td>
                <td><?= date('d M Y', strtotime($bill['bill_date'])) ?></td>
                <td><?= date('d M Y h:i A', strtotime($bill['created_at'])) ?></td>
            </tr>
        <?php endwhile; ?>
        
        <tr style="background-color: #E7E6E6; font-weight: bold;">
            <td colspan="2" class="text-right">TOTAL:</td>
            <td class="text-right">₹<?= number_format($total_revenue, 2) ?></td>
            <td colspan="3">Total Bills: <?= $total_bills ?></td>
        </tr>
        
        <tr style="background-color: #E7E6E6; font-weight: bold;">
            <td colspan="2" class="text-right">AVERAGE BILL VALUE:</td>
            <td class="text-right">₹<?= $total_bills > 0 ? number_format($total_revenue / $total_bills, 2) : '0.00' ?></td>
            <td colspan="3"></td>
        </tr>
    </tbody>
</table>

</body>
</html>