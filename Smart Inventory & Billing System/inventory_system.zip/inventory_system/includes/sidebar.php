<?php
// includes/sidebar.php

if (session_status() === PHP_SESSION_NONE) session_start();

$user_role    = isset($_SESSION['user_role']) ? $_SESSION['user_role'] : 'staff';
$current_page = basename($_SERVER['PHP_SELF']);
$current_dir  = basename(dirname($_SERVER['PHP_SELF']));

$is_admin   = ($user_role === 'admin');
$is_manager = ($user_role === 'manager');
$is_staff   = ($user_role === 'staff');
$is_admin_or_manager = ($is_admin || $is_manager);

// Role badge config
$role_cfg = [
    'admin'   => ['label' => 'Admin',   'bg' => '#6366f1'],
    'manager' => ['label' => 'Manager', 'bg' => '#8b5cf6'],
    'staff'   => ['label' => 'Staff',   'bg' => '#64748b'],
];
$rc = $role_cfg[$user_role] ?? $role_cfg['staff'];

function navLink($href, $icon, $label, $active) {
    $cls = $active ? 'active' : '';
    echo "<li><a href=\"{$href}\" class=\"{$cls}\">
            <i class=\"bi {$icon}\"></i><span>{$label}</span>
          </a></li>";
}
?>

<div class="sidebar" id="sidebar">

    <!-- Brand -->
    <div class="sidebar-brand">
        <i class="bi bi-shop"></i>
        <div>
            <h4>Smart Inventory</h4>
            <small>Billing System</small>
        </div>
    </div>

    <!-- User pill -->
    <div style="padding:12px 16px;">
        <div style="background:rgba(255,255,255,.07);border-radius:12px;padding:10px 14px;
                    display:flex;align-items:center;gap:10px;">
            <div style="width:34px;height:34px;border-radius:10px;
                        background:linear-gradient(135deg,#6366f1,#ec4899);
                        display:flex;align-items:center;justify-content:center;
                        color:white;font-weight:800;font-size:14px;flex-shrink:0;">
                <?= strtoupper(substr($_SESSION['user_name'] ?? 'U', 0, 1)) ?>
            </div>
            <div style="min-width:0;flex:1;">
                <div style="color:white;font-size:13px;font-weight:600;
                            white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">
                    <?= htmlspecialchars($_SESSION['user_name'] ?? '') ?>
                </div>
                <div style="margin-top:3px;">
                    <span style="background:<?= $rc['bg'] ?>;color:white;font-size:9px;
                                font-weight:700;padding:1px 7px;border-radius:20px;
                                letter-spacing:.5px;text-transform:uppercase;">
                        <?= $rc['label'] ?>
                    </span>
                </div>
            </div>
        </div>
    </div>

    <!-- Menu -->
    <ul class="sidebar-menu">

        <!-- MAIN -->
        <li class="menu-label">Main</li>

        <?php if ($is_admin) : ?>
        <li><a href="<?= $base_url ?>/modules/dashboard/index.php"
               class="<?= $current_dir=='dashboard' && $current_page=='index.php' ? 'active' : '' ?>">
            <i class="bi bi-grid-1x2-fill"></i><span>Dashboard</span>
        </a></li>
        <?php elseif ($is_manager) : ?>
        <li><a href="<?= $base_url ?>/modules/dashboard/manager_index.php"
               class="<?= $current_page=='manager_index.php' ? 'active' : '' ?>">
            <i class="bi bi-grid-1x2-fill"></i><span>Dashboard</span>
        </a></li>
        <?php else : ?>
        <li><a href="<?= $base_url ?>/modules/dashboard/staff_index.php"
               class="<?= $current_page=='staff_index.php' ? 'active' : '' ?>">
            <i class="bi bi-grid-1x2-fill"></i><span>Dashboard</span>
        </a></li>
        <?php endif; ?>

        <!-- INVENTORY — Admin + Manager -->
        <?php if ($is_admin_or_manager) : ?>
        <li class="menu-label">Inventory</li>

        <li><a href="<?= $base_url ?>/modules/categories/index.php"
               class="<?= $current_dir=='categories' ? 'active' : '' ?>">
            <i class="bi bi-tags-fill"></i><span>Categories</span>
        </a></li>

        <li><a href="<?= $base_url ?>/modules/products/index.php"
               class="<?= $current_dir=='products' ? 'active' : '' ?>">
            <i class="bi bi-box-seam-fill"></i><span>Products</span>
        </a></li>

        <li><a href="<?= $base_url ?>/modules/products/stock_log.php"
               class="<?= $current_page=='stock_log.php' ? 'active' : '' ?>">
            <i class="bi bi-clock-history"></i><span>Stock Log</span>
        </a></li>

        <li><a href="<?= $base_url ?>/modules/products/barcode_generator.php"
               class="<?= $current_page=='barcode_generator.php' ? 'active' : '' ?>">
            <i class="bi bi-upc-scan"></i><span>Barcodes</span>
        </a></li>

        <li><a href="<?= $base_url ?>/modules/customers/index.php"
               class="<?= $current_dir=='customers' ? 'active' : '' ?>">
            <i class="bi bi-people-fill"></i><span>Customers</span>
        </a></li>
        <?php else : ?>
        <!-- Staff: products view only -->
        <li class="menu-label">Inventory</li>
        <li><a href="<?= $base_url ?>/modules/products/index.php"
               class="<?= $current_dir=='products' ? 'active' : '' ?>">
            <i class="bi bi-box-seam-fill"></i><span>Products</span>
        </a></li>
        <?php endif; ?>

        <!-- SALES — Everyone -->
        <li class="menu-label">Sales</li>

        <li><a href="<?= $base_url ?>/modules/billing/create.php"
               class="<?= ($current_page=='create.php' && $current_dir=='billing') ? 'active' : '' ?>">
            <i class="bi bi-receipt-cutoff"></i><span>New Bill</span>
        </a></li>

        <li><a href="<?= $base_url ?>/modules/billing/list.php"
               class="<?= ($current_page=='list.php' && $current_dir=='billing') ? 'active' : '' ?>">
            <i class="bi bi-list-check"></i><span>All Bills</span>
        </a></li>

        <!-- FINANCE — Admin only -->
        <?php if ($is_admin) : ?>
        <li class="menu-label">Finance</li>

        <li><a href="<?= $base_url ?>/modules/purchases/index.php"
               class="<?= $current_dir=='purchases' ? 'active' : '' ?>">
            <i class="bi bi-box-arrow-in-down"></i><span>Purchase Entry</span>
        </a></li>

        <li><a href="<?= $base_url ?>/modules/purchases/suppliers.php"
               class="<?= $current_page=='suppliers.php' ? 'active' : '' ?>">
            <i class="bi bi-truck"></i><span>Suppliers</span>
        </a></li>

        <li><a href="<?= $base_url ?>/modules/expenses/index.php"
               class="<?= $current_dir=='expenses' ? 'active' : '' ?>">
            <i class="bi bi-wallet2"></i><span>Expenses</span>
        </a></li>
        <?php endif; ?>

        <!-- PURCHASES — Manager can see, but not expenses -->
        <?php if ($is_manager) : ?>
        <li class="menu-label">Purchases</li>

        <li><a href="<?= $base_url ?>/modules/purchases/index.php"
               class="<?= $current_dir=='purchases' ? 'active' : '' ?>">
            <i class="bi bi-box-arrow-in-down"></i><span>Purchase Entry</span>
        </a></li>

        <li><a href="<?= $base_url ?>/modules/purchases/suppliers.php"
               class="<?= $current_page=='suppliers.php' ? 'active' : '' ?>">
            <i class="bi bi-truck"></i><span>Suppliers</span>
        </a></li>
        <?php endif; ?>

        <!-- REPORTS — Admin full, Manager sales only -->
        <?php if ($is_admin_or_manager) : ?>
        <li class="menu-label">Reports</li>

        <li><a href="<?= $base_url ?>/modules/reports/index.php"
               class="<?= ($current_page=='index.php' && $current_dir=='reports') ? 'active' : '' ?>">
            <i class="bi bi-bar-chart-fill"></i><span>Sales Report</span>
        </a></li>
        <?php endif; ?>

        <?php if ($is_admin) : ?>
        <li><a href="<?= $base_url ?>/modules/reports/profit.php"
               class="<?= $current_page=='profit.php' ? 'active' : '' ?>">
            <i class="bi bi-currency-rupee"></i><span>Profit Analysis</span>
        </a></li>

        <li><a href="<?= $base_url ?>/modules/reports/net_profit.php"
               class="<?= $current_page=='net_profit.php' ? 'active' : '' ?>">
            <i class="bi bi-trophy-fill"></i><span>Net Profit</span>
        </a></li>

        <li><a href="<?= $base_url ?>/modules/reports/financial.php"
               class="<?= $current_page=='financial.php' ? 'active' : '' ?>">
            <i class="bi bi-file-earmark-bar-graph-fill"></i><span>Financial Report</span>
        </a></li>
        <?php endif; ?>

        <!-- ADMINISTRATION — Admin only -->
        <?php if ($is_admin) : ?>
        <li class="menu-label">Administration</li>

        <li><a href="<?= $base_url ?>/modules/Users/index.php"
               class="<?= ($current_dir=='Users' && $current_page!='profile.php') ? 'active' : '' ?>">
            <i class="bi bi-people-fill"></i><span>Manage Users</span>
        </a></li>
        <?php endif; ?>

        <!-- ACCOUNT — Everyone -->
        <li class="menu-label">Account</li>

        <li><a href="<?= $base_url ?>/modules/Users/profile.php"
               class="<?= $current_page=='profile.php' ? 'active' : '' ?>">
            <i class="bi bi-person-circle"></i><span>My Profile</span>
        </a></li>

        <li><a href="<?= $base_url ?>/modules/auth/logout.php"
               onclick="return confirm('Logout?');">
            <i class="bi bi-box-arrow-left"></i><span>Logout</span>
        </a></li>

    </ul>
</div>

<script>
(function() {
    var sidebar = document.getElementById('sidebar');
    var savedPos = localStorage.getItem('sidebarScroll');
    if (savedPos && sidebar) sidebar.scrollTop = savedPos;
    if (sidebar) sidebar.addEventListener('scroll', function() {
        localStorage.setItem('sidebarScroll', sidebar.scrollTop);
    });
})();
</script>
