<?php
// includes/auth_check.php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$_role = isset($_SESSION['user_role']) ? $_SESSION['user_role'] : '';

// ── Role checks ────────────────────────────────────────
function isAdmin()   { return isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin'; }
function isManager() { return isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'manager'; }
function isStaff()   { return isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'staff'; }

// Admin OR Manager
function isAdminOrManager() {
    return isset($_SESSION['user_role']) && in_array($_SESSION['user_role'], ['admin', 'manager']);
}

// ── Access gates ───────────────────────────────────────

// Only admin — blocks manager + staff
function requireAdmin() {
    if (!isAdmin()) {
        _accessDenied('Admin');
    }
}

// Admin or Manager — blocks staff only
function requireManager() {
    if (!isAdminOrManager()) {
        _accessDenied('Manager or Admin');
    }
}

// Any logged-in user — just checks session exists
function requireLogin() {
    if (!isset($_SESSION['user_id'])) {
        header('Location: /inventory_system/modules/auth/login.php');
        exit();
    }
}

// ── Deny page ──────────────────────────────────────────
function _accessDenied($required = 'Admin') {
    $dash = '/inventory_system/modules/dashboard/';
    $role = isset($_SESSION['user_role']) ? $_SESSION['user_role'] : 'guest';
    // Redirect to right dashboard instead of showing error
    if ($role === 'manager') {
        header("Location: {$dash}manager_index.php"); exit();
    } elseif ($role === 'staff') {
        header("Location: {$dash}staff_index.php"); exit();
    } else {
        echo "<div style='text-align:center;padding:60px;font-family:Inter,sans-serif;'>
                <div style='font-size:56px;margin-bottom:16px;'>🚫</div>
                <h2 style='color:#ef4444;font-size:24px;margin-bottom:8px;'>Access Denied</h2>
                <p style='color:#64748b;margin-bottom:24px;'>This page requires <strong>{$required}</strong> access.</p>
                <a href='/inventory_system/modules/auth/login.php'
                   style='background:#6366f1;color:white;padding:12px 28px;border-radius:12px;
                          text-decoration:none;font-weight:600;font-size:14px;'>
                   Back to Login
                </a>
              </div>";
        exit();
    }
}

?>
