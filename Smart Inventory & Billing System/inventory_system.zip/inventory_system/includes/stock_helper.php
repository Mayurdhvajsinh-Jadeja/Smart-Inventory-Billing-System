<?php
// includes/stock_helper.php
// Reusable stock movement logger — include this in any file that changes stock

function log_stock($conn, $product_id, $type, $qty, $direction, $reference_id = null, $note = null) {
    if (!$conn || $qty <= 0) return;
    $res  = mysqli_query($conn, "SELECT quantity FROM products WHERE id=" . (int)$product_id);
    $row  = mysqli_fetch_assoc($res);
    if (!$row) return;
    $before = (int)$row['quantity'];
    $after  = $direction === 'in' ? $before + $qty : $before - $qty;
    $uid    = isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : null;
    $stmt   = mysqli_prepare($conn,
        "INSERT INTO stock_movements
            (product_id, type, quantity, direction, stock_before, stock_after, reference_id, note, created_by)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)"
    );
    mysqli_stmt_bind_param($stmt, "isisiiisi",
        $product_id, $type, $qty, $direction,
        $before, $after, $reference_id, $note, $uid
    );
    mysqli_stmt_execute($stmt);
}
?>
