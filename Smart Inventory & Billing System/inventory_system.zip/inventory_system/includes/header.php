<?php
// includes/header.php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

// Database connection
$path_to_db = __DIR__ . '/../config/db.php';
if (file_exists($path_to_db)) {
    require_once $path_to_db;
} else {
    require_once $_SERVER['DOCUMENT_ROOT'] . '/inventory_system/config/db.php';
}

// Get user info
$user_name  = $_SESSION['user_name'];
$user_email = $_SESSION['user_email'];
$user_role  = isset($_SESSION['user_role']) ? $_SESSION['user_role'] : 'staff';
$avatar_letter = strtoupper(substr($user_name, 0, 1));

// 🔔 NOTIFICATION LOGIC (NEW)
$notif_count = 0;
$notifications = [];

// 1. Check Low Stock
$low_stock_q = mysqli_query($conn, "SELECT COUNT(*) as c FROM products WHERE quantity < 5");
$low_stock_c = mysqli_fetch_assoc($low_stock_q)['c'];
if ($low_stock_c > 0) {
    $notif_count++;
    $notifications[] = [
        'icon' => 'bi-exclamation-triangle-fill text-danger',
        'text' => "$low_stock_c products are low on stock",
        'link' => $base_url . '/modules/products/index.php'
    ];
}

// 2. Check Pending Bills (Admin Only)
if ($user_role === 'admin') {
    $pending_q = mysqli_query($conn, "SELECT COUNT(*) as c FROM bills WHERE status != 'Paid'");
    $pending_c = mysqli_fetch_assoc($pending_q)['c'];
    if ($pending_c > 0) {
        $notif_count++;
        $notifications[] = [
            'icon' => 'bi-cash-coin text-warning',
            'text' => "$pending_c bills have pending payments",
            'link' => $base_url . '/modules/billing/list.php'
        ];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($page_title) ? $page_title . ' | Smart Inventory' : 'Smart Inventory System' ?></title>

    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="<?= $base_url ?>/assets/css/style.css?v=<?= time() ?>" rel="stylesheet">
    <!-- QR/Barcode Scanner Library -->
    <script src="https://unpkg.com/html5-qrcode" type="text/javascript"></script>
    <script>
        const savedTheme = localStorage.getItem('theme');
        if (savedTheme === 'dark') {
            document.documentElement.setAttribute('data-theme', 'dark');
        }
    </script>
    <style>
        .notif-dropdown { min-width: 280px; padding: 0; border: 1px solid var(--border-color); }
        .notif-item { padding: 12px 15px; border-bottom: 1px solid var(--border-color); display: flex; align-items: center; gap: 12px; text-decoration: none; color: var(--text-main); transition: 0.2s; }
        .notif-item:hover { background: var(--hover-bg); }
        .notif-item:last-child { border-bottom: none; }
        .notif-icon { width: 35px; height: 35px; background: var(--hover-bg); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 16px; }
        .notif-text { font-size: 13px; margin: 0; line-height: 1.3; }
        .notif-badge { position: absolute; top: -5px; right: -5px; padding: 3px 6px; font-size: 10px; border-radius: 50%; }
    </style>
</head>
<body>

<div class="sidebar-overlay" id="sidebarOverlay" onclick="toggleSidebar()"></div>

<?php require_once __DIR__ . '/sidebar.php'; ?>

<div class="main-content" id="mainContent">

    <div class="top-navbar">
        <div class="d-flex align-items-center gap-3">
            <button class="sidebar-toggle" onclick="toggleSidebar()">
                <i class="bi bi-list" id="toggleIcon"></i>
            </button>
            <h5 class="page-title mb-0">
                <?= isset($page_title) ? $page_title : 'Dashboard' ?>
            </h5>
        </div>

        <div class="d-flex align-items-center gap-3">
            
            <!-- Dark Mode Toggle -->
            <button class="theme-toggle" onclick="toggleTheme()">
                <i class="bi bi-moon-stars-fill" id="themeIcon"></i>
            </button>

            <!-- 🔔 NOTIFICATION BELL -->
            <div class="dropdown">
                <button class="theme-toggle position-relative" data-bs-toggle="dropdown" aria-expanded="false">
                    <i class="bi bi-bell-fill"></i>
                    <?php if ($notif_count > 0) : ?>
                        <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" style="font-size:9px;">
                            <?= $notif_count ?>
                        </span>
                    <?php endif; ?>
                </button>
                <ul class="dropdown-menu dropdown-menu-end notif-dropdown shadow">
                    <li class="p-3 border-bottom d-flex justify-content-between align-items-center">
                        <strong style="font-size:14px;">Notifications</strong>
                        <span class="badge bg-primary rounded-pill"><?= $notif_count ?> New</span>
                    </li>
                    
                    <?php if ($notif_count > 0) : ?>
                        <?php foreach ($notifications as $note) : ?>
                            <li>
                                <a class="notif-item" href="<?= $note['link'] ?>">
                                    <div class="notif-icon"><i class="bi <?= $note['icon'] ?>"></i></div>
                                    <p class="notif-text"><?= $note['text'] ?></p>
                                </a>
                            </li>
                        <?php endforeach; ?>
                    <?php else : ?>
                        <li class="p-4 text-center text-muted">
                            <i class="bi bi-check-circle" style="font-size:24px;"></i>
                            <p class="mb-0 mt-2" style="font-size:13px;">All caught up!</p>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>

            <!-- Admin Info -->
            <div class="admin-info">
                <div class="d-none d-md-block text-end">
                    <div class="admin-name"><?= htmlspecialchars($user_name) ?></div>
                    <small class="text-muted" style="font-size:11px; text-transform:uppercase; font-weight:700;">
                        <?= htmlspecialchars($user_role) ?>
                    </small>
                </div>
                <div class="admin-avatar ms-2"><?= $avatar_letter ?></div>
            </div>
            
        </div>
    </div>

    <div class="page-content">