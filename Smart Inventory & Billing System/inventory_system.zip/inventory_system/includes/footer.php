<?php
// includes/footer.php
?>

    </div>
    <!-- Page Content End -->

</div>
<!-- Main Content End -->

<!-- TOAST CONTAINER -->
<div id="toastContainer" style="
    position:fixed; top:80px; right:20px; z-index:99999;
    display:flex; flex-direction:column; gap:10px;
    min-width:300px; max-width:380px; pointer-events:none;
"></div>

<!-- PHP Flash → JS Toast bridge -->
<?php if (!empty($_SESSION['success'])) : ?>
<script>document.addEventListener('DOMContentLoaded',function(){ showToast(<?= json_encode($_SESSION['success']) ?>, 'success'); });</script>
<?php unset($_SESSION['success']); endif; ?>

<?php if (!empty($_SESSION['error'])) : ?>
<script>document.addEventListener('DOMContentLoaded',function(){ showToast(<?= json_encode($_SESSION['error']) ?>, 'error'); });</script>
<?php unset($_SESSION['error']); endif; ?>

<?php if (!empty($_SESSION['warning'])) : ?>
<script>document.addEventListener('DOMContentLoaded',function(){ showToast(<?= json_encode($_SESSION['warning']) ?>, 'warning'); });</script>
<?php unset($_SESSION['warning']); endif; ?>

<?php if (!empty($_SESSION['info'])) : ?>
<script>document.addEventListener('DOMContentLoaded',function(){ showToast(<?= json_encode($_SESSION['info']) ?>, 'info'); });</script>
<?php unset($_SESSION['info']); endif; ?>

<!-- Bootstrap 5 JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<style>
.toast-item {
    display:flex; align-items:flex-start; gap:12px;
    padding:14px 16px; border-radius:14px;
    box-shadow:0 8px 30px rgba(0,0,0,0.15);
    pointer-events:all; cursor:pointer;
    position:relative; overflow:hidden;
    animation:toastIn 0.35s cubic-bezier(0.34,1.56,0.64,1) forwards;
    min-width:280px; max-width:380px;
    border-left:4px solid transparent;
}
.toast-item.removing { animation:toastOut 0.3s ease-in forwards; }
@keyframes toastIn  { from{opacity:0;transform:translateX(110%)} to{opacity:1;transform:translateX(0)} }
@keyframes toastOut { from{opacity:1;transform:translateX(0);max-height:100px} to{opacity:0;transform:translateX(110%);max-height:0;margin-bottom:-10px} }

.toast-progress {
    position:absolute; bottom:0; left:0; height:3px;
    border-radius:0 0 0 10px;
    animation:toastProgress var(--dur,4s) linear forwards;
}
@keyframes toastProgress { from{width:100%} to{width:0%} }

.toast-icon  { width:36px;height:36px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0;margin-top:1px; }
.toast-body  { flex:1; }
.toast-title { font-size:13px;font-weight:700;margin-bottom:2px;line-height:1.3; }
.toast-msg   { font-size:13px;line-height:1.4;opacity:0.88; }
.toast-close { background:none;border:none;cursor:pointer;font-size:18px;opacity:0.5;padding:0;line-height:1;transition:opacity 0.2s;flex-shrink:0; }
.toast-close:hover { opacity:1; }

.toast-success { background:#f0fdf4; border-color:#22c55e; color:#14532d; }
.toast-success .toast-icon     { background:#dcfce7; color:#16a34a; }
.toast-success .toast-progress { background:#22c55e; }

.toast-error   { background:#fff1f2; border-color:#ef4444; color:#7f1d1d; }
.toast-error .toast-icon       { background:#fee2e2; color:#dc2626; }
.toast-error .toast-progress   { background:#ef4444; }

.toast-warning { background:#fffbeb; border-color:#f59e0b; color:#78350f; }
.toast-warning .toast-icon     { background:#fef3c7; color:#d97706; }
.toast-warning .toast-progress { background:#f59e0b; }

.toast-info    { background:#eff6ff; border-color:#3b82f6; color:#1e3a5f; }
.toast-info .toast-icon        { background:#dbeafe; color:#2563eb; }
.toast-info .toast-progress    { background:#3b82f6; }

[data-theme="dark"] .toast-success { background:#052e16; color:#bbf7d0; }
[data-theme="dark"] .toast-success .toast-icon { background:#14532d; }
[data-theme="dark"] .toast-error   { background:#450a0a; color:#fecaca; }
[data-theme="dark"] .toast-error .toast-icon   { background:#7f1d1d; }
[data-theme="dark"] .toast-warning { background:#451a03; color:#fde68a; }
[data-theme="dark"] .toast-warning .toast-icon { background:#78350f; }
[data-theme="dark"] .toast-info    { background:#0c1a2e; color:#bfdbfe; }
[data-theme="dark"] .toast-info .toast-icon    { background:#1e3a5f; }
</style>

<script>
// ── TOAST SYSTEM ──────────────────────────────────
const _toastCfg = {
    success: { icon:'bi-check-circle-fill',          title:'Success' },
    error:   { icon:'bi-x-circle-fill',              title:'Error'   },
    warning: { icon:'bi-exclamation-triangle-fill',  title:'Warning' },
    info:    { icon:'bi-info-circle-fill',            title:'Info'   },
};

window.showToast = function(message, type, duration) {
    type     = type     || 'success';
    duration = duration || 4000;
    const cleanMsg  = message.replace(/^[✅❌⚠️ℹ️🔔]+\s*/u, '').trim();
    const cfg       = _toastCfg[type] || _toastCfg.info;
    const container = document.getElementById('toastContainer');
    const toast     = document.createElement('div');
    toast.className = 'toast-item toast-' + type;
    toast.style.setProperty('--dur', duration + 'ms');
    toast.innerHTML =
        '<div class="toast-icon"><i class="bi ' + cfg.icon + '"></i></div>' +
        '<div class="toast-body">' +
            '<div class="toast-title">' + cfg.title + '</div>' +
            '<div class="toast-msg">'   + cleanMsg   + '</div>' +
        '</div>' +
        '<button class="toast-close" onclick="removeToast(this.closest(\'.toast-item\'))">&times;</button>' +
        '<div class="toast-progress"></div>';
    container.appendChild(toast);
    toast.addEventListener('click', function(e) {
        if (!e.target.classList.contains('toast-close')) removeToast(toast);
    });
    setTimeout(function(){ removeToast(toast); }, duration);
};

window.removeToast = function(toast) {
    if (!toast || toast.classList.contains('removing')) return;
    toast.classList.add('removing');
    setTimeout(function(){ toast.remove(); }, 300);
};

// ── SIDEBAR + THEME ───────────────────────────────
document.addEventListener('DOMContentLoaded', function() {

    const sidebar     = document.getElementById('sidebar');
    const mainContent = document.getElementById('mainContent');
    const overlay     = document.getElementById('sidebarOverlay');

    if (sidebar) {
        var saved = localStorage.getItem('sidebarScroll');
        if (saved) {
            sidebar.scrollTop = parseInt(saved, 10);
            setTimeout(function(){ sidebar.scrollTop = parseInt(saved, 10); sidebar.classList.add('ready'); }, 0);
        } else { sidebar.classList.add('ready'); }
        sidebar.addEventListener('scroll', function(){ localStorage.setItem('sidebarScroll', sidebar.scrollTop); });
    }

    if (window.innerWidth > 992 && localStorage.getItem('sidebarState') === 'collapsed') {
        if(sidebar) sidebar.classList.add('collapsed');
        if(mainContent) mainContent.classList.add('expanded');
    }

    window.toggleSidebar = function() {
        if (window.innerWidth <= 992) {
            if(sidebar) sidebar.classList.toggle('show');
            if(overlay) overlay.classList.toggle('show');
        } else {
            if(sidebar) sidebar.classList.toggle('collapsed');
            if(mainContent) mainContent.classList.toggle('expanded');
            localStorage.setItem('sidebarState', sidebar && sidebar.classList.contains('collapsed') ? 'collapsed' : 'expanded');
        }
    };

    var themeIcon = document.getElementById('themeIcon');
    if (localStorage.getItem('theme') === 'dark' && themeIcon) {
        themeIcon.classList.replace('bi-moon-stars-fill', 'bi-sun-fill');
    }

    window.toggleTheme = function() {
        var root   = document.documentElement;
        var isDark = root.getAttribute('data-theme') === 'dark';
        var icon   = document.getElementById('themeIcon');
        if (isDark) {
            root.removeAttribute('data-theme');
            localStorage.setItem('theme', 'light');
            if(icon) icon.classList.replace('bi-sun-fill', 'bi-moon-stars-fill');
        } else {
            root.setAttribute('data-theme', 'dark');
            localStorage.setItem('theme', 'dark');
            if(icon) icon.classList.replace('bi-moon-stars-fill', 'bi-sun-fill');
        }
    };
});
</script>

</body>
</html>
