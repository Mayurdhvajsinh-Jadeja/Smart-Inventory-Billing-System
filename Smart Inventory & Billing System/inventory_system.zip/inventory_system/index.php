<?php
// index.php
session_start();

if (isset($_SESSION['user_id'])) {
    // Redirect based on role
    if (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin') {
        header("Location: modules/dashboard/index.php");
    } else {
        header("Location: modules/dashboard/staff_index.php");
    }
} else {
    // Default to Sign Up page as requested
    header("Location: modules/auth/login.php");
}
exit();
?>