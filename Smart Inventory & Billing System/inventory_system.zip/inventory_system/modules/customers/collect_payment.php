<?php
// modules/customers/collect_payment.php

session_start();
require_once __DIR__ . '/../../config/db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $customer_id  = (int)$_POST['customer_id'];
    $amount       = (float)$_POST['amount'];
    $payment_date = $_POST['payment_date'];
    $payment_mode = $_POST['payment_mode'];
    $note         = trim($_POST['note']);
    $redirect_to  = isset($_POST['redirect_to']) ? $_POST['redirect_to'] : 'customer';

    if ($amount > 0) {
        mysqli_begin_transaction($conn);
        try {
            // 1. Record Payment
            $pay_sql = "INSERT INTO customer_payments (customer_id, amount, payment_date, payment_mode, note) VALUES (?, ?, ?, ?, ?)";
            $stmt = mysqli_prepare($conn, $pay_sql);
            mysqli_stmt_bind_param($stmt, "idsss", $customer_id, $amount, $payment_date, $payment_mode, $note);
            mysqli_stmt_execute($stmt);

            // 2. Update Pending Bills (Oldest First)
            $bills = mysqli_query($conn, "SELECT id, due_amount FROM bills WHERE customer_id = $customer_id AND due_amount > 0 ORDER BY bill_date ASC");
            
            $remaining_payment = $amount;

            while ($bill = mysqli_fetch_assoc($bills)) {
                if ($remaining_payment <= 0) break;

                $due = $bill['due_amount'];
                
                if ($remaining_payment >= $due) {
                    // Fully pay off this bill
                    mysqli_query($conn, "UPDATE bills SET paid_amount = paid_amount + $due, due_amount = 0, status = 'Paid' WHERE id = " . $bill['id']);
                    $remaining_payment -= $due;
                } else {
                    // Partially pay this bill
                    mysqli_query($conn, "UPDATE bills SET paid_amount = paid_amount + $remaining_payment, due_amount = due_amount - $remaining_payment, status = 'Partial' WHERE id = " . $bill['id']);
                    $remaining_payment = 0;
                }
            }

            mysqli_commit($conn);
            $_SESSION['success'] = "✅ Payment of ₹$amount collected successfully!";
        } catch (Exception $e) {
            mysqli_rollback($conn);
            $_SESSION['error'] = "❌ Error: " . $e->getMessage();
        }
    }
    
    // Redirect based on source
    if ($redirect_to == 'bills') {
        header("Location: ../billing/list.php");
    } else {
        header("Location: view.php?id=$customer_id");
    }
    exit();
}
?>