<?php
// modules/customers/index.php
$page_title = "Customers";
session_start();
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../includes/auth_check.php';
requireManager();

if(isset($_GET['delete'])){
    $del=(int)$_GET['delete'];
    $chk=mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as c FROM bills WHERE customer_id=$del"));
    if($chk['c']>0) $_SESSION['error']="❌ Cannot delete — customer has ".$chk['c']." bills.";
    else{
        if(mysqli_query($conn,"DELETE FROM customers WHERE id=$del")) $_SESSION['success']="✅ Customer deleted!";
        else $_SESSION['error']="❌ Failed to delete customer!";
    }
    header("Location: index.php"); exit();
}

$search=isset($_GET['search'])?trim($_GET['search']):'';
$sql="SELECT c.*,COUNT(b.id) as total_bills,COALESCE(SUM(b.total_amount),0) as total_spent,COALESCE(SUM(b.due_amount),0) as total_due FROM customers c LEFT JOIN bills b ON c.id=b.customer_id WHERE 1=1";
if(!empty($search)) $sql.=" AND (c.name LIKE '%".mysqli_real_escape_string($conn,$search)."%' OR c.phone LIKE '%".mysqli_real_escape_string($conn,$search)."%')";
$sql.=" GROUP BY c.id ORDER BY total_spent DESC";
$customers=mysqli_query($conn,$sql);
$total=mysqli_num_rows($customers);

$stats=mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as total, SUM(CASE WHEN b.id IS NOT NULL THEN 1 ELSE 0 END) as active, COALESCE(SUM(b.due_amount),0) as total_due FROM customers c LEFT JOIN bills b ON c.id=b.customer_id"));
$total_revenue=mysqli_fetch_assoc(mysqli_query($conn,"SELECT COALESCE(SUM(total_amount),0) as t FROM bills"))['t'];

require_once __DIR__ . '/../../includes/header.php';
?>
<style>
.cust-stat{background:var(--card-bg);border:1px solid var(--border-color);border-radius:16px;padding:20px;position:relative;overflow:hidden;}
.cust-stat::before{content:'';position:absolute;top:0;left:0;right:0;height:3px;border-radius:16px 16px 0 0;}
.cs1::before{background:linear-gradient(90deg,#6366f1,#8b5cf6);}
.cs2::before{background:linear-gradient(90deg,#10b981,#06b6d4);}
.cs3::before{background:linear-gradient(90deg,#f59e0b,#f97316);}
.cs4::before{background:linear-gradient(90deg,#ef4444,#ec4899);}
.cust-card{background:var(--card-bg);border:1px solid var(--border-color);border-radius:18px;padding:20px;height:100%;transition:all .3s;position:relative;overflow:hidden;}
.cust-card:hover{transform:translateY(-4px);box-shadow:var(--shadow-md);}
.cust-card.vip::after{content:'VIP';position:absolute;top:12px;right:12px;background:linear-gradient(135deg,#f59e0b,#d97706);color:white;font-size:9px;font-weight:800;padding:2px 8px;border-radius:20px;letter-spacing:.5px;}
.cust-av{width:52px;height:52px;border-radius:14px;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:20px;flex-shrink:0;}
.cust-badge{display:inline-flex;align-items:center;gap:4px;padding:3px 10px;border-radius:20px;font-size:11px;font-weight:700;}
.due-pill{background:rgba(239,68,68,.1);color:#ef4444;border-radius:8px;padding:5px 10px;font-size:12px;font-weight:700;display:inline-flex;align-items:center;gap:4px;}
</style>

<!-- Header -->
<div class="d-flex align-items-center justify-content-between mb-4">
    <div>
        <h4 class="mb-1">👥 Customers</h4>
        <p class="text-muted mb-0" style="font-size:14px;"><?= $total ?> customers in database</p>
    </div>
    <div class="d-flex gap-2">
        <a href="add.php" class="btn btn-outline-primary"><i class="bi bi-person-plus me-2"></i>Add Manually</a>
        <a href="<?=$base_url?>/modules/billing/create.php" class="btn btn-primary"><i class="bi bi-receipt me-2"></i>Create Bill</a>
    </div>
</div>

<!-- Stats -->
<div class="row g-4 mb-4">
    <div class="col-lg-3 col-md-6"><div class="cust-stat cs1">
        <div class="d-flex align-items-center gap-3">
            <div style="width:44px;height:44px;border-radius:12px;background:rgba(99,102,241,.12);color:#6366f1;display:flex;align-items:center;justify-content:center;font-size:18px;"><i class="bi bi-people-fill"></i></div>
            <div><div style="font-size:24px;font-weight:800;color:var(--text-main);"><?=$total?></div><div style="font-size:12px;color:var(--text-muted);">Total Customers</div></div>
        </div>
    </div></div>
    <div class="col-lg-3 col-md-6"><div class="cust-stat cs2">
        <div class="d-flex align-items-center gap-3">
            <div style="width:44px;height:44px;border-radius:12px;background:rgba(16,185,129,.12);color:#10b981;display:flex;align-items:center;justify-content:center;font-size:18px;"><i class="bi bi-person-check-fill"></i></div>
            <div><div style="font-size:24px;font-weight:800;color:var(--text-main);"><?=$stats['active']?></div><div style="font-size:12px;color:var(--text-muted);">Active Customers</div></div>
        </div>
    </div></div>
    <div class="col-lg-3 col-md-6"><div class="cust-stat cs3">
        <div class="d-flex align-items-center gap-3">
            <div style="width:44px;height:44px;border-radius:12px;background:rgba(245,158,11,.12);color:#f59e0b;display:flex;align-items:center;justify-content:center;font-size:18px;"><i class="bi bi-currency-rupee"></i></div>
            <div><div style="font-size:24px;font-weight:800;color:var(--text-main);">₹<?=number_format($total_revenue,0)?></div><div style="font-size:12px;color:var(--text-muted);">Total Revenue</div></div>
        </div>
    </div></div>
    <div class="col-lg-3 col-md-6"><div class="cust-stat cs4">
        <div class="d-flex align-items-center gap-3">
            <div style="width:44px;height:44px;border-radius:12px;background:rgba(239,68,68,.12);color:#ef4444;display:flex;align-items:center;justify-content:center;font-size:18px;"><i class="bi bi-clock-history"></i></div>
            <div><div style="font-size:24px;font-weight:800;color:var(--text-main);">₹<?=number_format($stats['total_due'],0)?></div><div style="font-size:12px;color:var(--text-muted);">Total Pending Due</div></div>
        </div>
    </div></div>
</div>

<!-- Search -->
<div class="card mb-4">
    <div class="card-body">
        <form method="GET" class="d-flex gap-3">
            <input type="text" name="search" class="form-control" placeholder="Search by name or phone..." value="<?=htmlspecialchars($search)?>" style="flex:1;">
            <button type="submit" class="btn btn-primary"><i class="bi bi-search me-1"></i>Search</button>
            <?php if(!empty($search)):?><a href="index.php" class="btn btn-light"><i class="bi bi-x"></i></a><?php endif;?>
        </form>
    </div>
</div>

<!-- Customer Cards -->
<?php if($total>0):
$av_cols=['#6366f1','#10b981','#f59e0b','#ef4444','#06b6d4','#8b5cf6','#ec4899'];$i=0;
?>
<div class="row g-4">
<?php while($c=mysqli_fetch_assoc($customers)):
    $col=$av_cols[$i%7]; $i++;
    $is_vip=($c['total_bills']>5);
?>
<div class="col-xl-3 col-lg-4 col-md-6">
    <div class="cust-card <?=$is_vip?'vip':''?>">
        <!-- Avatar + name -->
        <div class="d-flex align-items-center gap-3 mb-3">
            <div class="cust-av" style="background:<?=$col?>20;color:<?=$col?>;"><?=strtoupper(substr($c['name'],0,1))?></div>
            <div class="flex-grow-1 min-w-0">
                <div style="font-size:14px;font-weight:700;color:var(--text-main);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;"><?=htmlspecialchars($c['name'])?></div>
                <div style="font-size:12px;color:var(--text-muted);"><i class="bi bi-phone me-1"></i><?=htmlspecialchars($c['phone'])?></div>
            </div>
        </div>
        <!-- Stats row -->
        <div class="row g-2 mb-3">
            <div class="col-6"><div style="background:var(--hover-bg);border-radius:10px;padding:8px;text-align:center;">
                <div style="font-size:16px;font-weight:800;color:<?=$col?>;"><?=$c['total_bills']?></div>
                <div style="font-size:10px;color:var(--text-muted);font-weight:600;">BILLS</div>
            </div></div>
            <div class="col-6"><div style="background:var(--hover-bg);border-radius:10px;padding:8px;text-align:center;">
                <div style="font-size:14px;font-weight:800;color:#10b981;">₹<?=number_format($c['total_spent'],0)?></div>
                <div style="font-size:10px;color:var(--text-muted);font-weight:600;">SPENT</div>
            </div></div>
        </div>
        <!-- Due amount if any -->
        <?php if($c['total_due']>0):?>
        <div class="due-pill mb-3"><i class="bi bi-clock-history"></i> Due: ₹<?=number_format($c['total_due'],2)?></div>
        <?php endif;?>
        <!-- Actions -->
        <div class="d-flex gap-2">
            <a href="view.php?id=<?=$c['id']?>" class="btn btn-sm btn-outline-primary flex-fill"><i class="bi bi-eye me-1"></i>View</a>
            <a href="edit.php?id=<?=$c['id']?>" class="btn btn-sm btn-outline-secondary"><i class="bi bi-pencil"></i></a>
            <?php if($c['total_bills']==0):?>
            <a href="index.php?delete=<?=$c['id']?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete <?=htmlspecialchars($c['name'])?>?')"><i class="bi bi-trash"></i></a>
            <?php else:?>
            <button class="btn btn-sm btn-outline-secondary" disabled title="Has bills"><i class="bi bi-trash"></i></button>
            <?php endif;?>
        </div>
    </div>
</div>
<?php endwhile;?>
</div>
<?php else:?>
<div class="card"><div class="card-body text-center py-5">
    <i class="bi bi-people" style="font-size:60px;color:#cbd5e1;"></i>
    <h5 class="mt-3 mb-2" style="color:var(--text-muted);">No customers found</h5>
    <p class="text-muted mb-4"><?=!empty($search)?'Try a different search term.':'Customers are auto-saved when you create a bill.'?></p>
    <a href="<?=$base_url?>/modules/billing/create.php" class="btn btn-primary"><i class="bi bi-receipt me-2"></i>Create First Bill</a>
</div></div>
<?php endif;?>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
