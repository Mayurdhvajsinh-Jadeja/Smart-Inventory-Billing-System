<?php
// modules/customers/view.php
$page_title = "Customer Details";
session_start();
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../includes/auth_check.php';
requireManager();

$cid = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if (!$cid) { header("Location: index.php"); exit(); }

$customer = mysqli_fetch_assoc(mysqli_query($conn,
    "SELECT c.*,COUNT(b.id) as total_bills,COALESCE(SUM(b.total_amount),0) as total_spent,
     COALESCE(SUM(b.due_amount),0) as total_due,COALESCE(SUM(b.paid_amount),0) as total_paid,
     MAX(b.bill_date) as last_purchase
     FROM customers c LEFT JOIN bills b ON c.id=b.customer_id WHERE c.id=$cid GROUP BY c.id"
));
if (!$customer) { $_SESSION['error']="❌ Customer not found!"; header("Location: index.php"); exit(); }

$bills    = mysqli_query($conn,"SELECT * FROM bills WHERE customer_id=$cid ORDER BY bill_date DESC,id DESC LIMIT 20");
$payments = mysqli_query($conn,"SELECT * FROM customer_payments WHERE customer_id=$cid ORDER BY payment_date DESC LIMIT 15");

// Monthly spending chart (last 6 months)
$ml=[]; $md=[];
for($i=5;$i>=0;$i--){
    $m=date('Y-m',strtotime("-$i months"));
    $ml[]=date('M',strtotime("-$i months"));
    $r=mysqli_fetch_assoc(mysqli_query($conn,"SELECT COALESCE(SUM(total_amount),0) as t FROM bills WHERE customer_id=$cid AND DATE_FORMAT(bill_date,'%Y-%m')='$m'"));
    $md[]=(float)$r['t'];
}

require_once __DIR__ . '/../../includes/header.php';
?>
<style>
.cust-hero{background:linear-gradient(135deg,#0f172a 0%,#1e1b4b 60%,#312e81 100%);border-radius:22px;padding:30px 34px;color:white;position:relative;overflow:hidden;margin-bottom:24px;}
.cust-hero::before{content:'';position:absolute;top:-50px;right:-50px;width:220px;height:220px;background:radial-gradient(circle,rgba(99,102,241,.3) 0%,transparent 70%);}
.ch-c{position:relative;z-index:1;}
.ch-av{width:72px;height:72px;border-radius:20px;display:flex;align-items:center;justify-content:center;font-size:28px;font-weight:800;flex-shrink:0;}
.info-field{background:var(--hover-bg);border-radius:12px;padding:14px 16px;border:1px solid var(--border-color);}
.if-lbl{font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:var(--text-muted);margin-bottom:5px;}
.if-val{font-size:14px;font-weight:600;color:var(--text-main);}
.ledger-card{border-radius:16px;padding:18px;border:2px solid;}
.lc-green{background:rgba(16,185,129,.06);border-color:rgba(16,185,129,.3);}
.lc-red  {background:rgba(239,68,68,.06); border-color:rgba(239,68,68,.3);}
.lc-blue {background:rgba(99,102,241,.06);border-color:rgba(99,102,241,.3);}
.bill-row{display:flex;align-items:center;gap:12px;padding:12px 0;border-bottom:1px solid var(--border-color);}
.bill-row:last-child{border-bottom:none;}
.pay-item{display:flex;align-items:center;gap:10px;padding:10px 14px;border-radius:12px;background:var(--hover-bg);border:1px solid var(--border-color);margin-bottom:8px;}
.timeline-line{border-left:2px dashed var(--border-color);margin-left:18px;padding-left:18px;}
</style>

<!-- Header -->
<div class="d-flex align-items-center justify-content-between mb-4">
    <div>
        <h4 class="mb-1">👤 Customer Profile</h4>
        <p class="text-muted mb-0" style="font-size:14px;">Full ledger, purchase history & payments</p>
    </div>
    <div class="d-flex gap-2">
        <a href="<?=$base_url?>/modules/billing/create.php" class="btn btn-primary"><i class="bi bi-plus-circle me-2"></i>New Bill</a>
        <a href="edit.php?id=<?=$cid?>" class="btn btn-outline-primary"><i class="bi bi-pencil me-2"></i>Edit</a>
        <a href="index.php" class="btn btn-light"><i class="bi bi-arrow-left me-2"></i>Back</a>
    </div>
</div>

<!-- Hero -->
<div class="cust-hero">
    <div class="ch-c">
        <div class="d-flex align-items-center gap-4">
            <div class="ch-av" style="background:linear-gradient(135deg,#6366f1,#ec4899);"><?=strtoupper(substr($customer['name'],0,1))?></div>
            <div>
                <h2 style="font-size:26px;font-weight:800;margin:0 0 4px;"><?=htmlspecialchars($customer['name'])?></h2>
                <div style="font-size:13px;opacity:.6;">Member since <?=date('M Y',strtotime($customer['created_at']))?></div>
                <div class="d-flex gap-2 mt-3 flex-wrap">
                    <div style="background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.2);border-radius:50px;padding:5px 14px;font-size:12px;font-weight:600;color:white;"><i class="bi bi-receipt-cutoff me-1"></i><?=$customer['total_bills']?> bills</div>
                    <div style="background:rgba(16,185,129,.25);border:1px solid rgba(16,185,129,.4);border-radius:50px;padding:5px 14px;font-size:12px;font-weight:600;color:#6ee7b7;"><i class="bi bi-currency-rupee me-1"></i>₹<?=number_format($customer['total_spent'],0)?> spent</div>
                    <?php if($customer['total_due']>0):?>
                    <div style="background:rgba(239,68,68,.25);border:1px solid rgba(239,68,68,.4);border-radius:50px;padding:5px 14px;font-size:12px;font-weight:600;color:#fca5a5;"><i class="bi bi-clock-history me-1"></i>₹<?=number_format($customer['total_due'],0)?> due</div>
                    <?php endif;?>
                    <?php if($customer['total_bills']>5):?><div style="background:linear-gradient(135deg,rgba(245,158,11,.3),rgba(249,115,22,.3));border:1px solid rgba(245,158,11,.4);border-radius:50px;padding:5px 14px;font-size:12px;font-weight:600;color:#fcd34d;">⭐ VIP Customer</div><?php endif;?>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row g-4 mb-4">
    <!-- Contact info -->
    <div class="col-lg-5">
        <div class="card h-100">
            <div class="card-header"><i class="bi bi-person-lines-fill me-2 text-primary"></i>Contact Information</div>
            <div class="card-body">
                <div class="d-flex flex-column gap-3">
                    <div class="info-field">
                        <div class="if-lbl"><i class="bi bi-phone me-1"></i>Phone</div>
                        <div class="if-val"><?=htmlspecialchars($customer['phone'])?></div>
                    </div>
                    <div class="info-field">
                        <div class="if-lbl"><i class="bi bi-envelope me-1"></i>Email</div>
                        <div class="if-val"><?=!empty($customer['email'])?htmlspecialchars($customer['email']):'—'?></div>
                    </div>
                    <div class="info-field">
                        <div class="if-lbl"><i class="bi bi-geo-alt me-1"></i>Address</div>
                        <div class="if-val"><?=!empty($customer['address'])?nl2br(htmlspecialchars($customer['address'])):'—'?></div>
                    </div>
                    <?php if($customer['last_purchase']):?>
                    <div class="info-field">
                        <div class="if-lbl"><i class="bi bi-calendar-check me-1"></i>Last Purchase</div>
                        <div class="if-val"><?=date('d M Y',strtotime($customer['last_purchase']))?></div>
                    </div>
                    <?php endif;?>
                </div>
            </div>
        </div>
    </div>

    <!-- Ledger cards -->
    <div class="col-lg-7">
        <div class="row g-3 mb-3">
            <div class="col-md-4">
                <div class="ledger-card lc-green text-center">
                    <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:#059669;margin-bottom:6px;">Total Spent</div>
                    <div style="font-size:24px;font-weight:800;color:#10b981;">₹<?=number_format($customer['total_spent'],0)?></div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="ledger-card lc-blue text-center">
                    <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:#4f46e5;margin-bottom:6px;">Amount Paid</div>
                    <div style="font-size:24px;font-weight:800;color:#6366f1;">₹<?=number_format($customer['total_paid'],0)?></div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="ledger-card <?=$customer['total_due']>0?'lc-red':'lc-green'?> text-center">
                    <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:<?=$customer['total_due']>0?'#dc2626':'#059669'?>;margin-bottom:6px;">Outstanding Due</div>
                    <div style="font-size:24px;font-weight:800;color:<?=$customer['total_due']>0?'#ef4444':'#10b981'?>;">₹<?=number_format($customer['total_due'],0)?></div>
                    <?php if($customer['total_due']>0):?>
                    <button class="btn btn-danger btn-sm w-100 mt-2" data-bs-toggle="modal" data-bs-target="#payModal">
                        <i class="bi bi-cash-coin me-1"></i>Collect Payment
                    </button>
                    <?php endif;?>
                </div>
            </div>
        </div>
        <!-- Spending chart -->
        <div class="card">
            <div class="card-header"><i class="bi bi-bar-chart-fill me-2 text-primary"></i>Monthly Spending (6 months)</div>
            <div class="card-body"><div style="position:relative;height:140px;"><canvas id="spendChart"></canvas></div></div>
        </div>
    </div>
</div>

<!-- Bill History -->
<div class="card mb-4">
    <div class="card-header d-flex align-items-center justify-content-between">
        <span><i class="bi bi-clock-history me-2 text-primary"></i>Purchase History</span>
        <span style="font-size:12px;font-weight:700;background:rgba(99,102,241,.1);color:#4f46e5;padding:3px 10px;border-radius:20px;"><?=mysqli_num_rows($bills)?> bills</span>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table mb-0">
                <thead><tr><th>Bill</th><th>Date</th><th>Items</th><th>Total</th><th>Paid</th><th>Due</th><th>Status</th><th></th></tr></thead>
                <tbody>
                <?php $av=['#6366f1','#10b981','#f59e0b','#ef4444','#06b6d4','#8b5cf6','#ec4899'];$bi=0;
                if(mysqli_num_rows($bills)>0):
                    while($b=mysqli_fetch_assoc($bills)):
                        $col=$av[$bi%7];$bi++;
                        $sc=$b['status']==='Paid'?'background:#d1fae5;color:#065f46;':($b['status']==='Partial'?'background:#fef3c7;color:#92400e;':'background:#fee2e2;color:#991b1b;');
                        $items_q=mysqli_query($conn,"SELECT bi.quantity,p.product_name FROM bill_items bi LEFT JOIN products p ON bi.product_id=p.id WHERE bi.bill_id=".$b['id']." LIMIT 3");
                        $items_arr=[]; while($it=mysqli_fetch_assoc($items_q)) $items_arr[]=$it;
                ?>
                <tr>
                    <td><strong style="color:<?=$col?>;">#<?=str_pad($b['id'],4,'0',STR_PAD_LEFT)?></strong></td>
                    <td style="font-size:12px;color:var(--text-muted);"><?=date('d M Y',strtotime($b['bill_date']))?></td>
                    <td style="font-size:12px;">
                        <?php foreach(array_slice($items_arr,0,2) as $it):?>
                        <div><?=htmlspecialchars($it['product_name'])?> ×<?=$it['quantity']?></div>
                        <?php endforeach;
                        if(count($items_arr)>2) echo '<div style="color:var(--text-muted);">+'.(count($items_arr)-2).' more</div>';?>
                    </td>
                    <td><strong>₹<?=number_format($b['total_amount'],2)?></strong></td>
                    <td style="color:#10b981;font-weight:600;">₹<?=number_format($b['paid_amount'],2)?></td>
                    <td style="color:<?=$b['due_amount']>0?'#ef4444':'var(--text-muted)'?>;font-weight:<?=$b['due_amount']>0?'700':'400'?>;"><?=$b['due_amount']>0?'₹'.number_format($b['due_amount'],2):'—'?></td>
                    <td><span style="font-size:10px;font-weight:700;padding:3px 10px;border-radius:20px;<?=$sc?>"><?=$b['status']?></span></td>
                    <td><a href="<?=$base_url?>/modules/billing/view.php?id=<?=$b['id']?>" class="btn btn-sm btn-outline-primary" target="_blank"><i class="bi bi-eye"></i></a></td>
                </tr>
                <?php endwhile; else:?>
                <tr><td colspan="8" class="text-center py-5 text-muted"><i class="bi bi-cart-x" style="font-size:40px;opacity:.3;"></i><p class="mt-2 mb-0">No purchase history yet</p></td></tr>
                <?php endif;?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Payment History -->
<?php if(mysqli_num_rows($payments)>0):?>
<div class="card mb-4">
    <div class="card-header"><i class="bi bi-cash-coin me-2 text-success"></i>Payment History</div>
    <div class="card-body">
        <?php while($pay=mysqli_fetch_assoc($payments)):?>
        <div class="pay-item">
            <div style="width:36px;height:36px;border-radius:10px;background:rgba(16,185,129,.12);color:#10b981;display:flex;align-items:center;justify-content:center;font-size:16px;flex-shrink:0;"><i class="bi bi-check-circle-fill"></i></div>
            <div style="flex:1;">
                <div style="font-size:13px;font-weight:600;color:var(--text-main);">₹<?=number_format($pay['amount'],2)?> received</div>
                <div style="font-size:11px;color:var(--text-muted);"><?=date('d M Y',strtotime($pay['payment_date']))?> · <?=$pay['payment_mode']?><?=!empty($pay['note'])?' · '.htmlspecialchars($pay['note']):''?></div>
            </div>
            <div style="font-size:14px;font-weight:800;color:#10b981;">+₹<?=number_format($pay['amount'],2)?></div>
        </div>
        <?php endwhile;?>
    </div>
</div>
<?php endif;?>

<!-- Collect Payment Modal -->
<div class="modal fade" id="payModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header" style="background:linear-gradient(135deg,#10b981,#059669);border:none;">
                <h5 class="modal-title text-white"><i class="bi bi-cash-stack me-2"></i>Collect Payment</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form action="collect_payment.php" method="POST">
                <input type="hidden" name="customer_id" value="<?=$cid?>">
                <div class="modal-body p-4">
                    <div class="alert alert-warning d-flex gap-3 align-items-center">
                        <i class="bi bi-exclamation-circle-fill" style="font-size:22px;"></i>
                        <div>Outstanding: <h4 class="mb-0 text-danger fw-bold">₹<?=number_format($customer['total_due'],2)?></h4></div>
                    </div>
                    <div class="mb-3"><label class="form-label fw-bold">Amount (₹)</label>
                        <div class="input-group"><span class="input-group-text">₹</span><input type="number" name="amount" class="form-control form-control-lg fw-bold" step="0.01" max="<?=$customer['total_due']?>" value="<?=number_format($customer['total_due'],2,'.','')?>" required></div>
                    </div>
                    <div class="row g-3">
                        <div class="col-6"><label class="form-label fw-bold">Date</label><input type="date" name="payment_date" class="form-control" value="<?=date('Y-m-d')?>" required></div>
                        <div class="col-6"><label class="form-label fw-bold">Mode</label><select name="payment_mode" class="form-select"><option value="Cash">💵 Cash</option><option value="UPI">📱 UPI</option><option value="Bank Transfer">🏦 Bank</option><option value="Cheque">📄 Cheque</option></select></div>
                    </div>
                    <div class="mt-3"><label class="form-label fw-bold">Note</label><input type="text" name="note" class="form-control" placeholder="Optional reference..."></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-success px-4"><i class="bi bi-check-lg me-2"></i>Confirm Payment</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
var ctx=document.getElementById('spendChart');
if(ctx){new Chart(ctx.getContext('2d'),{type:'bar',data:{labels:<?=json_encode($ml)?>,datasets:[{label:'Spent',data:<?=json_encode($md)?>,backgroundColor:'rgba(99,102,241,0.8)',borderColor:'#6366f1',borderWidth:0,borderRadius:6,borderSkipped:false}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false},tooltip:{callbacks:{label:function(c){return' ₹'+c.raw.toLocaleString('en-IN');}}}},scales:{x:{grid:{display:false},ticks:{font:{size:10}}},y:{beginAtZero:true,grid:{color:'rgba(128,128,128,0.08)'},ticks:{callback:function(v){return'₹'+(v>=1000?(v/1000).toFixed(0)+'k':v);}}}}}});}
</script>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
