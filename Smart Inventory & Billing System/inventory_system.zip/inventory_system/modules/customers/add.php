<?php
// modules/customers/add.php

$page_title = "Add Customer";

// Start session
session_start();

// Database connection
require_once __DIR__ . '/../../config/db.php';

// Handle Form Submit
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    $name    = trim($_POST['name']);
    $phone   = trim($_POST['phone']);
    $email   = trim($_POST['email']);
    $address = trim($_POST['address']);
    
    // Validation
    if (empty($name) || empty($phone)) {
        $_SESSION['error'] = "⚠️ Name and Phone are required!";
    } else {
        // Check duplicate phone
        $check_sql = "SELECT * FROM customers WHERE phone = ?";
        $check_stmt = mysqli_prepare($conn, $check_sql);
        mysqli_stmt_bind_param($check_stmt, "s", $phone);
        mysqli_stmt_execute($check_stmt);
        $check_result = mysqli_stmt_get_result($check_stmt);
        
        if (mysqli_num_rows($check_result) > 0) {
            $_SESSION['error'] = "⚠️ Phone number already exists!";
        } else {
            $sql  = "INSERT INTO customers (name, phone, email, address) VALUES (?, ?, ?, ?)";
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, "ssss", $name, $phone, $email, $address);
            
            if (mysqli_stmt_execute($stmt)) {
                $_SESSION['success'] = "✅ Customer added successfully!";
                header("Location: index.php");
                exit();
            } else {
                $_SESSION['error'] = "❌ Failed to add customer!";
            }
        }
    }
}

// Include Header
require_once __DIR__ . '/../../includes/header.php';
?>

<!-- ══════════════ ADD CUSTOMER PAGE ══════════════ -->

<!-- Page Header -->
<div class="d-flex align-items-center justify-content-between mb-4">
    <div>
        <h4 class="mb-1">➕ Add New Customer</h4>
        <p class="text-muted mb-0" style="font-size:14px;">
            Add customer details to your database
        </p>
    </div>
    <a href="index.php" class="btn btn-light" style="border-radius:10px;">
        <i class="bi bi-arrow-left me-2"></i>Back to Customers
    </a>
</div>

<!-- Alerts -->


<!-- Add Customer Form -->
<div class="card">
    <div class="card-header">
        <i class="bi bi-person-badge me-2 text-primary"></i>Customer Details
    </div>
    <div class="card-body">
        <form method="POST" action="">
            <div class="row g-4">

                <!-- Name -->
                <div class="col-md-6">
                    <label class="form-label" style="font-weight:600;">
                        Full Name <span class="text-danger">*</span>
                    </label>
                    <input 
                        type="text" 
                        name="name" 
                        class="form-control" 
                        placeholder="Enter customer name"
                        style="border-radius:10px; padding:12px 15px;"
                        value="<?= isset($_POST['name']) ? htmlspecialchars($_POST['name']) : '' ?>"
                        required
                    >
                </div>

                <!-- Phone -->
                <div class="col-md-6">
                    <label class="form-label" style="font-weight:600;">
                        Phone Number <span class="text-danger">*</span>
                    </label>
                    <input 
                        type="tel" 
                        name="phone" 
                        class="form-control" 
                        placeholder="Enter 10-digit phone number"
                        style="border-radius:10px; padding:12px 15px;"
                        pattern="[0-9]{10}"
                        maxlength="10"
                        value="<?= isset($_POST['phone']) ? htmlspecialchars($_POST['phone']) : '' ?>"
                        required
                    >
                    <small class="text-muted">Format: 10 digits (e.g., 9876543210)</small>
                </div>

                <!-- Email -->
                <div class="col-md-6">
                    <label class="form-label" style="font-weight:600;">
                        Email Address
                    </label>
                    <input 
                        type="email" 
                        name="email" 
                        class="form-control" 
                        placeholder="Enter email address"
                        style="border-radius:10px; padding:12px 15px;"
                        value="<?= isset($_POST['email']) ? htmlspecialchars($_POST['email']) : '' ?>"
                    >
                </div>

                <!-- Address -->
                <div class="col-12">
                    <label class="form-label" style="font-weight:600;">
                        Address
                    </label>
                    <textarea 
                        name="address" 
                        class="form-control" 
                        rows="3"
                        placeholder="Enter customer address"
                        style="border-radius:10px; padding:12px 15px;"
                    ><?= isset($_POST['address']) ? htmlspecialchars($_POST['address']) : '' ?></textarea>
                </div>

                <!-- Submit Button -->
                <div class="col-12">
                    <hr>
                    <button type="submit" class="btn btn-primary btn-lg" style="border-radius:10px;">
                        <i class="bi bi-check-circle me-2"></i>Add Customer
                    </button>
                    <a href="index.php" class="btn btn-light btn-lg ms-2" style="border-radius:10px;">
                        Cancel
                    </a>
                </div>

            </div>
        </form>
    </div>
</div>

<!-- Info Card -->
<div class="card mt-4" style="border:2px dashed #e2e8f0;">
    <div class="card-body">
        <h6 class="mb-3">
            <i class="bi bi-info-circle me-2" style="color:#6366f1;"></i>
            Why Add Customers?
        </h6>
        <div class="row g-3" style="font-size:13px;">
            <div class="col-md-4">
                <strong style="color:#0f172a;">📊 Track History:</strong>
                <p style="margin-top:8px; color:#64748b;">
                    View complete purchase history of each customer
                </p>
            </div>
            <div class="col-md-4">
                <strong style="color:#0f172a;">🎯 Better Service:</strong>
                <p style="margin-top:8px; color:#64748b;">
                    Know your top customers and serve them better
                </p>
            </div>
            <div class="col-md-4">
                <strong style="color:#0f172a;">💰 Increase Sales:</strong>
                <p style="margin-top:8px; color:#64748b;">
                    Build relationships and encourage repeat purchases
                </p>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>