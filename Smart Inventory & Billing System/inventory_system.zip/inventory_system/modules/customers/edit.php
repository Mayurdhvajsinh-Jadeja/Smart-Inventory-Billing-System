<?php
// modules/customers/edit.php

$page_title = "Edit Customer";

// Start session
session_start();

// Database connection
require_once __DIR__ . '/../../config/db.php';

// Get Customer ID
$customer_id = isset($_GET['id']) ? (int) $_GET['id'] : 0;

if ($customer_id == 0) {
    header("Location: index.php");
    exit();
}

// Get Customer Data
$customer_query = mysqli_query($conn, "SELECT * FROM customers WHERE id = $customer_id");

if (mysqli_num_rows($customer_query) == 0) {
    $_SESSION['error'] = "❌ Customer not found!";
    header("Location: index.php");
    exit();
}

$customer = mysqli_fetch_assoc($customer_query);

// Handle Form Submit
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    $name    = trim($_POST['name']);
    $phone   = trim($_POST['phone']);
    $email   = trim($_POST['email']);
    $address = trim($_POST['address']);
    
    if (empty($name) || empty($phone)) {
        $_SESSION['error'] = "⚠️ Name and Phone are required!";
    } else {
        // Check duplicate phone (except current customer)
        $check_sql = "SELECT * FROM customers WHERE phone = ? AND id != ?";
        $check_stmt = mysqli_prepare($conn, $check_sql);
        mysqli_stmt_bind_param($check_stmt, "si", $phone, $customer_id);
        mysqli_stmt_execute($check_stmt);
        $check_result = mysqli_stmt_get_result($check_stmt);
        
        if (mysqli_num_rows($check_result) > 0) {
            $_SESSION['error'] = "⚠️ Phone number already exists!";
        } else {
            $sql  = "UPDATE customers SET name=?, phone=?, email=?, address=? WHERE id=?";
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, "ssssi", $name, $phone, $email, $address, $customer_id);
            
            if (mysqli_stmt_execute($stmt)) {
                $_SESSION['success'] = "✅ Customer updated successfully!";
                header("Location: index.php");
                exit();
            } else {
                $_SESSION['error'] = "❌ Failed to update customer!";
            }
        }
    }
}

// Include Header
require_once __DIR__ . '/../../includes/header.php';
?>

<!-- ══════════════ EDIT CUSTOMER PAGE ══════════════ -->

<!-- Page Header -->
<div class="d-flex align-items-center justify-content-between mb-4">
    <div>
        <h4 class="mb-1">✏️ Edit Customer</h4>
        <p class="text-muted mb-0" style="font-size:14px;">
            Update customer information
        </p>
    </div>
    <a href="index.php" class="btn btn-light" style="border-radius:10px;">
        <i class="bi bi-arrow-left me-2"></i>Back to Customers
    </a>
</div>

<!-- Alerts -->


<!-- Edit Customer Form -->
<div class="card">
    <div class="card-header">
        <i class="bi bi-person-badge me-2 text-primary"></i>Customer Details
    </div>
    <div class="card-body">
        <form method="POST" action="">
            <div class="row g-4">

                <!-- Name -->
                <div class="col-md-6">
                    <label class="form-label" style="font-weight:600;">
                        Full Name <span class="text-danger">*</span>
                    </label>
                    <input 
                        type="text" 
                        name="name" 
                        class="form-control" 
                        style="border-radius:10px; padding:12px 15px;"
                        value="<?= htmlspecialchars($customer['name']) ?>"
                        required
                    >
                </div>

                <!-- Phone -->
                <div class="col-md-6">
                    <label class="form-label" style="font-weight:600;">
                        Phone Number <span class="text-danger">*</span>
                    </label>
                    <input 
                        type="tel" 
                        name="phone" 
                        class="form-control" 
                        style="border-radius:10px; padding:12px 15px;"
                        pattern="[0-9]{10}"
                        maxlength="10"
                        value="<?= htmlspecialchars($customer['phone']) ?>"
                        required
                    >
                </div>

                <!-- Email -->
                <div class="col-md-6">
                    <label class="form-label" style="font-weight:600;">
                        Email Address
                    </label>
                    <input 
                        type="email" 
                        name="email" 
                        class="form-control" 
                        style="border-radius:10px; padding:12px 15px;"
                        value="<?= htmlspecialchars($customer['email']) ?>"
                    >
                </div>

                <!-- Address -->
                <div class="col-12">
                    <label class="form-label" style="font-weight:600;">
                        Address
                    </label>
                    <textarea 
                        name="address" 
                        class="form-control" 
                        rows="3"
                        style="border-radius:10px; padding:12px 15px;"
                    ><?= htmlspecialchars($customer['address']) ?></textarea>
                </div>

                <!-- Submit Button -->
                <div class="col-12">
                    <hr>
                    <button type="submit" class="btn btn-primary btn-lg" style="border-radius:10px;">
                        <i class="bi bi-check-circle me-2"></i>Update Customer
                    </button>
                    <a href="index.php" class="btn btn-light btn-lg ms-2" style="border-radius:10px;">
                        Cancel
                    </a>
                </div>

            </div>
        </form>
    </div>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>