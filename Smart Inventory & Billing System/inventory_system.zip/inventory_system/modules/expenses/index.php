<?php
// modules/expenses/index.php
$page_title = "Expenses";
session_start();
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../includes/auth_check.php';
requireAdmin();

if (isset($_GET['delete'])) {
    $del = (int)$_GET['delete'];
    if (mysqli_query($conn,"DELETE FROM expenses WHERE id=$del")) $_SESSION['success']="✅ Expense deleted!";
    else $_SESSION['error']="❌ Failed to delete!";
    header("Location: index.php"); exit();
}

$date_from = isset($_GET['date_from']) ? $_GET['date_from'] : date('Y-m-01');
$date_to   = isset($_GET['date_to'])   ? $_GET['date_to']   : date('Y-m-d');

$expenses = mysqli_query($conn,"SELECT * FROM expenses WHERE expense_date BETWEEN '$date_from' AND '$date_to' ORDER BY expense_date DESC,id DESC");
$total_expenses = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COALESCE(SUM(amount),0) as t FROM expenses WHERE expense_date BETWEEN '$date_from' AND '$date_to'"))['t'];
$today_expenses = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COALESCE(SUM(amount),0) as t FROM expenses WHERE expense_date='".date('Y-m-d')."'"))['t'];
$month_expenses = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COALESCE(SUM(amount),0) as t FROM expenses WHERE DATE_FORMAT(expense_date,'%Y-%m')='".date('Y-m')."'"))['t'];
$alltime        = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COALESCE(SUM(amount),0) as t FROM expenses"))['t'];

$cat_q = mysqli_query($conn,"SELECT category,COUNT(*) as cnt,COALESCE(SUM(amount),0) as total FROM expenses WHERE expense_date BETWEEN '$date_from' AND '$date_to' GROUP BY category ORDER BY total DESC");
$cat_data=[]; while($r=mysqli_fetch_assoc($cat_q)) $cat_data[]=$r;

// 6-month trend
$trend_labels=[]; $trend_data=[];
for($i=5;$i>=0;$i--){
    $m=date('Y-m',strtotime("-$i months"));
    $trend_labels[]=date('M Y',strtotime("-$i months"));
    $r=mysqli_fetch_assoc(mysqli_query($conn,"SELECT COALESCE(SUM(amount),0) as t FROM expenses WHERE DATE_FORMAT(expense_date,'%Y-%m')='$m'"));
    $trend_data[]=(float)$r['t'];
}

require_once __DIR__ . '/../../includes/header.php';
?>
<style>
.exp-stat{background:var(--card-bg);border:1px solid var(--border-color);border-radius:16px;padding:20px;position:relative;overflow:hidden;}
.exp-stat::before{content:'';position:absolute;top:0;left:0;right:0;height:3px;border-radius:16px 16px 0 0;}
.es1::before{background:linear-gradient(90deg,#ef4444,#ec4899);}
.es2::before{background:linear-gradient(90deg,#f59e0b,#f97316);}
.es3::before{background:linear-gradient(90deg,#8b5cf6,#6366f1);}
.es4::before{background:linear-gradient(90deg,#64748b,#94a3b8);}
.es-icon{width:44px;height:44px;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0;}
.cat-pill{display:flex;align-items:center;justify-content:space-between;padding:10px 14px;border-radius:12px;margin-bottom:8px;background:var(--hover-bg);border:1px solid var(--border-color);}
.cat-bar-wrap{height:6px;background:var(--border-color);border-radius:99px;overflow:hidden;margin-top:5px;}
.cat-bar{height:100%;border-radius:99px;transition:width 1s cubic-bezier(.4,0,.2,1);}
.exp-row{transition:background .15s;}
.exp-row:hover{background:var(--hover-bg);}
</style>

<!-- Header -->
<div class="d-flex align-items-center justify-content-between mb-4">
    <div>
        <h4 class="mb-1">💸 Expenses</h4>
        <p class="text-muted mb-0" style="font-size:14px;">Track and manage shop expenses</p>
    </div>
    <a href="add.php" class="btn btn-primary"><i class="bi bi-plus-circle me-2"></i>Add Expense</a>
</div>

<!-- Stat cards -->
<div class="row g-4 mb-4">
    <div class="col-lg-3 col-md-6"><div class="exp-stat es1">
        <div class="d-flex align-items-center gap-3"><div class="es-icon" style="background:rgba(239,68,68,.12);color:#ef4444;"><i class="bi bi-calendar-day"></i></div><div><div style="font-size:22px;font-weight:800;color:var(--text-main);">₹<?=number_format($today_expenses,0)?></div><div style="font-size:12px;color:var(--text-muted);">Today</div></div></div>
    </div></div>
    <div class="col-lg-3 col-md-6"><div class="exp-stat es2">
        <div class="d-flex align-items-center gap-3"><div class="es-icon" style="background:rgba(245,158,11,.12);color:#f59e0b;"><i class="bi bi-calendar-month"></i></div><div><div style="font-size:22px;font-weight:800;color:var(--text-main);">₹<?=number_format($month_expenses,0)?></div><div style="font-size:12px;color:var(--text-muted);">This Month</div></div></div>
    </div></div>
    <div class="col-lg-3 col-md-6"><div class="exp-stat es3">
        <div class="d-flex align-items-center gap-3"><div class="es-icon" style="background:rgba(139,92,246,.12);color:#8b5cf6;"><i class="bi bi-funnel-fill"></i></div><div><div style="font-size:22px;font-weight:800;color:var(--text-main);">₹<?=number_format($total_expenses,0)?></div><div style="font-size:12px;color:var(--text-muted);">Filtered Period</div></div></div>
    </div></div>
    <div class="col-lg-3 col-md-6"><div class="exp-stat es4">
        <div class="d-flex align-items-center gap-3"><div class="es-icon" style="background:rgba(100,116,139,.12);color:#64748b;"><i class="bi bi-infinity"></i></div><div><div style="font-size:22px;font-weight:800;color:var(--text-main);">₹<?=number_format($alltime,0)?></div><div style="font-size:12px;color:var(--text-muted);">All Time</div></div></div>
    </div></div>
</div>

<!-- Charts + Category breakdown -->
<div class="row g-4 mb-4">
    <!-- 6-month trend -->
    <div class="col-lg-7">
        <div class="card h-100">
            <div class="card-header"><i class="bi bi-graph-down-arrow me-2 text-danger"></i>6-Month Expense Trend</div>
            <div class="card-body"><div style="position:relative;height:220px;"><canvas id="trendChart"></canvas></div></div>
        </div>
    </div>
    <!-- Category breakdown -->
    <div class="col-lg-5">
        <div class="card h-100">
            <div class="card-header"><i class="bi bi-pie-chart-fill me-2 text-warning"></i>By Category</div>
            <div class="card-body">
                <?php
                $cat_colors=['#ef4444','#f59e0b','#8b5cf6','#06b6d4','#10b981','#ec4899','#6366f1'];
                $cat_max = count($cat_data)>0 ? max(array_column($cat_data,'total')) : 1;
                if(count($cat_data)>0):
                    foreach($cat_data as $i=>$c):
                        $pct=$cat_max>0?round(($c['total']/$cat_max)*100):0;
                        $col=$cat_colors[$i%count($cat_colors)];
                ?>
                <div class="cat-pill" style="margin-bottom:10px;">
                    <div style="flex:1;min-width:0;">
                        <div class="d-flex justify-content-between mb-1">
                            <span style="font-size:13px;font-weight:600;color:var(--text-main);"><?=htmlspecialchars($c['category'])?></span>
                            <span style="font-size:12px;font-weight:700;color:<?=$col?>;">₹<?=number_format($c['total'],0)?></span>
                        </div>
                        <div class="cat-bar-wrap"><div class="cat-bar" style="width:0%;background:<?=$col?>;" data-w="<?=$pct?>%"></div></div>
                        <div style="font-size:10px;color:var(--text-muted);margin-top:3px;"><?=$c['cnt']?> entries</div>
                    </div>
                </div>
                <?php endforeach; else:?>
                <div class="text-center py-4 text-muted"><i class="bi bi-pie-chart" style="font-size:36px;opacity:.3;"></i><p class="mt-2 mb-0" style="font-size:13px;">No data in this range</p></div>
                <?php endif;?>
            </div>
        </div>
    </div>
</div>

<!-- Date Filter -->
<div class="card mb-4">
    <div class="card-body">
        <form method="GET" class="row g-3 align-items-end">
            <div class="col-md-4">
                <label class="form-label">From Date</label>
                <input type="date" name="date_from" class="form-control" value="<?=$date_from?>">
            </div>
            <div class="col-md-4">
                <label class="form-label">To Date</label>
                <input type="date" name="date_to" class="form-control" value="<?=$date_to?>">
            </div>
            <div class="col-md-4 d-flex gap-2">
                <button type="submit" class="btn btn-primary flex-fill"><i class="bi bi-funnel me-1"></i>Filter</button>
                <a href="index.php" class="btn btn-light"><i class="bi bi-x"></i></a>
            </div>
        </form>
    </div>
</div>

<!-- Expenses Table -->
<div class="card">
    <div class="card-header d-flex align-items-center justify-content-between">
        <span><i class="bi bi-list-ul me-2 text-danger"></i>Expense Records (<?=mysqli_num_rows($expenses)?>)</span>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table mb-0">
                <thead><tr><th>Date</th><th>Category</th><th>Description</th><th>Amount</th><th>Payment</th><th>Actions</th></tr></thead>
                <tbody>
                <?php if(mysqli_num_rows($expenses)>0):
                    $ei=0;
                    while($exp=mysqli_fetch_assoc($expenses)):
                        $col=$cat_colors[$ei%count($cat_colors)]; $ei++;
                ?>
                <tr class="exp-row">
                    <td style="color:var(--text-muted);font-size:13px;white-space:nowrap;"><?=date('d M Y',strtotime($exp['expense_date']))?></td>
                    <td><span style="display:inline-flex;align-items:center;gap:6px;background:<?=$col?>15;color:<?=$col?>;padding:4px 12px;border-radius:20px;font-size:12px;font-weight:700;"><?=htmlspecialchars($exp['category'])?></span></td>
                    <td style="font-size:13px;color:var(--text-main);"><?=htmlspecialchars($exp['description'] ?? '—')?></td>
                    <td><strong style="color:#ef4444;font-size:15px;">₹<?=number_format($exp['amount'],2)?></strong></td>
                    <td style="font-size:12px;color:var(--text-muted);"><?=$exp['payment_mode']?></td>
                    <td><a href="index.php?delete=<?=$exp['id']?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete this expense?')"><i class="bi bi-trash"></i></a></td>
                </tr>
                <?php endwhile; else:?>
                <tr><td colspan="6" class="text-center py-5" style="color:var(--text-muted);"><i class="bi bi-inbox" style="font-size:40px;opacity:.3;"></i><p class="mt-2 mb-0">No expenses in this range</p></td></tr>
                <?php endif;?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
document.addEventListener('DOMContentLoaded',function(){
    // Animate category bars
    setTimeout(function(){document.querySelectorAll('.cat-bar').forEach(function(b){b.style.width=b.getAttribute('data-w');});},200);
    // Trend chart
    var ctx=document.getElementById('trendChart');
    if(ctx){
        new Chart(ctx.getContext('2d'),{
            type:'bar',
            data:{labels:<?=json_encode($trend_labels)?>,datasets:[{label:'Expenses',data:<?=json_encode($trend_data)?>,backgroundColor:'rgba(239,68,68,0.8)',borderColor:'#ef4444',borderWidth:0,borderRadius:8,borderSkipped:false}]},
            options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false},tooltip:{callbacks:{label:function(c){return' ₹'+c.raw.toLocaleString('en-IN');}}}},scales:{x:{grid:{display:false},ticks:{font:{size:11}}},y:{beginAtZero:true,grid:{color:'rgba(128,128,128,0.08)'},ticks:{callback:function(v){return'₹'+(v>=1000?(v/1000).toFixed(0)+'k':v);}}}}}
        });
    }
});
</script>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
