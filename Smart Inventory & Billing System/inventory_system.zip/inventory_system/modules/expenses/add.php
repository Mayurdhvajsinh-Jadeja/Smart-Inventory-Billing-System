<?php
// modules/expenses/add.php

$page_title = "Add Expense";

// Start session
session_start();
require_once __DIR__ . '/../../config/db.php';

// Database connection
require_once __DIR__ . '/../../includes/auth_check.php';
requireAdmin(); // Only Admin can access

// Handle Form Submit
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    $expense_date = $_POST['expense_date'];
    $category     = trim($_POST['category']);
    $amount       = (float) $_POST['amount'];
    $description  = trim($_POST['description']);
    $payment_mode = $_POST['payment_mode'];
    
    // Validation
    if (empty($expense_date) || empty($category) || $amount <= 0) {
        $_SESSION['error'] = "⚠️ Please fill all required fields!";
    } else {
        $sql  = "INSERT INTO expenses (expense_date, category, amount, description, payment_mode) 
                 VALUES (?, ?, ?, ?, ?)";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "ssdss", $expense_date, $category, $amount, $description, $payment_mode);
        
        if (mysqli_stmt_execute($stmt)) {
            $_SESSION['success'] = "✅ Expense added successfully!";
            header("Location: index.php");
            exit();
        } else {
            $_SESSION['error'] = "❌ Failed to add expense!";
        }
    }
}

// Include Header
require_once __DIR__ . '/../../includes/header.php';
?>

<!-- ══════════════ ADD EXPENSE PAGE ══════════════ -->

<!-- Page Header -->
<div class="d-flex align-items-center justify-content-between mb-4">
    <div>
        <h4 class="mb-1">➕ Add New Expense</h4>
        <p class="text-muted mb-0" style="font-size:14px;">
            Record shop expenses for accurate profit calculation
        </p>
    </div>
    <a href="index.php" class="btn btn-light" style="border-radius:10px;">
        <i class="bi bi-arrow-left me-2"></i>Back to Expenses
    </a>
</div>

<!-- Alerts -->


<!-- Add Expense Form -->
<div class="card">
    <div class="card-header">
        <i class="bi bi-cash-stack me-2 text-danger"></i>Expense Details
    </div>
    <div class="card-body">
        <form method="POST" action="">
            <div class="row g-4">

                <!-- Expense Date -->
                <div class="col-md-6">
                    <label class="form-label" style="font-weight:600;">
                        Expense Date <span class="text-danger">*</span>
                    </label>
                    <input 
                        type="date" 
                        name="expense_date" 
                        class="form-control" 
                        value="<?= date('Y-m-d') ?>"
                        max="<?= date('Y-m-d') ?>"
                        style="border-radius:10px; padding:12px 15px;"
                        required
                    >
                </div>

                <!-- Category -->
                <div class="col-md-6">
                    <label class="form-label" style="font-weight:600;">
                        Category <span class="text-danger">*</span>
                    </label>
                    <select name="category" class="form-select" 
                            style="border-radius:10px; padding:12px 15px;" required>
                        <option value="">-- Select Category --</option>
                        <option value="Rent">🏠 Rent</option>
                        <option value="Electricity Bill">💡 Electricity Bill</option>
                        <option value="Water Bill">💧 Water Bill</option>
                        <option value="Internet Bill">🌐 Internet Bill</option>
                        <option value="Staff Salary">👥 Staff Salary</option>
                        <option value="Transportation">🚚 Transportation</option>
                        <option value="Maintenance">🔧 Maintenance</option>
                        <option value="Office Supplies">📦 Office Supplies</option>
                        <option value="Marketing">📢 Marketing</option>
                        <option value="Insurance">🛡️ Insurance</option>
                        <option value="Taxes">💼 Taxes</option>
                        <option value="Other">📝 Other</option>
                    </select>
                </div>

                <!-- Amount -->
                <div class="col-md-6">
                    <label class="form-label" style="font-weight:600;">
                        Amount (₹) <span class="text-danger">*</span>
                    </label>
                    <input 
                        type="number" 
                        name="amount" 
                        class="form-control" 
                        placeholder="Enter expense amount"
                        style="border-radius:10px; padding:12px 15px;"
                        step="0.01" 
                        min="0.01"
                        required
                    >
                </div>

                <!-- Payment Mode -->
                <div class="col-md-6">
                    <label class="form-label" style="font-weight:600;">
                        Payment Mode
                    </label>
                    <select name="payment_mode" class="form-select" 
                            style="border-radius:10px; padding:12px 15px;">
                        <option value="Cash">💵 Cash</option>
                        <option value="Card">💳 Card</option>
                        <option value="UPI">📱 UPI</option>
                        <option value="Bank Transfer">🏦 Bank Transfer</option>
                        <option value="Online">🌐 Online</option>
                        <option value="Cheque">📄 Cheque</option>
                    </select>
                </div>

                <!-- Description -->
                <div class="col-12">
                    <label class="form-label" style="font-weight:600;">
                        Description / Notes
                    </label>
                    <textarea 
                        name="description" 
                        class="form-control" 
                        rows="3"
                        placeholder="Enter expense details or notes..."
                        style="border-radius:10px; padding:12px 15px;"
                    ></textarea>
                </div>

                <!-- Submit Button -->
                <div class="col-12">
                    <hr>
                    <button type="submit" class="btn btn-danger btn-lg" style="border-radius:10px;">
                        <i class="bi bi-check-circle me-2"></i>Save Expense
                    </button>
                    <a href="index.php" class="btn btn-light btn-lg ms-2" style="border-radius:10px;">
                        Cancel
                    </a>
                </div>

            </div>
        </form>
    </div>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>