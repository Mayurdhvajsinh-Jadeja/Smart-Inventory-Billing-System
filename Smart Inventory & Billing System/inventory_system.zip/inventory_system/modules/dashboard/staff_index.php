<?php
// modules/dashboard/staff_index.php
$page_title = "Staff Dashboard";
session_start();
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../includes/header.php';

$today          = date('Y-m-d');
$total_products = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as t FROM products WHERE quantity > 0"))['t'];
$low_stock      = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as t FROM products WHERE quantity < 5"))['t'];
$today_bills    = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as t FROM bills WHERE DATE(bill_date)='$today'"))['t'];
$today_revenue  = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COALESCE(SUM(total_amount),0) as t FROM bills WHERE DATE(bill_date)='$today'"))['t'];
$recent         = mysqli_query($conn,"SELECT * FROM bills WHERE DATE(bill_date)='$today' ORDER BY id DESC LIMIT 5");
?>
<style>
.staff-hero{background:linear-gradient(135deg,#0f172a 0%,#1e293b 50%,#1e1b4b 100%);border-radius:24px;padding:32px 36px;color:white;position:relative;overflow:hidden;margin-bottom:24px;}
.staff-hero::before{content:'';position:absolute;top:-40px;right:-40px;width:200px;height:200px;background:radial-gradient(circle,rgba(99,102,241,.3) 0%,transparent 70%);}
.sh-c{position:relative;z-index:1;}
.act-card{background:var(--card-bg);border:1px solid var(--border-color);border-radius:20px;padding:28px;text-align:center;text-decoration:none;display:flex;flex-direction:column;align-items:center;gap:14px;transition:all .35s cubic-bezier(.4,0,.2,1);height:100%;}
.act-card:hover{transform:translateY(-6px);box-shadow:0 20px 50px rgba(0,0,0,.12);}
.act-icon{width:72px;height:72px;border-radius:20px;display:flex;align-items:center;justify-content:center;font-size:30px;}
.act-card.bill-card .act-icon{background:linear-gradient(135deg,rgba(99,102,241,.15),rgba(139,92,246,.15));color:#6366f1;}
.act-card.bill-card:hover{border-color:#6366f1;box-shadow:0 20px 50px rgba(99,102,241,.15);}
.act-card.stock-card .act-icon{background:linear-gradient(135deg,rgba(16,185,129,.15),rgba(6,182,212,.15));color:#10b981;}
.act-card.stock-card:hover{border-color:#10b981;box-shadow:0 20px 50px rgba(16,185,129,.15);}
.act-title{font-size:17px;font-weight:700;color:var(--text-main);}
.act-sub{font-size:13px;color:var(--text-muted);}
.act-btn{width:100%;padding:11px;border-radius:12px;font-size:14px;font-weight:700;border:none;cursor:pointer;text-decoration:none;display:inline-flex;align-items:center;justify-content:center;gap:8px;transition:all .3s;margin-top:4px;}
.act-btn.btn-indigo{background:linear-gradient(135deg,#6366f1,#4f46e5);color:white;}
.act-btn.btn-emerald{background:linear-gradient(135deg,#10b981,#059669);color:white;}
.act-btn:hover{transform:translateY(-1px);box-shadow:0 8px 20px rgba(0,0,0,.15);}
.stat-mini{background:var(--card-bg);border:1px solid var(--border-color);border-radius:14px;padding:18px 20px;display:flex;align-items:center;gap:14px;}
.sm-icon{width:44px;height:44px;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0;}
.sm-val{font-size:22px;font-weight:800;color:var(--text-main);line-height:1;}
.sm-lbl{font-size:12px;color:var(--text-muted);margin-top:2px;}
.br{display:flex;align-items:center;gap:12px;padding:10px 0;border-bottom:1px solid var(--border-color);}
.br:last-child{border-bottom:none;}
</style>

<!-- Hero -->
<div class="staff-hero">
    <div class="sh-c">
        <div style="font-size:11px;font-weight:700;letter-spacing:2px;text-transform:uppercase;opacity:.5;margin-bottom:5px;">Staff Dashboard</div>
        <h1 style="font-size:26px;font-weight:800;margin:0 0 3px;">Hello, <?= htmlspecialchars($_SESSION['user_name']) ?> 👋</h1>
        <p style="font-size:13px;opacity:.5;margin:0 0 16px;"><?= date('l, d F Y') ?> — Ready to make sales?</p>
        <div class="d-flex gap-3 flex-wrap">
            <div style="background:rgba(255,255,255,.1);border-radius:10px;padding:8px 14px;font-size:13px;color:rgba(255,255,255,.8);">
                <i class="bi bi-receipt me-1"></i> <?= $today_bills ?> bills today
            </div>
            <div style="background:rgba(16,185,129,.2);border:1px solid rgba(16,185,129,.3);border-radius:10px;padding:8px 14px;font-size:13px;color:#6ee7b7;">
                <i class="bi bi-currency-rupee me-1"></i> ₹<?= number_format($today_revenue,0) ?> today
            </div>
            <?php if($low_stock>0):?>
            <div style="background:rgba(245,158,11,.2);border:1px solid rgba(245,158,11,.3);border-radius:10px;padding:8px 14px;font-size:13px;color:#fcd34d;">
                <i class="bi bi-exclamation-triangle me-1"></i> <?= $low_stock ?> low stock
            </div>
            <?php endif;?>
        </div>
    </div>
</div>

<!-- Stats row -->
<div class="row g-3 mb-4">
    <div class="col-6 col-md-3">
        <div class="stat-mini">
            <div class="sm-icon" style="background:rgba(99,102,241,.12);color:#6366f1;"><i class="bi bi-receipt-cutoff"></i></div>
            <div><div class="sm-val"><?= $today_bills ?></div><div class="sm-lbl">Today's Bills</div></div>
        </div>
    </div>
    <div class="col-6 col-md-3">
        <div class="stat-mini">
            <div class="sm-icon" style="background:rgba(16,185,129,.12);color:#10b981;"><i class="bi bi-currency-rupee"></i></div>
            <div><div class="sm-val">₹<?= number_format($today_revenue,0) ?></div><div class="sm-lbl">Today's Sales</div></div>
        </div>
    </div>
    <div class="col-6 col-md-3">
        <div class="stat-mini">
            <div class="sm-icon" style="background:rgba(6,182,212,.12);color:#06b6d4;"><i class="bi bi-box-seam-fill"></i></div>
            <div><div class="sm-val"><?= $total_products ?></div><div class="sm-lbl">In-Stock Products</div></div>
        </div>
    </div>
    <div class="col-6 col-md-3">
        <div class="stat-mini">
            <div class="sm-icon" style="background:rgba(239,68,68,.12);color:#ef4444;"><i class="bi bi-exclamation-triangle"></i></div>
            <div><div class="sm-val"><?= $low_stock ?></div><div class="sm-lbl">Low Stock</div></div>
        </div>
    </div>
</div>

<!-- Action cards -->
<div class="row g-4 mb-4">
    <div class="col-md-6">
        <div class="act-card bill-card">
            <div class="act-icon"><i class="bi bi-receipt-cutoff"></i></div>
            <div class="act-title">Create New Bill</div>
            <div class="act-sub">Generate an invoice for a customer. Search by phone to auto-fill customer details.</div>
            <a href="<?= $base_url ?>/modules/billing/create.php" class="act-btn btn-indigo w-100">
                <i class="bi bi-plus-lg"></i> Create Bill
            </a>
        </div>
    </div>
    <div class="col-md-6">
        <div class="act-card stock-card">
            <div class="act-icon"><i class="bi bi-box-seam"></i></div>
            <div class="act-title">Check Inventory</div>
            <div class="act-sub">View all products, check stock levels, search by name or category before billing.</div>
            <a href="<?= $base_url ?>/modules/products/index.php" class="act-btn btn-emerald w-100">
                <i class="bi bi-search"></i> View Products
            </a>
        </div>
    </div>
</div>

<!-- Today's bills -->
<div class="card">
    <div class="card-header d-flex align-items-center justify-content-between">
        <span><i class="bi bi-clock-history me-2 text-primary"></i>Today's Bills</span>
        <a href="<?= $base_url ?>/modules/billing/list.php" class="btn btn-sm btn-primary">All Bills</a>
    </div>
    <div class="card-body" style="<?= mysqli_num_rows($recent)>0 ? 'padding:0;' : '' ?>">
        <?php if(mysqli_num_rows($recent)>0):
            $cols=['#6366f1','#10b981','#f59e0b','#ef4444','#06b6d4'];$i=0;?>
        <div style="padding:8px 20px;">
        <?php while($b=mysqli_fetch_assoc($recent)):$col=$cols[$i%5];$i++;$sc=$b['status']==='Paid'?'background:#d1fae5;color:#065f46;':($b['status']==='Partial'?'background:#fef3c7;color:#92400e;':'background:#fee2e2;color:#991b1b;');?>
        <div class="br">
            <div style="width:34px;height:34px;border-radius:10px;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:12px;background:<?=$col?>22;color:<?=$col?>;flex-shrink:0;"><?=strtoupper(substr($b['customer_name'],0,1))?></div>
            <div style="flex:1;min-width:0;"><div style="font-size:13px;font-weight:600;color:var(--text-main);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;"><?=htmlspecialchars($b['customer_name'])?></div><div style="font-size:11px;color:var(--text-muted);">#<?=str_pad($b['id'],4,'0',STR_PAD_LEFT)?> · <?=$b['payment_mode']?></div></div>
            <div style="font-size:13px;font-weight:700;color:#10b981;">₹<?=number_format($b['total_amount'],0)?></div>
            <span style="font-size:10px;font-weight:700;padding:2px 8px;border-radius:20px;flex-shrink:0;<?=$sc?>"><?=$b['status']?></span>
            <a href="<?=$base_url?>/modules/billing/view.php?id=<?=$b['id']?>" style="color:var(--primary);font-size:18px;"><i class="bi bi-eye"></i></a>
        </div>
        <?php endwhile;?>
        </div>
        <?php else:?>
        <div class="text-center py-5">
            <i class="bi bi-receipt" style="font-size:48px;color:#cbd5e1;"></i>
            <p class="mt-3 mb-0 text-muted">No bills created today yet.</p>
            <a href="<?=$base_url?>/modules/billing/create.php" class="btn btn-primary mt-3"><i class="bi bi-plus-circle me-2"></i>Create First Bill</a>
        </div>
        <?php endif;?>
    </div>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
