<?php
// modules/dashboard/index.php
$page_title = "Dashboard";

require_once __DIR__ . '/../../config/db.php';

if (session_status() === PHP_SESSION_NONE) session_start();

if (isset($_SESSION['user_role']) && $_SESSION['user_role'] !== 'admin') {
    header("Location: staff_index.php"); exit();
}

$today      = date('Y-m-d');
$this_month = date('Y-m');

$total_products = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as t FROM products"))['t'];
$total_customers= mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as t FROM customers"))['t'];
$today_sales    = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COALESCE(SUM(total_amount),0) as t FROM bills WHERE DATE(bill_date)='$today'"))['t'];
$today_bills    = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as t FROM bills WHERE DATE(bill_date)='$today'"))['t'];
$total_bills    = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as t FROM bills"))['t'];
$low_stock      = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as t FROM products WHERE quantity < 5"))['t'];
$out_of_stock   = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as t FROM products WHERE quantity = 0"))['t'];

$month_revenue  = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COALESCE(SUM(total_amount),0) as t FROM bills WHERE DATE_FORMAT(bill_date,'%Y-%m')='$this_month'"))['t'];
$month_purchases= mysqli_fetch_assoc(mysqli_query($conn, "SELECT COALESCE(SUM(total_amount),0) as t FROM purchases WHERE DATE_FORMAT(purchase_date,'%Y-%m')='$this_month'"))['t'];
$month_expenses = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COALESCE(SUM(amount),0) as t FROM expenses WHERE DATE_FORMAT(expense_date,'%Y-%m')='$this_month'"))['t'];
$month_cogs     = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COALESCE(SUM(bi.quantity*p.cost_price),0) as t FROM bill_items bi LEFT JOIN products p ON bi.product_id=p.id LEFT JOIN bills b ON bi.bill_id=b.id WHERE DATE_FORMAT(b.bill_date,'%Y-%m')='$this_month'"))['t'];
$month_net      = ($month_revenue - $month_cogs) - $month_expenses;

// Prev month for growth %
$prev_month     = date('Y-m', strtotime('-1 month'));
$prev_revenue   = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COALESCE(SUM(total_amount),0) as t FROM bills WHERE DATE_FORMAT(bill_date,'%Y-%m')='$prev_month'"))['t'];
$revenue_growth = $prev_revenue > 0 ? round((($month_revenue - $prev_revenue) / $prev_revenue) * 100, 1) : 0;

// Recent bills (last 7)
$recent_bills = mysqli_query($conn, "SELECT * FROM bills ORDER BY id DESC LIMIT 7");

// Low stock products
$low_stock_products = mysqli_query($conn, "SELECT * FROM products WHERE quantity < 5 ORDER BY quantity ASC LIMIT 6");

// 30-day sales trend (line chart)
$trend_labels = []; $trend_data = [];
for ($i = 29; $i >= 0; $i--) {
    $d = date('Y-m-d', strtotime("-$i days"));
    $trend_labels[] = date('d M', strtotime($d));
    $trend_data[$d] = 0;
}
$trend_q = mysqli_query($conn, "SELECT DATE(bill_date) as d, COALESCE(SUM(total_amount),0) as s FROM bills WHERE bill_date >= DATE_SUB('$today', INTERVAL 29 DAY) GROUP BY DATE(bill_date)");
while ($r = mysqli_fetch_assoc($trend_q)) { if (isset($trend_data[$r['d']])) $trend_data[$r['d']] = (float)$r['s']; }

// 7-day cash flow
$days=[]; $cash_in_data=[]; $cash_out_data=[];
for ($i=6;$i>=0;$i--) { $d=date('Y-m-d',strtotime("-$i days")); $days[]=date('d M',strtotime($d)); $cash_in_data[$d]=0; $cash_out_data[$d]=0; }
$ci = mysqli_query($conn,"SELECT DATE(bill_date) as d,COALESCE(SUM(total_amount),0) as a FROM bills WHERE bill_date>=DATE_SUB('$today',INTERVAL 6 DAY) GROUP BY DATE(bill_date)");
while($r=mysqli_fetch_assoc($ci)){if(isset($cash_in_data[$r['d']]))$cash_in_data[$r['d']]=(float)$r['a'];}
$cop=mysqli_query($conn,"SELECT DATE(purchase_date) as d,COALESCE(SUM(total_amount),0) as a FROM purchases WHERE purchase_date>=DATE_SUB('$today',INTERVAL 6 DAY) GROUP BY DATE(purchase_date)");
while($r=mysqli_fetch_assoc($cop)){if(isset($cash_out_data[$r['d']]))$cash_out_data[$r['d']]+=(float)$r['a'];}
$coe=mysqli_query($conn,"SELECT DATE(expense_date) as d,COALESCE(SUM(amount),0) as a FROM expenses WHERE expense_date>=DATE_SUB('$today',INTERVAL 6 DAY) GROUP BY DATE(expense_date)");
while($r=mysqli_fetch_assoc($coe)){if(isset($cash_out_data[$r['d']]))$cash_out_data[$r['d']]+=(float)$r['a'];}
$total_cash_in=array_sum($cash_in_data); $total_cash_out=array_sum($cash_out_data); $cash_position=$total_cash_in-$total_cash_out;

// Top products
$top_q=mysqli_query($conn,"SELECT p.product_name,SUM(bi.quantity) as s FROM bill_items bi JOIN products p ON bi.product_id=p.id GROUP BY bi.product_id ORDER BY s DESC LIMIT 6");
$top_labels=[]; $top_data=[]; $top_max=1;
while($r=mysqli_fetch_assoc($top_q)){$top_labels[]=$r['product_name'];$top_data[]=(int)$r['s'];}
if(count($top_data)>0) $top_max=max($top_data);

// Stock health
$total_stock_q = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as t FROM products"))['t'];
$healthy_stock = $total_stock_q - $low_stock;
$stock_health_pct = $total_stock_q > 0 ? round(($healthy_stock / $total_stock_q) * 100) : 100;

require_once __DIR__ . '/../../includes/header.php';
?>

<style>
/* ═══════════════════════════════════════════
   DASHBOARD REDESIGN — ULTRA PREMIUM
═══════════════════════════════════════════ */

/* Hero Banner */
.db-hero {
    background: linear-gradient(135deg, #0f172a 0%, #1e1b4b 40%, #312e81 70%, #4c1d95 100%);
    border-radius: 24px;
    padding: 36px 40px;
    color: white;
    position: relative;
    overflow: hidden;
    margin-bottom: 28px;
}
.db-hero::before {
    content:'';position:absolute;top:-80px;right:-80px;width:320px;height:320px;
    background:radial-gradient(circle,rgba(139,92,246,.35) 0%,transparent 70%);
    animation:heroOrb 8s ease-in-out infinite;
}
.db-hero::after {
    content:'';position:absolute;bottom:-60px;left:30%;width:200px;height:200px;
    background:radial-gradient(circle,rgba(236,72,153,.2) 0%,transparent 70%);
    animation:heroOrb 6s ease-in-out infinite reverse;
}
@keyframes heroOrb { 0%,100%{transform:translate(0,0) scale(1)} 50%{transform:translate(20px,-20px) scale(1.1)} }

.db-hero-content { position:relative;z-index:1; }
.db-hero-greeting { font-size:13px;font-weight:600;letter-spacing:2px;text-transform:uppercase;opacity:.6;margin-bottom:6px; }
.db-hero-name { font-size:30px;font-weight:800;margin:0 0 4px;letter-spacing:-0.5px; }
.db-hero-date { font-size:14px;opacity:.5;margin:0; }

.db-hero-pills { display:flex;gap:10px;flex-wrap:wrap;margin-top:20px; }
.db-hero-pill {
    background:rgba(255,255,255,.12);
    border:1px solid rgba(255,255,255,.15);
    backdrop-filter:blur(10px);
    border-radius:50px;padding:7px 16px;
    font-size:12px;font-weight:600;color:white;
    display:flex;align-items:center;gap:6px;
}
.db-hero-pill i { font-size:13px; }
.db-hero-pill.green  { background:rgba(16,185,129,.25); border-color:rgba(16,185,129,.4); }
.db-hero-pill.yellow { background:rgba(245,158,11,.25); border-color:rgba(245,158,11,.4); }
.db-hero-pill.red    { background:rgba(239,68,68,.25);  border-color:rgba(239,68,68,.4); }

.db-hero-cta {
    background:linear-gradient(135deg,#6366f1,#ec4899);
    border:none;color:white;border-radius:12px;
    padding:10px 22px;font-size:14px;font-weight:700;
    cursor:pointer;transition:all .3s;text-decoration:none;
    display:inline-flex;align-items:center;gap:8px;
}
.db-hero-cta:hover { transform:translateY(-2px);box-shadow:0 10px 30px rgba(99,102,241,.5);color:white; }

/* KPI Cards */
.kpi-card {
    border-radius:20px;padding:24px;position:relative;overflow:hidden;
    cursor:pointer;transition:all .4s cubic-bezier(.4,0,.2,1);
    border:1px solid transparent;
    height:100%;
}
.kpi-card:hover { transform:translateY(-6px);box-shadow:0 20px 60px rgba(0,0,0,.15); }
.kpi-card::after {
    content:'';position:absolute;bottom:-30px;right:-30px;
    width:100px;height:100px;border-radius:50%;
    background:rgba(255,255,255,.08);
    transition:transform .4s;
}
.kpi-card:hover::after { transform:scale(1.5); }

.kpi-card.blue   { background:linear-gradient(135deg,#6366f1,#4f46e5); }
.kpi-card.green  { background:linear-gradient(135deg,#10b981,#059669); }
.kpi-card.amber  { background:linear-gradient(135deg,#f59e0b,#d97706); }
.kpi-card.rose   { background:linear-gradient(135deg,#f43f5e,#e11d48); }
.kpi-card.cyan   { background:linear-gradient(135deg,#06b6d4,#0891b2); }
.kpi-card.purple { background:linear-gradient(135deg,#8b5cf6,#7c3aed); }

.kpi-icon { width:52px;height:52px;border-radius:14px;background:rgba(255,255,255,.2);
    display:flex;align-items:center;justify-content:center;font-size:22px;color:white;margin-bottom:16px; }
.kpi-value { font-size:32px;font-weight:800;color:white;letter-spacing:-1px;line-height:1; }
.kpi-label { font-size:13px;color:rgba(255,255,255,.7);margin-top:6px;font-weight:500; }
.kpi-badge {
    display:inline-flex;align-items:center;gap:3px;
    background:rgba(255,255,255,.2);border-radius:50px;
    padding:3px 10px;font-size:11px;color:white;font-weight:600;margin-top:10px;
}

/* Finance Cards */
.finance-card {
    background:var(--card-bg);border:1px solid var(--border-color);
    border-radius:18px;padding:22px;height:100%;
    transition:all .3s ease;position:relative;overflow:hidden;
}
.finance-card::before {
    content:'';position:absolute;left:0;top:0;bottom:0;width:4px;border-radius:4px 0 0 4px;
}
.finance-card.fc-green::before  { background:linear-gradient(180deg,#10b981,#059669); }
.finance-card.fc-purple::before { background:linear-gradient(180deg,#6366f1,#4f46e5); }
.finance-card.fc-red::before    { background:linear-gradient(180deg,#ef4444,#dc2626); }
.finance-card.fc-profit::before { background:linear-gradient(180deg,#f59e0b,#d97706); }
.finance-card:hover { transform:translateY(-3px);box-shadow:var(--shadow-md); }
.fc-icon { width:44px;height:44px;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:18px; }
.fc-label { font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:var(--text-muted);margin-bottom:4px; }
.fc-value { font-size:24px;font-weight:800;line-height:1; }
.fc-sub   { font-size:12px;color:var(--text-muted);margin-top:4px; }

/* Chart Cards */
.chart-card {
    background:var(--card-bg);border:1px solid var(--border-color);
    border-radius:20px;overflow:hidden;height:100%;
}
.chart-card-header {
    padding:20px 24px 0;display:flex;align-items:center;justify-content:space-between;
}
.chart-card-title { font-size:15px;font-weight:700;color:var(--text-main); }
.chart-card-sub   { font-size:12px;color:var(--text-muted); }
.chart-card-body  { padding:16px 24px 24px; }

/* Top Products Bar */
.top-prod-item { margin-bottom:14px; }
.top-prod-name { font-size:13px;font-weight:600;color:var(--text-main);margin-bottom:5px;
    white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:180px; }
.top-prod-bar-wrap { height:8px;background:var(--hover-bg);border-radius:99px;overflow:hidden; }
.top-prod-bar { height:100%;border-radius:99px;transition:width 1.2s cubic-bezier(.4,0,.2,1); }
.top-prod-meta { display:flex;justify-content:space-between;margin-top:3px; }
.top-prod-count { font-size:11px;font-weight:700;color:var(--text-muted); }

/* Stock Gauge */
.gauge-wrap { position:relative;width:160px;height:80px;margin:0 auto 8px; }
.gauge-arc-bg { fill:none;stroke:var(--hover-bg);stroke-width:14;stroke-linecap:round; }
.gauge-arc    { fill:none;stroke-width:14;stroke-linecap:round;transition:stroke-dasharray 1.5s cubic-bezier(.4,0,.2,1); }
.gauge-pct    { position:absolute;bottom:0;left:50%;transform:translateX(-50%);
    font-size:28px;font-weight:800;color:var(--text-main);line-height:1; }
.gauge-label  { text-align:center;font-size:12px;color:var(--text-muted);margin-top:4px; }

/* Recent Bills */
.bill-row { display:flex;align-items:center;gap:14px;padding:12px 0;border-bottom:1px solid var(--border-color); }
.bill-row:last-child { border-bottom:none; }
.bill-avatar { width:38px;height:38px;border-radius:12px;display:flex;align-items:center;justify-content:center;
    font-weight:800;font-size:14px;flex-shrink:0; }
.bill-info { flex:1;min-width:0; }
.bill-name { font-size:13px;font-weight:600;color:var(--text-main);white-space:nowrap;overflow:hidden;text-overflow:ellipsis; }
.bill-date { font-size:11px;color:var(--text-muted); }
.bill-amount { font-size:14px;font-weight:700;color:#10b981;flex-shrink:0; }
.bill-badge { font-size:10px;font-weight:700;padding:3px 9px;border-radius:20px;flex-shrink:0; }

/* Quick Actions */
.qa-grid { display:grid;grid-template-columns:repeat(5,1fr);gap:14px; }
.qa-btn {
    display:flex;flex-direction:column;align-items:center;justify-content:center;
    gap:10px;padding:20px 10px;border-radius:18px;text-decoration:none;
    border:2px solid var(--border-color);background:var(--card-bg);
    transition:all .35s cubic-bezier(.4,0,.2,1);position:relative;overflow:hidden;
}
.qa-btn::before {
    content:'';position:absolute;inset:0;opacity:0;transition:opacity .3s;
}
.qa-btn:hover { transform:translateY(-5px);border-color:transparent; }
.qa-btn:hover::before { opacity:1; }
.qa-btn.qa-blue::before   { background:linear-gradient(135deg,rgba(99,102,241,.12),rgba(139,92,246,.12)); }
.qa-btn.qa-green::before  { background:linear-gradient(135deg,rgba(16,185,129,.12),rgba(6,182,212,.12)); }
.qa-btn.qa-amber::before  { background:linear-gradient(135deg,rgba(245,158,11,.12),rgba(249,115,22,.12)); }
.qa-btn.qa-rose::before   { background:linear-gradient(135deg,rgba(244,63,94,.12),rgba(236,72,153,.12)); }
.qa-btn.qa-slate::before  { background:linear-gradient(135deg,rgba(100,116,139,.12),rgba(71,85,105,.12)); }
.qa-btn:hover.qa-blue   { box-shadow:0 12px 40px rgba(99,102,241,.2); }
.qa-btn:hover.qa-green  { box-shadow:0 12px 40px rgba(16,185,129,.2); }
.qa-btn:hover.qa-amber  { box-shadow:0 12px 40px rgba(245,158,11,.2); }
.qa-btn:hover.qa-rose   { box-shadow:0 12px 40px rgba(244,63,94,.2); }
.qa-btn:hover.qa-slate  { box-shadow:0 12px 40px rgba(100,116,139,.2); }
.qa-icon { width:50px;height:50px;border-radius:14px;display:flex;align-items:center;justify-content:center;font-size:22px;position:relative;z-index:1; }
.qa-blue  .qa-icon { background:linear-gradient(135deg,#6366f1,#4f46e5);color:white; }
.qa-green .qa-icon { background:linear-gradient(135deg,#10b981,#059669);color:white; }
.qa-amber .qa-icon { background:linear-gradient(135deg,#f59e0b,#d97706);color:white; }
.qa-rose  .qa-icon { background:linear-gradient(135deg,#f43f5e,#e11d48);color:white; }
.qa-slate .qa-icon { background:linear-gradient(135deg,#64748b,#475569);color:white; }
.qa-label { font-size:12px;font-weight:700;color:var(--text-main);position:relative;z-index:1;text-align:center; }
.qa-sub   { font-size:10px;color:var(--text-muted);position:relative;z-index:1;text-align:center; }

/* Section titles */
.section-title { font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:2px;color:var(--text-muted);margin-bottom:16px; }

/* Low stock pills */
.stock-pill {
    display:flex;align-items:center;justify-content:space-between;
    padding:10px 14px;border-radius:12px;margin-bottom:8px;
    background:var(--hover-bg);border:1px solid var(--border-color);
}
.stock-pill:last-child { margin-bottom:0; }
.stock-pill-name { font-size:13px;font-weight:600;color:var(--text-main); }
.stock-pill-qty  { font-size:13px;font-weight:800; }

@media(max-width:992px){ .qa-grid{grid-template-columns:repeat(3,1fr);} }
@media(max-width:576px){ .qa-grid{grid-template-columns:repeat(2,1fr);} .db-hero{padding:24px 20px;} .kpi-value{font-size:24px;} }
</style>

<!-- ═══════════════════ HERO BANNER ═══════════════════ -->
<div class="db-hero mb-4">
    <div class="db-hero-content">
        <div class="row align-items-center">
            <div class="col-lg-8">
                <div class="db-hero-greeting">Welcome back</div>
                <h1 class="db-hero-name"><?= htmlspecialchars($_SESSION['user_name']) ?> 👋</h1>
                <p class="db-hero-date"><?= date('l, d F Y') ?></p>
                <div class="db-hero-pills mt-3">
                    <div class="db-hero-pill green">
                        <i class="bi bi-currency-rupee"></i>
                        Today ₹<?= number_format($today_sales, 0) ?>
                    </div>
                    <div class="db-hero-pill <?= $today_bills > 0 ? '' : 'yellow' ?>">
                        <i class="bi bi-receipt-cutoff"></i>
                        <?= $today_bills ?> bill<?= $today_bills != 1 ? 's' : '' ?> today
                    </div>
                    <?php if ($low_stock > 0) : ?>
                    <div class="db-hero-pill red">
                        <i class="bi bi-exclamation-triangle-fill"></i>
                        <?= $low_stock ?> low stock
                    </div>
                    <?php endif; ?>
                    <div class="db-hero-pill">
                        <i class="bi bi-people-fill"></i>
                        <?= $total_customers ?> customers
                    </div>
                </div>
            </div>
            <div class="col-lg-4 text-lg-end mt-3 mt-lg-0">
                <a href="<?= $base_url ?>/modules/billing/create.php" class="db-hero-cta">
                    <i class="bi bi-plus-circle-fill"></i> New Bill
                </a>
            </div>
        </div>
    </div>
</div>

<!-- ═══════════════════ KPI CARDS ═══════════════════ -->
<div class="row g-4 mb-4">
    <div class="col-xl-2 col-lg-4 col-md-6">
        <div class="kpi-card blue">
            <div class="kpi-icon"><i class="bi bi-box-seam-fill"></i></div>
            <div class="kpi-value counter" data-target="<?= $total_products ?>"><?= $total_products ?></div>
            <div class="kpi-label">Total Products</div>
            <div class="kpi-badge"><i class="bi bi-tags-fill"></i> In catalogue</div>
        </div>
    </div>
    <div class="col-xl-2 col-lg-4 col-md-6">
        <div class="kpi-card green">
            <div class="kpi-icon"><i class="bi bi-currency-rupee"></i></div>
            <div class="kpi-value">₹<?= number_format($today_sales, 0) ?></div>
            <div class="kpi-label">Today's Revenue</div>
            <div class="kpi-badge"><i class="bi bi-receipt"></i> <?= $today_bills ?> bills</div>
        </div>
    </div>
    <div class="col-xl-2 col-lg-4 col-md-6">
        <div class="kpi-card purple">
            <div class="kpi-icon"><i class="bi bi-receipt-cutoff"></i></div>
            <div class="kpi-value counter" data-target="<?= $total_bills ?>"><?= $total_bills ?></div>
            <div class="kpi-label">Total Bills</div>
            <div class="kpi-badge"><i class="bi bi-calendar3"></i> All time</div>
        </div>
    </div>
    <div class="col-xl-2 col-lg-4 col-md-6">
        <div class="kpi-card cyan">
            <div class="kpi-icon"><i class="bi bi-people-fill"></i></div>
            <div class="kpi-value counter" data-target="<?= $total_customers ?>"><?= $total_customers ?></div>
            <div class="kpi-label">Customers</div>
            <div class="kpi-badge"><i class="bi bi-person-check"></i> Registered</div>
        </div>
    </div>
    <div class="col-xl-2 col-lg-4 col-md-6">
        <div class="kpi-card amber">
            <div class="kpi-icon"><i class="bi bi-graph-up-arrow"></i></div>
            <div class="kpi-value">₹<?= number_format($month_revenue, 0) ?></div>
            <div class="kpi-label">Month Revenue</div>
            <div class="kpi-badge">
                <i class="bi bi-arrow-<?= $revenue_growth >= 0 ? 'up' : 'down' ?>"></i>
                <?= abs($revenue_growth) ?>% vs last
            </div>
        </div>
    </div>
    <div class="col-xl-2 col-lg-4 col-md-6">
        <div class="kpi-card rose">
            <div class="kpi-icon"><i class="bi bi-exclamation-triangle-fill"></i></div>
            <div class="kpi-value counter" data-target="<?= $low_stock ?>"><?= $low_stock ?></div>
            <div class="kpi-label">Low Stock</div>
            <div class="kpi-badge"><i class="bi bi-x-circle"></i> <?= $out_of_stock ?> out</div>
        </div>
    </div>
</div>

<!-- ═══════════════════ FINANCE CARDS ═══════════════════ -->
<div class="row g-4 mb-4">
    <div class="col-lg-3 col-md-6">
        <div class="finance-card fc-green">
            <div class="d-flex align-items-center justify-content-between mb-3">
                <div class="fc-icon" style="background:rgba(16,185,129,.15);color:#10b981;">
                    <i class="bi bi-graph-up-arrow"></i>
                </div>
                <span style="font-size:11px;background:#d1fae5;color:#065f46;padding:4px 10px;border-radius:20px;font-weight:700;">
                    ↑ Revenue
                </span>
            </div>
            <div class="fc-label">Monthly Revenue</div>
            <div class="fc-value" style="color:#10b981;">₹<?= number_format($month_revenue, 0) ?></div>
            <div class="fc-sub">Money coming in this month</div>
        </div>
    </div>
    <div class="col-lg-3 col-md-6">
        <div class="finance-card fc-purple">
            <div class="d-flex align-items-center justify-content-between mb-3">
                <div class="fc-icon" style="background:rgba(99,102,241,.15);color:#6366f1;">
                    <i class="bi bi-box-arrow-in-down"></i>
                </div>
                <span style="font-size:11px;background:#e0e7ff;color:#3730a3;padding:4px 10px;border-radius:20px;font-weight:700;">
                    ↓ Stock
                </span>
            </div>
            <div class="fc-label">Stock Purchased</div>
            <div class="fc-value" style="color:#6366f1;">₹<?= number_format($month_purchases, 0) ?></div>
            <div class="fc-sub">Paid to suppliers</div>
        </div>
    </div>
    <div class="col-lg-3 col-md-6">
        <div class="finance-card fc-red">
            <div class="d-flex align-items-center justify-content-between mb-3">
                <div class="fc-icon" style="background:rgba(239,68,68,.15);color:#ef4444;">
                    <i class="bi bi-wallet2"></i>
                </div>
                <span style="font-size:11px;background:#fee2e2;color:#991b1b;padding:4px 10px;border-radius:20px;font-weight:700;">
                    ↓ Expense
                </span>
            </div>
            <div class="fc-label">Shop Expenses</div>
            <div class="fc-value" style="color:#ef4444;">₹<?= number_format($month_expenses, 0) ?></div>
            <div class="fc-sub">Rent, salary, bills</div>
        </div>
    </div>
    <div class="col-lg-3 col-md-6">
        <div class="finance-card fc-profit">
            <div class="d-flex align-items-center justify-content-between mb-3">
                <div class="fc-icon" style="background:rgba(245,158,11,.15);color:#f59e0b;">
                    <i class="bi bi-trophy-fill"></i>
                </div>
                <span style="font-size:11px;background:<?= $month_net>=0 ? '#d1fae5;color:#065f46' : '#fee2e2;color:#991b1b' ?>;padding:4px 10px;border-radius:20px;font-weight:700;">
                    <?= $month_net >= 0 ? '✅ Profit' : '⚠️ Loss' ?>
                </span>
            </div>
            <div class="fc-label">Net Profit</div>
            <div class="fc-value" style="color:<?= $month_net>=0 ? '#f59e0b' : '#ef4444' ?>;">
                ₹<?= number_format(abs($month_net), 0) ?>
            </div>
            <div class="fc-sub"><?= $month_net >= 0 ? 'Great job this month!' : 'Review your expenses' ?></div>
        </div>
    </div>
</div>

<!-- ═══════════════════ CHARTS ROW ═══════════════════ -->
<div class="row g-4 mb-4">

    <!-- 30-Day Sales Trend -->
    <div class="col-lg-8">
        <div class="chart-card">
            <div class="chart-card-header">
                <div>
                    <div class="chart-card-title"><i class="bi bi-activity me-2 text-primary"></i>30-Day Sales Trend</div>
                    <div class="chart-card-sub">Daily revenue over the last 30 days</div>
                </div>
                <div style="font-size:20px;font-weight:800;color:var(--text-main);">
                    ₹<?= number_format(array_sum($trend_data), 0) ?>
                </div>
            </div>
            <div class="chart-card-body">
                <div style="position:relative;height:240px;">
                    <canvas id="trendChart"></canvas>
                </div>
            </div>
        </div>
    </div>

    <!-- Top Products Ranking -->
    <div class="col-lg-4">
        <div class="chart-card">
            <div class="chart-card-header">
                <div>
                    <div class="chart-card-title"><i class="bi bi-trophy-fill me-2 text-warning"></i>Top Products</div>
                    <div class="chart-card-sub">By units sold</div>
                </div>
            </div>
            <div class="chart-card-body">
                <?php
                $bar_colors = ['#6366f1','#10b981','#f59e0b','#ef4444','#06b6d4','#ec4899'];
                if (count($top_labels) > 0) :
                    foreach ($top_labels as $i => $lbl) :
                        $pct = $top_max > 0 ? round(($top_data[$i] / $top_max) * 100) : 0;
                        $col = $bar_colors[$i % count($bar_colors)];
                ?>
                <div class="top-prod-item">
                    <div class="d-flex justify-content-between align-items-center mb-1">
                        <span class="top-prod-name"><?= htmlspecialchars($lbl) ?></span>
                        <span style="font-size:12px;font-weight:800;color:<?= $col ?>;"><?= $top_data[$i] ?></span>
                    </div>
                    <div class="top-prod-bar-wrap">
                        <div class="top-prod-bar" style="width:0%;background:<?= $col ?>;"
                             data-width="<?= $pct ?>%"></div>
                    </div>
                </div>
                <?php endforeach;
                else : ?>
                    <div class="text-center py-4 text-muted">
                        <i class="bi bi-bar-chart" style="font-size:36px;opacity:.3;"></i>
                        <p class="mt-2 mb-0" style="font-size:13px;">No sales yet</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- ═══════════════════ MIDDLE ROW ═══════════════════ -->
<div class="row g-4 mb-4">

    <!-- 7-Day Cash Flow -->
    <div class="col-lg-5">
        <div class="chart-card">
            <div class="chart-card-header">
                <div>
                    <div class="chart-card-title"><i class="bi bi-bar-chart-fill me-2 text-success"></i>7-Day Cash Flow</div>
                    <div class="chart-card-sub">Sales vs Outgoing</div>
                </div>
                <div>
                    <div style="font-size:11px;color:var(--text-muted);text-align:right;">Net Position</div>
                    <div style="font-size:18px;font-weight:800;color:<?= $cash_position>=0 ? '#10b981' : '#ef4444' ?>;">
                        ₹<?= number_format($cash_position, 0) ?>
                    </div>
                </div>
            </div>
            <div class="chart-card-body">
                <div style="position:relative;height:200px;">
                    <canvas id="cashFlowChart"></canvas>
                </div>
            </div>
        </div>
    </div>

    <!-- Stock Health Gauge -->
    <div class="col-lg-3">
        <div class="chart-card h-100">
            <div class="chart-card-header">
                <div class="chart-card-title"><i class="bi bi-shield-check me-2 text-cyan"></i>Stock Health</div>
            </div>
            <div class="chart-card-body text-center">
                <!-- SVG Semi-circle gauge -->
                <div class="gauge-wrap">
                    <svg viewBox="0 0 160 80" width="160" height="80">
                        <path class="gauge-arc-bg" d="M 15 75 A 65 65 0 0 1 145 75"/>
                        <path class="gauge-arc" id="gaugeArc"
                              d="M 15 75 A 65 65 0 0 1 145 75"
                              stroke="<?= $stock_health_pct >= 80 ? '#10b981' : ($stock_health_pct >= 50 ? '#f59e0b' : '#ef4444') ?>"
                              stroke-dasharray="0 204"
                              style="stroke-dasharray:0 204;"/>
                    </svg>
                    <div class="gauge-pct" id="gaugePct">0%</div>
                </div>
                <div class="gauge-label" style="font-weight:700;font-size:14px;color:<?= $stock_health_pct >= 80 ? '#10b981' : ($stock_health_pct >= 50 ? '#f59e0b' : '#ef4444') ?>;">
                    <?= $stock_health_pct >= 80 ? 'Healthy' : ($stock_health_pct >= 50 ? 'Moderate' : 'Critical') ?>
                </div>
                <div class="row g-2 mt-3">
                    <div class="col-4">
                        <div style="background:rgba(16,185,129,.1);border-radius:10px;padding:8px 4px;text-align:center;">
                            <div style="font-size:16px;font-weight:800;color:#10b981;"><?= $total_stock_q - $low_stock ?></div>
                            <div style="font-size:9px;color:var(--text-muted);font-weight:600;">OK</div>
                        </div>
                    </div>
                    <div class="col-4">
                        <div style="background:rgba(245,158,11,.1);border-radius:10px;padding:8px 4px;text-align:center;">
                            <div style="font-size:16px;font-weight:800;color:#f59e0b;"><?= $low_stock - $out_of_stock ?></div>
                            <div style="font-size:9px;color:var(--text-muted);font-weight:600;">LOW</div>
                        </div>
                    </div>
                    <div class="col-4">
                        <div style="background:rgba(239,68,68,.1);border-radius:10px;padding:8px 4px;text-align:center;">
                            <div style="font-size:16px;font-weight:800;color:#ef4444;"><?= $out_of_stock ?></div>
                            <div style="font-size:9px;color:var(--text-muted);font-weight:600;">OUT</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Recent Bills -->
    <div class="col-lg-4">
        <div class="chart-card h-100">
            <div class="chart-card-header">
                <div class="chart-card-title"><i class="bi bi-receipt me-2 text-primary"></i>Recent Bills</div>
                <a href="<?= $base_url ?>/modules/billing/list.php"
                   style="font-size:12px;font-weight:600;color:var(--primary);text-decoration:none;">
                    View all <i class="bi bi-arrow-right"></i>
                </a>
            </div>
            <div class="chart-card-body" style="padding-top:12px;">
                <?php
                $av_colors = ['#6366f1','#10b981','#f59e0b','#ef4444','#06b6d4','#ec4899','#8b5cf6'];
                $bi = 0;
                if ($recent_bills && mysqli_num_rows($recent_bills) > 0) :
                    while ($bill = mysqli_fetch_assoc($recent_bills)) :
                        $col = $av_colors[$bi % count($av_colors)]; $bi++;
                        $status_style = $bill['status'] === 'Paid'
                            ? 'background:#d1fae5;color:#065f46;'
                            : ($bill['status'] === 'Partial' ? 'background:#fef3c7;color:#92400e;' : 'background:#fee2e2;color:#991b1b;');
                ?>
                <div class="bill-row">
                    <div class="bill-avatar" style="background:<?= $col ?>22;color:<?= $col ?>;">
                        <?= strtoupper(substr($bill['customer_name'], 0, 1)) ?>
                    </div>
                    <div class="bill-info">
                        <div class="bill-name"><?= htmlspecialchars($bill['customer_name']) ?></div>
                        <div class="bill-date"><?= date('d M', strtotime($bill['bill_date'])) ?> · #<?= str_pad($bill['id'],4,'0',STR_PAD_LEFT) ?></div>
                    </div>
                    <div class="bill-amount">₹<?= number_format($bill['total_amount'], 0) ?></div>
                    <div class="bill-badge" style="<?= $status_style ?>"><?= $bill['status'] ?></div>
                </div>
                <?php endwhile; else : ?>
                    <div class="text-center py-4 text-muted">
                        <i class="bi bi-inbox" style="font-size:36px;opacity:.3;"></i>
                        <p class="mt-2 mb-0" style="font-size:13px;">No bills yet</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- ═══════════════════ BOTTOM ROW ═══════════════════ -->
<div class="row g-4 mb-4">

    <!-- Quick Actions -->
    <div class="col-lg-8">
        <div class="chart-card">
            <div class="chart-card-header mb-3">
                <div class="chart-card-title"><i class="bi bi-lightning-charge-fill me-2 text-warning"></i>Quick Actions</div>
            </div>
            <div class="chart-card-body" style="padding-top:0;">
                <div class="qa-grid">
                    <a href="<?= $base_url ?>/modules/billing/create.php" class="qa-btn qa-blue">
                        <div class="qa-icon"><i class="bi bi-plus-circle-fill"></i></div>
                        <div class="qa-label">New Bill</div>
                        <div class="qa-sub">Create invoice</div>
                    </a>
                    <a href="<?= $base_url ?>/modules/purchases/create.php" class="qa-btn qa-green">
                        <div class="qa-icon"><i class="bi bi-box-arrow-in-down"></i></div>
                        <div class="qa-label">Purchase</div>
                        <div class="qa-sub">Add stock</div>
                    </a>
                    <a href="<?= $base_url ?>/modules/expenses/add.php" class="qa-btn qa-amber">
                        <div class="qa-icon"><i class="bi bi-wallet2"></i></div>
                        <div class="qa-label">Expense</div>
                        <div class="qa-sub">Record cost</div>
                    </a>
                    <a href="<?= $base_url ?>/modules/reports/financial.php" class="qa-btn qa-rose">
                        <div class="qa-icon"><i class="bi bi-bar-chart-fill"></i></div>
                        <div class="qa-label">Reports</div>
                        <div class="qa-sub">View analytics</div>
                    </a>
                    <a href="backup.php" class="qa-btn qa-slate">
                        <div class="qa-icon"><i class="bi bi-database-down"></i></div>
                        <div class="qa-label">Backup</div>
                        <div class="qa-sub">Export SQL</div>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Low Stock Alert -->
    <div class="col-lg-4">
        <div class="chart-card h-100">
            <div class="chart-card-header">
                <div class="chart-card-title">
                    <i class="bi bi-exclamation-triangle-fill me-2 text-danger"></i>Low Stock Alert
                </div>
                <a href="<?= $base_url ?>/modules/products/index.php"
                   style="font-size:12px;font-weight:600;color:#ef4444;text-decoration:none;">
                    Manage <i class="bi bi-arrow-right"></i>
                </a>
            </div>
            <div class="chart-card-body" style="padding-top:12px;">
                <?php
                $ls_colors = ['#ef4444','#f59e0b','#f59e0b','#f59e0b','#f59e0b','#f59e0b'];
                if ($low_stock_products && mysqli_num_rows($low_stock_products) > 0) :
                    $lsi = 0;
                    while ($p = mysqli_fetch_assoc($low_stock_products)) :
                        $lc = $p['quantity'] == 0 ? '#ef4444' : '#f59e0b';
                ?>
                <div class="stock-pill">
                    <div class="d-flex align-items-center gap-2">
                        <div style="width:8px;height:8px;border-radius:50%;background:<?= $lc ?>;flex-shrink:0;"></div>
                        <span class="stock-pill-name"><?= htmlspecialchars($p['product_name']) ?></span>
                    </div>
                    <div class="d-flex align-items-center gap-2">
                        <span class="stock-pill-qty" style="color:<?= $lc ?>;"><?= $p['quantity'] ?></span>
                        <span style="font-size:10px;font-weight:700;padding:2px 8px;border-radius:20px;
                                     background:<?= $p['quantity']==0 ? 'rgba(239,68,68,.15)' : 'rgba(245,158,11,.15)' ?>;
                                     color:<?= $lc ?>;">
                            <?= $p['quantity'] == 0 ? 'OUT' : 'LOW' ?>
                        </span>
                    </div>
                </div>
                <?php $lsi++; endwhile;
                else : ?>
                    <div class="text-center py-4">
                        <i class="bi bi-check-circle-fill" style="font-size:36px;color:#10b981;"></i>
                        <p class="mt-2 mb-0" style="font-size:13px;color:var(--text-muted);">All items stocked up!</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- ═══════════════════ SCRIPTS ═══════════════════ -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {

    // ── Animated Counters ──────────────────────────
    document.querySelectorAll('.counter').forEach(function(el) {
        var target = +el.getAttribute('data-target');
        if (target === 0) return;
        var step = target / 60;
        var cur  = 0;
        function tick() {
            cur += step;
            if (cur < target) { el.textContent = Math.floor(cur); requestAnimationFrame(tick); }
            else { el.textContent = target; }
        }
        tick();
    });

    // ── Animated Top Product Bars ──────────────────
    setTimeout(function() {
        document.querySelectorAll('.top-prod-bar').forEach(function(bar) {
            bar.style.width = bar.getAttribute('data-width');
        });
    }, 300);

    // ── Stock Health Gauge ─────────────────────────
    var pct   = <?= $stock_health_pct ?>;
    var arc   = document.getElementById('gaugeArc');
    var pctEl = document.getElementById('gaugePct');
    var total = 204; // arc length
    setTimeout(function() {
        var filled = (pct / 100) * total;
        arc.style.strokeDasharray = filled + ' ' + total;
        var cur = 0;
        var step = pct / 60;
        function countUp() {
            cur += step;
            if (cur < pct) { pctEl.textContent = Math.floor(cur) + '%'; requestAnimationFrame(countUp); }
            else { pctEl.textContent = pct + '%'; }
        }
        countUp();
    }, 400);

    // ── 30-Day Trend Line Chart ────────────────────
    var trendCtx = document.getElementById('trendChart');
    if (trendCtx) {
        var trendLabels = <?= json_encode($trend_labels) ?>;
        var trendData   = <?= json_encode(array_values($trend_data)) ?>;
        new Chart(trendCtx.getContext('2d'), {
            type: 'line',
            data: {
                labels: trendLabels,
                datasets: [{
                    label: 'Sales',
                    data: trendData,
                    borderColor: '#6366f1',
                    backgroundColor: function(ctx) {
                        var g = ctx.chart.ctx.createLinearGradient(0,0,0,240);
                        g.addColorStop(0,'rgba(99,102,241,0.25)');
                        g.addColorStop(1,'rgba(99,102,241,0)');
                        return g;
                    },
                    borderWidth: 2.5,
                    pointRadius: 0,
                    pointHoverRadius: 5,
                    pointHoverBackgroundColor: '#6366f1',
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true, maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        mode: 'index', intersect: false,
                        callbacks: { label: function(c){ return ' ₹' + c.raw.toLocaleString('en-IN'); } }
                    }
                },
                scales: {
                    x: {
                        grid: { display: false },
                        ticks: {
                            maxTicksLimit: 8,
                            font: { size: 11 },
                            color: 'rgba(128,128,128,0.7)'
                        }
                    },
                    y: {
                        beginAtZero: true,
                        grid: { color: 'rgba(128,128,128,0.08)' },
                        ticks: {
                            font: { size: 11 },
                            color: 'rgba(128,128,128,0.7)',
                            callback: function(v){ return '₹' + (v >= 1000 ? (v/1000).toFixed(0)+'k' : v); }
                        }
                    }
                }
            }
        });
    }

    // ── 7-Day Cash Flow Bar Chart ──────────────────
    var cfCtx = document.getElementById('cashFlowChart');
    if (cfCtx) {
        var cfLabels  = <?= json_encode($days) ?>;
        var cfCashIn  = <?= json_encode(array_values($cash_in_data)) ?>;
        var cfCashOut = <?= json_encode(array_values($cash_out_data)) ?>;
        new Chart(cfCtx.getContext('2d'), {
            type: 'bar',
            data: {
                labels: cfLabels,
                datasets: [
                    { label:'Cash In',  data:cfCashIn,  backgroundColor:'rgba(16,185,129,0.85)', borderColor:'#10b981', borderWidth:0, borderRadius:6, borderSkipped:false },
                    { label:'Cash Out', data:cfCashOut, backgroundColor:'rgba(239,68,68,0.85)',  borderColor:'#ef4444', borderWidth:0, borderRadius:6, borderSkipped:false }
                ]
            },
            options: {
                responsive: true, maintainAspectRatio: false,
                plugins: {
                    legend: { position:'bottom', labels:{ font:{ size:11 }, padding:12, boxWidth:10 } },
                    tooltip: { callbacks:{ label:function(c){ return ' ₹'+c.raw.toLocaleString('en-IN'); } } }
                },
                scales: {
                    x: { grid:{ display:false }, ticks:{ font:{ size:11 } } },
                    y: { beginAtZero:true, grid:{ color:'rgba(128,128,128,0.08)' }, ticks:{ callback:function(v){ return '₹'+(v>=1000?(v/1000).toFixed(0)+'k':v); } } }
                }
            }
        });
    }
});
</script>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
