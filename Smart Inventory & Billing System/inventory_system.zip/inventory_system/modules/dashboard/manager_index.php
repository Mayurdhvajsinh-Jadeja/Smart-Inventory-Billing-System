<?php
// modules/dashboard/manager_index.php
$page_title = "Manager Dashboard";
session_start();
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../includes/auth_check.php';

if (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin') { header("Location: index.php"); exit(); }
if (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'staff')  { header("Location: staff_index.php"); exit(); }

$today=$_d=date('Y-m-d'); $this_month=date('Y-m');
$total_products =mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as t FROM products"))['t'];
$total_customers=mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as t FROM customers"))['t'];
$today_sales    =mysqli_fetch_assoc(mysqli_query($conn,"SELECT COALESCE(SUM(total_amount),0) as t FROM bills WHERE DATE(bill_date)='$today'"))['t'];
$today_bills    =mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as t FROM bills WHERE DATE(bill_date)='$today'"))['t'];
$total_bills    =mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as t FROM bills"))['t'];
$low_stock      =mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as t FROM products WHERE quantity < 5"))['t'];
$month_revenue  =mysqli_fetch_assoc(mysqli_query($conn,"SELECT COALESCE(SUM(total_amount),0) as t FROM bills WHERE DATE_FORMAT(bill_date,'%Y-%m')='$this_month'"))['t'];
$pending_bills  =mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as t FROM bills WHERE status != 'Paid'"))['t'];

$days=[];$sales_data=[];
for($i=6;$i>=0;$i--){$d=date('Y-m-d',strtotime("-$i days"));$days[]=date('D',strtotime($d));$sales_data[$d]=0;}
$sq=mysqli_query($conn,"SELECT DATE(bill_date) as d,COALESCE(SUM(total_amount),0) as s FROM bills WHERE bill_date>=DATE_SUB('$today',INTERVAL 6 DAY) GROUP BY DATE(bill_date)");
while($r=mysqli_fetch_assoc($sq)){if(isset($sales_data[$r['d']]))$sales_data[$r['d']]=(float)$r['s'];}

$recent=mysqli_query($conn,"SELECT * FROM bills ORDER BY id DESC LIMIT 8");
$top_q=mysqli_query($conn,"SELECT p.product_name,SUM(bi.quantity) as s FROM bill_items bi JOIN products p ON bi.product_id=p.id GROUP BY bi.product_id ORDER BY s DESC LIMIT 5");
$top_labels=[];$top_data=[];$top_max=1;
while($r=mysqli_fetch_assoc($top_q)){$top_labels[]=$r['product_name'];$top_data[]=(int)$r['s'];}
if(count($top_data))$top_max=max($top_data);
$ls_q=mysqli_query($conn,"SELECT * FROM products WHERE quantity < 5 ORDER BY quantity ASC LIMIT 5");

require_once __DIR__ . '/../../includes/header.php';
?>
<style>
.db-hero{background:linear-gradient(135deg,#1e1b4b 0%,#312e81 50%,#4c1d95 100%);border-radius:24px;padding:32px 36px;color:white;position:relative;overflow:hidden;margin-bottom:24px;}
.db-hero::before{content:'';position:absolute;top:-60px;right:-60px;width:260px;height:260px;background:radial-gradient(circle,rgba(139,92,246,.35) 0%,transparent 70%);}
.db-hero-c{position:relative;z-index:1;}
.mgr-pill{display:inline-flex;align-items:center;gap:6px;background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.2);border-radius:50px;padding:6px 14px;font-size:12px;font-weight:600;color:white;}
.kc{border-radius:18px;padding:22px;height:100%;transition:all .35s;border:1px solid transparent;position:relative;overflow:hidden;}
.kc:hover{transform:translateY(-5px);box-shadow:0 20px 50px rgba(0,0,0,.12);}
.kc.blue{background:linear-gradient(135deg,#6366f1,#4f46e5);}
.kc.green{background:linear-gradient(135deg,#10b981,#059669);}
.kc.purple{background:linear-gradient(135deg,#8b5cf6,#7c3aed);}
.kc.amber{background:linear-gradient(135deg,#f59e0b,#d97706);}
.kc.rose{background:linear-gradient(135deg,#f43f5e,#e11d48);}
.kc.cyan{background:linear-gradient(135deg,#06b6d4,#0891b2);}
.ki{width:48px;height:48px;border-radius:12px;background:rgba(255,255,255,.2);display:flex;align-items:center;justify-content:center;font-size:20px;color:white;margin-bottom:14px;}
.kv{font-size:28px;font-weight:800;color:white;letter-spacing:-1px;line-height:1;}
.kl{font-size:12px;color:rgba(255,255,255,.7);margin-top:5px;}
.cc{background:var(--card-bg);border:1px solid var(--border-color);border-radius:18px;overflow:hidden;height:100%;}
.cc-h{padding:18px 22px 0;display:flex;align-items:center;justify-content:space-between;}
.cc-t{font-size:14px;font-weight:700;color:var(--text-main);}
.cc-s{font-size:11px;color:var(--text-muted);}
.cc-b{padding:14px 22px 22px;}
.br{display:flex;align-items:center;gap:12px;padding:10px 0;border-bottom:1px solid var(--border-color);}
.br:last-child{border-bottom:none;}
.ba{width:36px;height:36px;border-radius:10px;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:13px;flex-shrink:0;}
.bi2{flex:1;min-width:0;}
.bn{font-size:13px;font-weight:600;color:var(--text-main);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.bd{font-size:11px;color:var(--text-muted);}
.bam{font-size:13px;font-weight:700;color:#10b981;flex-shrink:0;}
.sb{font-size:10px;font-weight:700;padding:2px 8px;border-radius:20px;flex-shrink:0;}
.qa-g{display:grid;grid-template-columns:repeat(2,1fr);gap:10px;}
.qa-b{display:flex;flex-direction:column;align-items:center;gap:7px;padding:16px 8px;border-radius:14px;text-decoration:none;border:2px solid var(--border-color);background:var(--card-bg);transition:all .3s;}
.qa-b:hover{transform:translateY(-3px);}
.qi{width:42px;height:42px;border-radius:11px;display:flex;align-items:center;justify-content:center;font-size:18px;}
.q1 .qi{background:linear-gradient(135deg,#6366f1,#4f46e5);color:white;}
.q2 .qi{background:linear-gradient(135deg,#10b981,#059669);color:white;}
.q3 .qi{background:linear-gradient(135deg,#f59e0b,#d97706);color:white;}
.q4 .qi{background:linear-gradient(135deg,#06b6d4,#0891b2);color:white;}
.ql{font-size:11px;font-weight:700;color:var(--text-main);text-align:center;}
.tp-bw{height:7px;background:var(--hover-bg);border-radius:99px;overflow:hidden;margin-top:4px;}
.tp-b{height:100%;border-radius:99px;transition:width 1.2s cubic-bezier(.4,0,.2,1);}
.sp{display:flex;align-items:center;justify-content:space-between;padding:9px 13px;border-radius:11px;margin-bottom:7px;background:var(--hover-bg);border:1px solid var(--border-color);}
</style>

<div class="db-hero">
    <div class="db-hero-c">
        <div class="row align-items-center">
            <div class="col-lg-8">
                <div style="font-size:11px;font-weight:700;letter-spacing:2px;text-transform:uppercase;opacity:.55;margin-bottom:5px;">Manager Dashboard</div>
                <h1 style="font-size:28px;font-weight:800;margin:0 0 3px;"><?= htmlspecialchars($_SESSION['user_name']) ?> 👋</h1>
                <p style="font-size:13px;opacity:.5;margin:0;"><?= date('l, d F Y') ?></p>
                <div class="d-flex gap-2 flex-wrap mt-3">
                    <div class="mgr-pill"><i class="bi bi-currency-rupee"></i> Today ₹<?= number_format($today_sales,0) ?></div>
                    <div class="mgr-pill"><i class="bi bi-receipt-cutoff"></i> <?= $today_bills ?> bills today</div>
                    <?php if($low_stock>0):?><div class="mgr-pill" style="background:rgba(239,68,68,.2);border-color:rgba(239,68,68,.4);"><i class="bi bi-exclamation-triangle-fill"></i> <?=$low_stock?> low stock</div><?php endif;?>
                </div>
            </div>
            <div class="col-lg-4 text-lg-end mt-3 mt-lg-0">
                <a href="<?=$base_url?>/modules/billing/create.php" style="background:linear-gradient(135deg,#8b5cf6,#ec4899);border:none;color:white;border-radius:12px;padding:10px 22px;font-size:14px;font-weight:700;text-decoration:none;display:inline-flex;align-items:center;gap:8px;">
                    <i class="bi bi-plus-circle-fill"></i> New Bill
                </a>
            </div>
        </div>
    </div>
</div>

<div class="row g-4 mb-4">
    <div class="col-xl-2 col-lg-4 col-md-6"><div class="kc blue"><div class="ki"><i class="bi bi-box-seam-fill"></i></div><div class="kv counter" data-target="<?=$total_products?>"><?=$total_products?></div><div class="kl">Total Products</div></div></div>
    <div class="col-xl-2 col-lg-4 col-md-6"><div class="kc green"><div class="ki"><i class="bi bi-currency-rupee"></i></div><div class="kv">₹<?=number_format($today_sales,0)?></div><div class="kl">Today's Revenue</div></div></div>
    <div class="col-xl-2 col-lg-4 col-md-6"><div class="kc purple"><div class="ki"><i class="bi bi-receipt-cutoff"></i></div><div class="kv counter" data-target="<?=$total_bills?>"><?=$total_bills?></div><div class="kl">Total Bills</div></div></div>
    <div class="col-xl-2 col-lg-4 col-md-6"><div class="kc cyan"><div class="ki"><i class="bi bi-people-fill"></i></div><div class="kv counter" data-target="<?=$total_customers?>"><?=$total_customers?></div><div class="kl">Customers</div></div></div>
    <div class="col-xl-2 col-lg-4 col-md-6"><div class="kc amber"><div class="ki"><i class="bi bi-graph-up-arrow"></i></div><div class="kv">₹<?=number_format($month_revenue,0)?></div><div class="kl">Month Revenue</div></div></div>
    <div class="col-xl-2 col-lg-4 col-md-6"><div class="kc rose"><div class="ki"><i class="bi bi-clock-history"></i></div><div class="kv counter" data-target="<?=$pending_bills?>"><?=$pending_bills?></div><div class="kl">Pending Bills</div></div></div>
</div>

<div class="row g-4 mb-4">
    <div class="col-lg-8"><div class="cc">
        <div class="cc-h"><div><div class="cc-t"><i class="bi bi-bar-chart-fill me-2 text-primary"></i>7-Day Sales</div><div class="cc-s">Daily revenue this week</div></div><div style="font-size:18px;font-weight:800;color:var(--text-main);">₹<?=number_format(array_sum($sales_data),0)?></div></div>
        <div class="cc-b"><div style="position:relative;height:220px;"><canvas id="salesChart"></canvas></div></div>
    </div></div>
    <div class="col-lg-4"><div class="cc">
        <div class="cc-h"><div class="cc-t"><i class="bi bi-trophy-fill me-2 text-warning"></i>Top Products</div></div>
        <div class="cc-b" style="padding-top:12px;">
            <?php $bc=['#6366f1','#10b981','#f59e0b','#ef4444','#06b6d4'];
            foreach($top_labels as $i=>$lbl):$pct=$top_max>0?round(($top_data[$i]/$top_max)*100):0;$col=$bc[$i%5];?>
            <div style="margin-bottom:12px;"><div class="d-flex justify-content-between"><span style="font-size:12px;font-weight:600;color:var(--text-main);max-width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;"><?=htmlspecialchars($lbl)?></span><span style="font-size:11px;font-weight:800;color:<?=$col?>;"><?=$top_data[$i]?></span></div><div class="tp-bw"><div class="tp-b" style="width:0%;background:<?=$col?>;" data-width="<?=$pct?>%"></div></div></div>
            <?php endforeach;if(!count($top_labels)):?><div class="text-center py-3 text-muted" style="font-size:13px;">No data yet</div><?php endif;?>
        </div>
    </div></div>
</div>

<div class="row g-4 mb-4">
    <div class="col-lg-5"><div class="cc">
        <div class="cc-h"><div class="cc-t"><i class="bi bi-receipt me-2 text-primary"></i>Recent Bills</div><a href="<?=$base_url?>/modules/billing/list.php" style="font-size:12px;font-weight:600;color:var(--primary);text-decoration:none;">View all</a></div>
        <div class="cc-b" style="padding-top:10px;">
            <?php $avc=['#6366f1','#10b981','#f59e0b','#ef4444','#06b6d4','#ec4899','#8b5cf6'];$bi=0;
            if($recent&&mysqli_num_rows($recent)>0):while($b=mysqli_fetch_assoc($recent)):$col=$avc[$bi%7];$bi++;$sc=$b['status']==='Paid'?'background:#d1fae5;color:#065f46;':($b['status']==='Partial'?'background:#fef3c7;color:#92400e;':'background:#fee2e2;color:#991b1b;');?>
            <div class="br"><div class="ba" style="background:<?=$col?>22;color:<?=$col?>;"><?=strtoupper(substr($b['customer_name'],0,1))?></div><div class="bi2"><div class="bn"><?=htmlspecialchars($b['customer_name'])?></div><div class="bd"><?=date('d M',strtotime($b['bill_date']))?> · #<?=str_pad($b['id'],4,'0',STR_PAD_LEFT)?></div></div><div class="bam">₹<?=number_format($b['total_amount'],0)?></div><div class="sb" style="<?=$sc?>"><?=$b['status']?></div></div>
            <?php endwhile;else:?><div class="text-center py-4 text-muted"><i class="bi bi-inbox" style="font-size:32px;opacity:.3;"></i></div><?php endif;?>
        </div>
    </div></div>
    <div class="col-lg-3"><div class="cc h-100">
        <div class="cc-h"><div class="cc-t"><i class="bi bi-exclamation-triangle-fill me-2 text-danger"></i>Low Stock</div><a href="<?=$base_url?>/modules/products/index.php" style="font-size:12px;font-weight:600;color:#ef4444;text-decoration:none;">Manage</a></div>
        <div class="cc-b" style="padding-top:10px;">
            <?php if($ls_q&&mysqli_num_rows($ls_q)>0):while($p=mysqli_fetch_assoc($ls_q)):$lc=$p['quantity']==0?'#ef4444':'#f59e0b';?>
            <div class="sp"><div class="d-flex align-items-center gap-2"><div style="width:7px;height:7px;border-radius:50%;background:<?=$lc?>;flex-shrink:0;"></div><span style="font-size:12px;font-weight:600;color:var(--text-main);max-width:110px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;"><?=htmlspecialchars($p['product_name'])?></span></div><span style="font-size:12px;font-weight:800;color:<?=$lc?>;"><?=$p['quantity']?></span></div>
            <?php endwhile;else:?><div class="text-center py-4"><i class="bi bi-check-circle-fill" style="font-size:32px;color:#10b981;"></i><p class="mt-2 mb-0" style="font-size:12px;color:var(--text-muted);">All stocked up!</p></div><?php endif;?>
        </div>
    </div></div>
    <div class="col-lg-4"><div class="cc h-100">
        <div class="cc-h"><div class="cc-t"><i class="bi bi-lightning-charge-fill me-2 text-warning"></i>Quick Actions</div></div>
        <div class="cc-b" style="padding-top:14px;"><div class="qa-g">
            <a href="<?=$base_url?>/modules/billing/create.php" class="qa-b q1"><div class="qi"><i class="bi bi-plus-circle-fill"></i></div><div class="ql">New Bill</div></a>
            <a href="<?=$base_url?>/modules/products/index.php" class="qa-b q2"><div class="qi"><i class="bi bi-box-seam-fill"></i></div><div class="ql">Products</div></a>
            <a href="<?=$base_url?>/modules/customers/index.php" class="qa-b q3"><div class="qi"><i class="bi bi-people-fill"></i></div><div class="ql">Customers</div></a>
            <a href="<?=$base_url?>/modules/reports/index.php" class="qa-b q4"><div class="qi"><i class="bi bi-bar-chart-fill"></i></div><div class="ql">Reports</div></a>
        </div></div>
    </div></div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
document.addEventListener('DOMContentLoaded',function(){
    document.querySelectorAll('.counter').forEach(function(el){var t=+el.getAttribute('data-target'),s=t/60,c=0;if(!t)return;(function tick(){c+=s;if(c<t){el.textContent=Math.floor(c);requestAnimationFrame(tick);}else el.textContent=t;})();});
    setTimeout(function(){document.querySelectorAll('.tp-b').forEach(function(b){b.style.width=b.getAttribute('data-width');});},300);
    var ctx=document.getElementById('salesChart');
    if(ctx){new Chart(ctx.getContext('2d'),{type:'bar',data:{labels:<?=json_encode($days)?>,datasets:[{label:'Sales',data:<?=json_encode(array_values($sales_data))?>,backgroundColor:'rgba(139,92,246,0.85)',borderColor:'#8b5cf6',borderWidth:0,borderRadius:8,borderSkipped:false}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false},tooltip:{callbacks:{label:function(c){return' ₹'+c.raw.toLocaleString('en-IN');}}}},scales:{x:{grid:{display:false},ticks:{font:{size:11}}},y:{beginAtZero:true,grid:{color:'rgba(128,128,128,0.08)'},ticks:{callback:function(v){return'₹'+(v>=1000?(v/1000).toFixed(0)+'k':v);}}}}}});}
});
</script>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
                