<?php
// modules/users/profile.php
$page_title = "My Profile";
session_start();
require_once __DIR__ . '/../../config/db.php';

$id = $_SESSION['user_id'];
$user = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM users WHERE id = $id"));

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $new_pass = trim($_POST['password']);

    $sql = "UPDATE users SET name=?, email=? WHERE id=?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "ssi", $name, $email, $id);
    
    if (mysqli_stmt_execute($stmt)) {
        // Update Session Name
        $_SESSION['user_name'] = $name;
        $_SESSION['user_email'] = $email;

        if (!empty($new_pass)) {
            $hash = password_hash($new_pass, PASSWORD_DEFAULT);
            mysqli_query($conn, "UPDATE users SET password='$hash' WHERE id=$id");
        }
        $_SESSION['success'] = "✅ Profile updated successfully!";
        header("Location: profile.php");
        exit();
    }
}

require_once __DIR__ . '/../../includes/header.php';
?>

<div class="row justify-content-center">
    <div class="col-md-6">
        
        <?php if (isset($_SESSION['success'])) : ?>
            <div class="alert alert-success alert-dismissible fade show">
                <?= $_SESSION['success']; unset($_SESSION['success']); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-header">
                <i class="bi bi-person-circle me-2"></i> My Profile
            </div>
            <div class="card-body">
                <div class="text-center mb-4">
                    <div style="width:80px;height:80px;background:#e0e7ff;border-radius:50%;display:inline-flex;align-items:center;justify-content:center;font-size:32px;font-weight:bold;color:#6366f1;">
                        <?= strtoupper(substr($user['name'], 0, 1)) ?>
                    </div>
                    <h4 class="mt-2"><?= htmlspecialchars($user['name']) ?></h4>
                    <span class="badge bg-secondary"><?= strtoupper($user['role']) ?></span>
                </div>

                <form method="POST">
                    <div class="mb-3">
                        <label class="form-label">Full Name</label>
                        <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($user['name']) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Email</label>
                        <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($user['email']) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Change Password</label>
                        <input type="password" name="password" class="form-control" placeholder="Leave empty to keep current">
                    </div>
                    <div class="d-grid">
                        <button type="submit" class="btn btn-primary">Save Changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>