<?php
// modules/Users/add.php
$page_title = "Add User";
session_start();
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../includes/auth_check.php';
requireAdmin();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name     = trim($_POST['name']);
    $email    = trim($_POST['email']);
    $password = trim($_POST['password']);
    $role     = $_POST['role'];

    // Validate role
    if (!in_array($role, ['admin', 'manager', 'staff'])) $role = 'staff';

    $check = mysqli_query($conn, "SELECT id FROM users WHERE email = '" . mysqli_real_escape_string($conn, $email) . "'");
    if (mysqli_num_rows($check) > 0) {
        $_SESSION['error'] = "⚠️ Email already exists!";
    } else {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = mysqli_prepare($conn, "INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)");
        mysqli_stmt_bind_param($stmt, "ssss", $name, $email, $hash, $role);
        if (mysqli_stmt_execute($stmt)) {
            $_SESSION['success'] = "✅ User '$name' created as " . ucfirst($role) . "!";
            header("Location: index.php"); exit();
        } else {
            $_SESSION['error'] = "❌ Failed to create user.";
        }
    }
}

require_once __DIR__ . '/../../includes/header.php';
?>

<div class="d-flex align-items-center justify-content-between mb-4">
    <div>
        <h4 class="mb-1">➕ Add New User</h4>
        <p class="text-muted mb-0" style="font-size:14px;">Create a new team member account</p>
    </div>
    <a href="index.php" class="btn btn-light"><i class="bi bi-arrow-left me-2"></i>Back</a>
</div>

<div class="row g-4">
    <div class="col-lg-7">
        <div class="card">
            <div class="card-header"><i class="bi bi-person-plus-fill me-2 text-primary"></i>User Details</div>
            <div class="card-body">
                <form method="POST">
                    <div class="mb-3">
                        <label class="form-label">Full Name <span class="text-danger">*</span></label>
                        <input type="text" name="name" class="form-control" placeholder="e.g. Raj Patel" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Email Address <span class="text-danger">*</span></label>
                        <input type="email" name="email" class="form-control" placeholder="e.g. raj@shop.com" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Password <span class="text-danger">*</span></label>
                        <input type="password" name="password" class="form-control" placeholder="Minimum 6 characters" required minlength="6">
                    </div>
                    <div class="mb-4">
                        <label class="form-label">Role <span class="text-danger">*</span></label>
                        <div class="d-flex flex-column gap-2" id="roleOptions">
                            <?php
                            $roles = [
                                ['admin',   '#6366f1', 'Admin',   'bi-shield-fill-check', 'Full access — finance, expenses, user management, all reports'],
                                ['manager', '#8b5cf6', 'Manager', 'bi-person-badge-fill',  'Billing, products, customers, purchases, sales reports'],
                                ['staff',   '#64748b', 'Staff',   'bi-person-fill',         'Create bills and view products only'],
                            ];
                            foreach ($roles as $i => [$val, $col, $lbl, $icon, $desc]) : ?>
                            <label style="display:flex;align-items:center;gap:14px;padding:14px 16px;
                                          border:2px solid var(--border-color);border-radius:12px;
                                          cursor:pointer;transition:all .2s;background:var(--card-bg);"
                                   class="role-opt" data-color="<?= $col ?>">
                                <input type="radio" name="role" value="<?= $val ?>"
                                       <?= $i===2 ? 'checked' : '' ?> style="display:none;"
                                       onchange="updateRoleStyle()">
                                <div style="width:40px;height:40px;border-radius:10px;
                                            background:<?= $col ?>20;
                                            display:flex;align-items:center;justify-content:center;flex-shrink:0;">
                                    <i class="bi <?= $icon ?>" style="font-size:18px;color:<?= $col ?>;"></i>
                                </div>
                                <div>
                                    <div style="font-size:14px;font-weight:700;color:var(--text-main);"><?= $lbl ?></div>
                                    <div style="font-size:12px;color:var(--text-muted);"><?= $desc ?></div>
                                </div>
                            </label>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <div class="d-flex gap-3">
                        <button type="submit" class="btn btn-primary flex-fill">
                            <i class="bi bi-check-circle me-2"></i>Create User
                        </button>
                        <a href="index.php" class="btn btn-light">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Role Guide -->
    <div class="col-lg-5">
        <div class="card" style="position:sticky;top:90px;">
            <div class="card-header"><i class="bi bi-info-circle me-2 text-info"></i>Role Guide</div>
            <div class="card-body">
                <?php foreach ([
                    ['admin',  '#6366f1','Admin',  'Full control of the entire system. Can see profits, manage expenses, add/remove users, access all financial reports.'],
                    ['manager','#8b5cf6','Manager','Can handle daily operations — billing, inventory, purchasing. Cannot see expense details, profit reports or manage users.'],
                    ['staff',  '#64748b','Staff',  'Cashier-level access. Can create bills and check product stock. Cannot access customer data, reports or financials.'],
                ] as [$v,$col,$lbl,$txt]) : ?>
                <div style="border:1px solid <?= $col ?>33;border-radius:12px;padding:14px;margin-bottom:12px;background:<?= $col ?>08;">
                    <div style="font-size:13px;font-weight:700;color:<?= $col ?>;margin-bottom:6px;"><?= $lbl ?></div>
                    <div style="font-size:12px;color:var(--text-muted);line-height:1.6;"><?= $txt ?></div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>

<script>
function updateRoleStyle() {
    document.querySelectorAll('.role-opt').forEach(function(el) {
        var radio = el.querySelector('input[type="radio"]');
        var col   = el.getAttribute('data-color');
        if (radio.checked) {
            el.style.borderColor = col;
            el.style.background  = col + '10';
        } else {
            el.style.borderColor = 'var(--border-color)';
            el.style.background  = 'var(--card-bg)';
        }
    });
}
// Init on load
updateRoleStyle();
document.querySelectorAll('.role-opt input').forEach(function(r) {
    r.addEventListener('change', updateRoleStyle);
});
</script>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
