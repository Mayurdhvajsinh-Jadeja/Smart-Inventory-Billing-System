<?php
// modules/Users/index.php
$page_title = "Manage Users";
session_start();
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../includes/auth_check.php';
requireAdmin();

if (isset($_GET['delete'])) {
    $del = (int)$_GET['delete'];
    if ($del == $_SESSION['user_id']) {
        $_SESSION['error'] = "❌ You cannot delete your own account!";
    } else {
        if (mysqli_query($conn, "DELETE FROM users WHERE id = $del"))
            $_SESSION['success'] = "✅ User removed successfully!";
        else
            $_SESSION['error'] = "❌ Failed to delete user.";
    }
    header("Location: index.php"); exit();
}

$users       = mysqli_query($conn, "SELECT * FROM users ORDER BY FIELD(role,'admin','manager','staff'), name ASC");
$total_users = mysqli_num_rows($users);
$counts      = mysqli_fetch_assoc(mysqli_query($conn,
    "SELECT
        SUM(role='admin') as admins,
        SUM(role='manager') as managers,
        SUM(role='staff') as staffs
     FROM users"));

require_once __DIR__ . '/../../includes/header.php';
?>

<style>
.user-card{background:var(--card-bg);border:1px solid var(--border-color);border-radius:18px;padding:22px;
    transition:all .3s ease;position:relative;overflow:hidden;height:100%;}
.user-card:hover{transform:translateY(-4px);box-shadow:var(--shadow-md);}
.user-card::before{content:'';position:absolute;top:0;left:0;right:0;height:3px;border-radius:18px 18px 0 0;}
.uc-admin::before  {background:linear-gradient(90deg,#6366f1,#8b5cf6);}
.uc-manager::before{background:linear-gradient(90deg,#8b5cf6,#ec4899);}
.uc-staff::before  {background:linear-gradient(90deg,#64748b,#94a3b8);}
.role-badge{display:inline-flex;align-items:center;gap:5px;padding:4px 12px;border-radius:20px;
    font-size:11px;font-weight:700;letter-spacing:.5px;}
.rb-admin  {background:rgba(99,102,241,.12);color:#4f46e5;}
.rb-manager{background:rgba(139,92,246,.12);color:#7c3aed;}
.rb-staff  {background:rgba(100,116,139,.12);color:#475569;}
.perm-item{display:flex;align-items:center;gap:6px;font-size:12px;padding:4px 0;}
.perm-yes{color:#10b981;} .perm-no{color:#ef4444;opacity:.5;}
</style>

<!-- Header -->
<div class="d-flex align-items-center justify-content-between mb-4">
    <div>
        <h4 class="mb-1">👥 User Management</h4>
        <p class="text-muted mb-0" style="font-size:14px;"><?= $total_users ?> users across 3 roles</p>
    </div>
    <a href="add.php" class="btn btn-primary">
        <i class="bi bi-person-plus-fill me-2"></i>Add New User
    </a>
</div>

<!-- Role stat cards -->
<div class="row g-4 mb-4">
    <?php
    $role_stats = [
        ['role'=>'admin',   'label'=>'Admins',   'count'=>$counts['admins'],   'col'=>'#6366f1', 'icon'=>'bi-shield-fill-check', 'desc'=>'Full system access'],
        ['role'=>'manager', 'label'=>'Managers', 'count'=>$counts['managers'], 'col'=>'#8b5cf6', 'icon'=>'bi-person-badge-fill',  'desc'=>'Billing + reports'],
        ['role'=>'staff',   'label'=>'Staff',    'count'=>$counts['staffs'],   'col'=>'#64748b', 'icon'=>'bi-person-fill',         'desc'=>'Billing only'],
    ];
    foreach ($role_stats as $rs) : ?>
    <div class="col-md-4">
        <div class="card h-100" style="border-top:3px solid <?= $rs['col'] ?>;">
            <div class="card-body d-flex align-items-center gap-3">
                <div style="width:52px;height:52px;border-radius:14px;
                            background:<?= $rs['col'] ?>20;
                            display:flex;align-items:center;justify-content:center;flex-shrink:0;">
                    <i class="bi <?= $rs['icon'] ?>" style="font-size:22px;color:<?= $rs['col'] ?>;"></i>
                </div>
                <div>
                    <div style="font-size:28px;font-weight:800;color:var(--text-main);line-height:1;">
                        <?= $rs['count'] ?? 0 ?>
                    </div>
                    <div style="font-size:13px;font-weight:600;color:var(--text-main);"><?= $rs['label'] ?></div>
                    <div style="font-size:11px;color:var(--text-muted);"><?= $rs['desc'] ?></div>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<!-- Permission matrix -->
<div class="card mb-4">
    <div class="card-header"><i class="bi bi-shield-lock-fill me-2 text-primary"></i>Permission Matrix</div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table mb-0" style="font-size:13px;">
                <thead>
                    <tr>
                        <th style="width:30%;">Feature</th>
                        <th class="text-center"><span class="role-badge rb-admin">ADMIN</span></th>
                        <th class="text-center"><span class="role-badge rb-manager">MANAGER</span></th>
                        <th class="text-center"><span class="role-badge rb-staff">STAFF</span></th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $perms = [
                        ['Full Dashboard',        true,  true,  false],
                        ['Create Bills',          true,  true,  true ],
                        ['View All Bills',        true,  true,  false],
                        ['Products (add/edit)',   true,  true,  false],
                        ['Products (view)',       true,  true,  true ],
                        ['Customers',             true,  true,  false],
                        ['Purchases & Suppliers', true,  true,  false],
                        ['Expenses',              true,  false, false],
                        ['Sales Reports',         true,  true,  false],
                        ['Profit & Finance Reports',true,false, false],
                        ['Manage Users',          true,  false, false],
                        ['System Backup',         true,  false, false],
                    ];
                    foreach ($perms as $p) :
                        $tick = '<i class="bi bi-check-circle-fill perm-yes" style="font-size:16px;"></i>';
                        $cross= '<i class="bi bi-x-circle perm-no" style="font-size:16px;"></i>';
                    ?>
                    <tr>
                        <td class="fw-500"><?= $p[0] ?></td>
                        <td class="text-center"><?= $p[1] ? $tick : $cross ?></td>
                        <td class="text-center"><?= $p[2] ? $tick : $cross ?></td>
                        <td class="text-center"><?= $p[3] ? $tick : $cross ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- User Cards -->
<div class="row g-4">
    <?php
    mysqli_data_seek($users, 0);
    while ($u = mysqli_fetch_assoc($users)) :
        $role = $u['role'];
        $col  = $role === 'admin' ? '#6366f1' : ($role === 'manager' ? '#8b5cf6' : '#64748b');
        $rb   = 'rb-' . $role;
        $uc   = 'uc-' . $role;
        $lbl  = ucfirst($role);
        $initials = strtoupper(substr($u['name'], 0, 2));
    ?>
    <div class="col-xl-3 col-lg-4 col-md-6">
        <div class="user-card <?= $uc ?>">
            <!-- Avatar + role -->
            <div class="d-flex align-items-center gap-3 mb-3">
                <div style="width:48px;height:48px;border-radius:14px;
                            background:linear-gradient(135deg,<?= $col ?>,<?= $col ?>aa);
                            display:flex;align-items:center;justify-content:center;
                            color:white;font-weight:800;font-size:16px;flex-shrink:0;">
                    <?= $initials ?>
                </div>
                <div class="flex-grow-1 min-w-0">
                    <div style="font-size:14px;font-weight:700;color:var(--text-main);
                                white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">
                        <?= htmlspecialchars($u['name']) ?>
                        <?php if ($u['id'] == $_SESSION['user_id']) : ?>
                            <span style="font-size:10px;background:var(--hover-bg);color:var(--text-muted);
                                         padding:1px 6px;border-radius:6px;margin-left:4px;">You</span>
                        <?php endif; ?>
                    </div>
                    <span class="role-badge <?= $rb ?>"><?= $lbl ?></span>
                </div>
            </div>

            <!-- Email -->
            <div style="font-size:12px;color:var(--text-muted);margin-bottom:12px;
                        white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">
                <i class="bi bi-envelope me-1"></i><?= htmlspecialchars($u['email']) ?>
            </div>

            <!-- Joined -->
            <div style="font-size:11px;color:var(--text-muted);margin-bottom:16px;">
                <i class="bi bi-calendar3 me-1"></i>Joined <?= date('d M Y', strtotime($u['created_at'])) ?>
            </div>

            <!-- Actions -->
            <div class="d-flex gap-2">
                <a href="edit.php?id=<?= $u['id'] ?>" class="btn btn-sm btn-outline-primary flex-fill">
                    <i class="bi bi-pencil me-1"></i>Edit
                </a>
                <?php if ($u['id'] != $_SESSION['user_id']) : ?>
                <a href="index.php?delete=<?= $u['id'] ?>"
                   class="btn btn-sm btn-outline-danger"
                   onclick="return confirm('Remove <?= htmlspecialchars($u['name']) ?>? They will lose access immediately.')">
                    <i class="bi bi-trash"></i>
                </a>
                <?php else : ?>
                <button class="btn btn-sm btn-outline-secondary" disabled title="Can't delete yourself">
                    <i class="bi bi-trash"></i>
                </button>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php endwhile; ?>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
