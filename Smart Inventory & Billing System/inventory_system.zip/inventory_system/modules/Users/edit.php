<?php
// modules/Users/edit.php
$page_title = "Edit User";
session_start();
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../includes/auth_check.php';
requireAdmin();

$id   = (int)$_GET['id'];
$user = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM users WHERE id = $id"));
if (!$user) { header("Location: index.php"); exit(); }

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name     = trim($_POST['name']);
    $email    = trim($_POST['email']);
    $role     = $_POST['role'];
    $new_pass = trim($_POST['password']);

    if (!in_array($role, ['admin', 'manager', 'staff'])) $role = 'staff';

    // Prevent self-demotion to staff
    if ($id == $_SESSION['user_id'] && $role === 'staff') {
        $_SESSION['error'] = "⚠️ You cannot demote yourself to Staff!";
    } else {
        $stmt = mysqli_prepare($conn, "UPDATE users SET name=?, email=?, role=? WHERE id=?");
        mysqli_stmt_bind_param($stmt, "sssi", $name, $email, $role, $id);
        mysqli_stmt_execute($stmt);

        if (!empty($new_pass)) {
            $hash = password_hash($new_pass, PASSWORD_DEFAULT);
            $ps   = mysqli_prepare($conn, "UPDATE users SET password=? WHERE id=?");
            mysqli_stmt_bind_param($ps, "si", $hash, $id);
            mysqli_stmt_execute($ps);
        }

        $_SESSION['success'] = "✅ User updated successfully!";
        header("Location: index.php"); exit();
    }
}

require_once __DIR__ . '/../../includes/header.php';
?>

<div class="d-flex align-items-center justify-content-between mb-4">
    <div>
        <h4 class="mb-1">✏️ Edit User</h4>
        <p class="text-muted mb-0" style="font-size:14px;"><?= htmlspecialchars($user['name']) ?></p>
    </div>
    <a href="index.php" class="btn btn-light"><i class="bi bi-arrow-left me-2"></i>Back</a>
</div>

<div class="row g-4 justify-content-center">
    <div class="col-lg-7">
        <div class="card">
            <div class="card-header"><i class="bi bi-pencil-square me-2 text-primary"></i>Edit Details</div>
            <div class="card-body">
                <form method="POST">
                    <div class="mb-3">
                        <label class="form-label">Full Name</label>
                        <input type="text" name="name" class="form-control"
                               value="<?= htmlspecialchars($user['name']) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Email Address</label>
                        <input type="email" name="email" class="form-control"
                               value="<?= htmlspecialchars($user['email']) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">New Password <span style="color:var(--text-muted);font-weight:400;">(leave blank to keep current)</span></label>
                        <input type="password" name="password" class="form-control" placeholder="Enter new password">
                    </div>
                    <div class="mb-4">
                        <label class="form-label">Role</label>
                        <div class="d-flex flex-column gap-2">
                            <?php
                            $roles = [
                                ['admin',   '#6366f1','Admin',   'bi-shield-fill-check','Full system access'],
                                ['manager', '#8b5cf6','Manager', 'bi-person-badge-fill', 'Billing, products, reports'],
                                ['staff',   '#64748b','Staff',   'bi-person-fill',        'Billing only'],
                            ];
                            foreach ($roles as [$val,$col,$lbl,$icon,$desc]) : ?>
                            <label style="display:flex;align-items:center;gap:14px;padding:12px 16px;
                                          border:2px solid var(--border-color);border-radius:12px;
                                          cursor:pointer;transition:all .2s;background:var(--card-bg);"
                                   class="role-opt" data-color="<?= $col ?>">
                                <input type="radio" name="role" value="<?= $val ?>"
                                       <?= $user['role']==$val ? 'checked' : '' ?>
                                       style="display:none;" onchange="updateRoleStyle()">
                                <div style="width:36px;height:36px;border-radius:10px;background:<?= $col ?>20;
                                            display:flex;align-items:center;justify-content:center;flex-shrink:0;">
                                    <i class="bi <?= $icon ?>" style="font-size:16px;color:<?= $col ?>;"></i>
                                </div>
                                <div>
                                    <div style="font-size:13px;font-weight:700;color:var(--text-main);"><?= $lbl ?></div>
                                    <div style="font-size:11px;color:var(--text-muted);"><?= $desc ?></div>
                                </div>
                            </label>
                            <?php endforeach; ?>
                        </div>
                        <?php if ($id == $_SESSION['user_id']) : ?>
                        <div style="font-size:12px;color:var(--warning);margin-top:8px;">
                            <i class="bi bi-exclamation-triangle me-1"></i>You cannot demote yourself to Staff.
                        </div>
                        <?php endif; ?>
                    </div>
                    <div class="d-flex gap-3">
                        <button type="submit" class="btn btn-primary flex-fill">
                            <i class="bi bi-check-circle me-2"></i>Update User
                        </button>
                        <a href="index.php" class="btn btn-light">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
function updateRoleStyle() {
    document.querySelectorAll('.role-opt').forEach(function(el) {
        var radio = el.querySelector('input[type="radio"]');
        var col   = el.getAttribute('data-color');
        if (radio.checked) {
            el.style.borderColor = col;
            el.style.background  = col + '10';
        } else {
            el.style.borderColor = 'var(--border-color)';
            el.style.background  = 'var(--card-bg)';
        }
    });
}
updateRoleStyle();
</script>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
