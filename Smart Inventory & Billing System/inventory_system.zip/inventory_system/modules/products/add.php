<?php
// modules/products/add.php
$page_title = "Add Product";
session_start();
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../includes/stock_helper.php';


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $product_name = trim($_POST['product_name']);
    $barcode      = trim($_POST['barcode']);
    $category_id  = (int)$_POST['category_id'];
    $price        = (float)$_POST['price'];
    $cost_price   = (float)$_POST['cost_price'];
    $quantity     = (int)$_POST['quantity'];

    if (empty($product_name) || $category_id == 0 || $price <= 0) {
        $_SESSION['error'] = "⚠️ Please fill all required fields!";
    } else {
        if (!empty($barcode)) {
            $chk = mysqli_query($conn, "SELECT id FROM products WHERE barcode='".mysqli_real_escape_string($conn,$barcode)."'");
            if (mysqli_num_rows($chk) > 0) { $_SESSION['error'] = "⚠️ Barcode already exists!"; header("Location: add.php"); exit(); }
        }
        $stmt = mysqli_prepare($conn, "INSERT INTO products (barcode,product_name,category_id,price,cost_price,quantity) VALUES (?,?,?,?,?,?)");
        mysqli_stmt_bind_param($stmt, "ssiddi", $barcode, $product_name, $category_id, $price, $cost_price, $quantity);
        if (mysqli_stmt_execute($stmt)) {
            $new_pid = mysqli_insert_id($conn);
            if ($quantity > 0) log_stock($conn, $new_pid, 'opening', $quantity, 'in', null, 'Opening stock when product added');
            $_SESSION['success'] = "✅ Product '$product_name' added!"; header("Location: index.php"); exit();
        } else $_SESSION['error'] = "❌ Failed to add product!";
    }
}

$categories = mysqli_query($conn, "SELECT * FROM categories ORDER BY category_name");
require_once __DIR__ . '/../../includes/header.php';
?>

<style>
.field-card{background:var(--card-bg);border:1px solid var(--border-color);border-radius:16px;padding:20px 22px;height:100%;transition:border-color .2s;}
.field-card:focus-within{border-color:#6366f1;}
.field-label{font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:var(--text-muted);margin-bottom:8px;display:flex;align-items:center;gap:6px;}
.field-label i{font-size:13px;}
.field-card .form-control,.field-card .form-select{border:none;background:transparent;padding:0;font-size:16px;font-weight:600;color:var(--text-main);box-shadow:none !important;}
.field-card .form-control::placeholder{color:var(--text-muted);font-weight:400;}
.field-card .input-group .form-control{font-size:14px;}
.profit-preview{background:linear-gradient(135deg,rgba(16,185,129,.1),rgba(6,182,212,.1));border:1px solid rgba(16,185,129,.2);border-radius:12px;padding:14px 18px;margin-top:4px;}
.cat-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:8px;margin-top:8px;}
.cat-opt{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:6px;padding:12px 8px;border-radius:12px;border:2px solid var(--border-color);cursor:pointer;transition:all .2s;background:var(--card-bg);text-align:center;}
.cat-opt input{display:none;}
.cat-opt span{font-size:12px;font-weight:600;color:var(--text-muted);}
.cat-opt:has(input:checked){border-color:#6366f1;background:rgba(99,102,241,.08);}
.cat-opt:has(input:checked) span{color:#4f46e5;}
.cat-opt .cat-icon{width:36px;height:36px;border-radius:10px;background:var(--hover-bg);display:flex;align-items:center;justify-content:center;font-size:16px;transition:background .2s;}
.cat-opt:has(input:checked) .cat-icon{background:linear-gradient(135deg,#6366f1,#8b5cf6);color:white;}
</style>

<div class="d-flex align-items-center justify-content-between mb-4">
    <div>
        <h4 class="mb-1">➕ Add New Product</h4>
        <p class="text-muted mb-0" style="font-size:14px;">Fill in the details to add a product to inventory</p>
    </div>
    <a href="index.php" class="btn btn-light"><i class="bi bi-arrow-left me-2"></i>Back</a>
</div>

<form method="POST" id="addForm">
<div class="row g-4">

    <!-- LEFT: Main fields -->
    <div class="col-lg-8">
        <div class="row g-4">

            <!-- Product Name -->
            <div class="col-12">
                <div class="field-card">
                    <div class="field-label"><i class="bi bi-box-seam-fill text-primary"></i> Product Name <span class="text-danger">*</span></div>
                    <input type="text" name="product_name" class="form-control" placeholder="e.g. Coca Cola 500ml" required autofocus>
                </div>
            </div>

            <!-- Barcode -->
            <div class="col-md-6">
                <div class="field-card">
                    <div class="field-label"><i class="bi bi-upc-scan text-warning"></i> Barcode / SKU</div>
                    <div class="input-group">
                        <input type="text" name="barcode" id="barcodeField" class="form-control" placeholder="Scan or type code...">
                        <button type="button" class="btn btn-outline-secondary btn-sm" onclick="genBarcode()" title="Auto-generate">
                            <i class="bi bi-magic"></i>
                        </button>
                    </div>
                    <div style="font-size:11px;color:var(--text-muted);margin-top:6px;">Leave blank if product has no barcode</div>
                </div>
            </div>

            <!-- Stock Quantity -->
            <div class="col-md-6">
                <div class="field-card">
                    <div class="field-label"><i class="bi bi-layers-fill text-cyan" style="color:#06b6d4;"></i> Opening Stock</div>
                    <input type="number" name="quantity" class="form-control" value="0" min="0" placeholder="0">
                    <div style="font-size:11px;color:var(--text-muted);margin-top:6px;">Initial stock quantity when adding</div>
                </div>
            </div>

            <!-- Selling Price -->
            <div class="col-md-6">
                <div class="field-card">
                    <div class="field-label"><i class="bi bi-tag-fill text-success"></i> Selling Price (₹) <span class="text-danger">*</span></div>
                    <div class="input-group">
                        <span class="input-group-text" style="background:transparent;border:none;padding:0 8px 0 0;font-size:18px;font-weight:700;color:#10b981;">₹</span>
                        <input type="number" name="price" id="sellPrice" class="form-control" placeholder="0.00" step="0.01" min="0" required oninput="calcMargin()">
                    </div>
                </div>
            </div>

            <!-- Cost Price -->
            <div class="col-md-6">
                <div class="field-card">
                    <div class="field-label"><i class="bi bi-receipt text-muted"></i> Cost Price (₹)</div>
                    <div class="input-group">
                        <span class="input-group-text" style="background:transparent;border:none;padding:0 8px 0 0;font-size:18px;font-weight:700;color:#64748b;">₹</span>
                        <input type="number" name="cost_price" id="costPrice" class="form-control" placeholder="0.00" step="0.01" min="0" oninput="calcMargin()">
                    </div>
                </div>
            </div>

            <!-- Profit Preview -->
            <div class="col-12">
                <div class="profit-preview" id="profitPreview" style="display:none;">
                    <div class="row g-3 text-center">
                        <div class="col-4">
                            <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:#0f766e;">Profit / Unit</div>
                            <div style="font-size:22px;font-weight:800;color:#10b981;" id="profitAmt">₹0</div>
                        </div>
                        <div class="col-4">
                            <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:#0f766e;">Margin %</div>
                            <div style="font-size:22px;font-weight:800;color:#10b981;" id="profitPct">0%</div>
                        </div>
                        <div class="col-4">
                            <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:#0f766e;">Rating</div>
                            <div style="font-size:18px;font-weight:800;" id="profitRating">—</div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>

    <!-- RIGHT: Category picker + submit -->
    <div class="col-lg-4">
        <div class="card" style="border-radius:16px;position:sticky;top:90px;">
            <div class="card-header" style="border-radius:16px 16px 0 0;">
                <i class="bi bi-tags-fill me-2 text-primary"></i>Category <span class="text-danger">*</span>
            </div>
            <div class="card-body">
                <?php
                $cat_icons = ['Groceries'=>'bi-basket-fill','Beverages'=>'bi-cup-straw','Snacks'=>'bi-cookie','Dairy Products'=>'bi-droplet-fill','Personal Care'=>'bi-heart-fill','Stationary Items'=>'bi-pencil-fill','cloths'=>'bi-bag-fill'];
                $cat_colors= ['#6366f1','#10b981','#f59e0b','#ef4444','#06b6d4','#8b5cf6','#ec4899'];
                $cats_arr  = [];
                while($c=mysqli_fetch_assoc($categories)) $cats_arr[]=$c;
                ?>
                <input type="hidden" name="category_id" id="catInput" required>
                <div class="cat-grid" id="catGrid">
                    <?php foreach($cats_arr as $i=>$cat):
                        $icon=$cat_icons[$cat['category_name']] ?? 'bi-tag-fill';
                        $col=$cat_colors[$i%count($cat_colors)];
                    ?>
                    <label class="cat-opt" onclick="selectCat(<?=$cat['id']?>)">
                        <input type="radio" name="_cat_visual" value="<?=$cat['id']?>">
                        <div class="cat-icon"><i class="bi <?=$icon?>" style="color:<?=$col?>;"></i></div>
                        <span><?=htmlspecialchars($cat['category_name'])?></span>
                    </label>
                    <?php endforeach;?>
                </div>
                <div id="catError" style="display:none;color:#ef4444;font-size:12px;margin-top:8px;"><i class="bi bi-exclamation-circle me-1"></i>Please select a category</div>
            </div>
            <div class="card-footer" style="border-radius:0 0 16px 16px;background:transparent;">
                <button type="submit" class="btn btn-primary w-100 btn-lg" id="submitBtn">
                    <i class="bi bi-check-circle me-2"></i>Add Product
                </button>
                <a href="index.php" class="btn btn-light w-100 mt-2">Cancel</a>
            </div>
        </div>
    </div>

</div>
</form>

<script>
function genBarcode() {
    document.getElementById('barcodeField').value = Math.floor(100000000000 + Math.random() * 900000000000);
}

function selectCat(id) {
    document.getElementById('catInput').value = id;
    document.getElementById('catError').style.display = 'none';
}

function calcMargin() {
    const sell = parseFloat(document.getElementById('sellPrice').value) || 0;
    const cost = parseFloat(document.getElementById('costPrice').value) || 0;
    const preview = document.getElementById('profitPreview');
    if (sell > 0 && cost > 0) {
        const profit = sell - cost;
        const pct    = (profit / cost) * 100;
        document.getElementById('profitAmt').textContent = '₹' + profit.toFixed(2);
        document.getElementById('profitPct').textContent = pct.toFixed(1) + '%';
        const rating = pct >= 30 ? '🟢 High' : pct >= 15 ? '🟡 Medium' : '🔴 Low';
        document.getElementById('profitRating').textContent = rating;
        document.getElementById('profitAmt').style.color = pct >= 15 ? '#10b981' : '#ef4444';
        document.getElementById('profitPct').style.color = pct >= 15 ? '#10b981' : '#ef4444';
        preview.style.display = 'block';
    } else {
        preview.style.display = 'none';
    }
}

document.getElementById('addForm').addEventListener('submit', function(e) {
    if (!document.getElementById('catInput').value) {
        e.preventDefault();
        document.getElementById('catError').style.display = 'block';
        document.getElementById('catGrid').scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
});
</script>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
