<?php
// modules/products/stock_log.php
$page_title = "Stock Movement Log";
session_start();
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../includes/auth_check.php';
requireManager();

// Filters
$filter_product  = isset($_GET['product_id'])  ? (int)$_GET['product_id']              : 0;
$filter_type     = isset($_GET['type'])        ? trim($_GET['type'])                   : '';
$filter_dir      = isset($_GET['direction'])   ? trim($_GET['direction'])              : '';
$filter_from     = isset($_GET['date_from'])   ? $_GET['date_from']                   : date('Y-m-01');
$filter_to       = isset($_GET['date_to'])     ? $_GET['date_to']                     : date('Y-m-d');
$page_num        = isset($_GET['page'])        ? max(1,(int)$_GET['page'])             : 1;
$per_page        = 20;
$offset          = ($page_num - 1) * $per_page;

// Build WHERE
$where = "WHERE sm.created_at BETWEEN '$filter_from 00:00:00' AND '$filter_to 23:59:59'";
if ($filter_product) $where .= " AND sm.product_id = $filter_product";
if ($filter_type && in_array($filter_type,['sale','purchase','manual_edit','manual_add','opening']))
    $where .= " AND sm.type = '".mysqli_real_escape_string($conn,$filter_type)."'";
if ($filter_dir && in_array($filter_dir,['in','out']))
    $where .= " AND sm.direction = '".mysqli_real_escape_string($conn,$filter_dir)."'";

$total_rows = mysqli_fetch_assoc(mysqli_query($conn,
    "SELECT COUNT(*) as t FROM stock_movements sm $where"))['t'];
$total_pages = max(1, ceil($total_rows / $per_page));

$movements = mysqli_query($conn,
    "SELECT sm.*, p.product_name, u.name as user_name
     FROM stock_movements sm
     LEFT JOIN products p ON sm.product_id = p.id
     LEFT JOIN users    u ON sm.created_by  = u.id
     $where
     ORDER BY sm.created_at DESC
     LIMIT $offset, $per_page"
);

// Summary stats for period
$stats_in  = mysqli_fetch_assoc(mysqli_query($conn,
    "SELECT COUNT(*) as cnt, COALESCE(SUM(quantity),0) as qty
     FROM stock_movements sm $where AND direction='in'"));
$stats_out = mysqli_fetch_assoc(mysqli_query($conn,
    "SELECT COUNT(*) as cnt, COALESCE(SUM(quantity),0) as qty
     FROM stock_movements sm $where AND direction='out'"));

// Products list for filter dropdown
$all_products = mysqli_query($conn,"SELECT id,product_name FROM products ORDER BY product_name");

// Type config
$type_cfg = [
    'sale'        => ['label'=>'Sale',           'icon'=>'bi-cart-fill',         'col'=>'#ef4444'],
    'purchase'    => ['label'=>'Purchase',        'icon'=>'bi-box-arrow-in-down', 'col'=>'#6366f1'],
    'manual_edit' => ['label'=>'Manual Edit',     'icon'=>'bi-pencil-fill',       'col'=>'#f59e0b'],
    'manual_add'  => ['label'=>'Manual Add',      'icon'=>'bi-plus-circle-fill',  'col'=>'#06b6d4'],
    'opening'     => ['label'=>'Opening Stock',   'icon'=>'bi-box-seam-fill',     'col'=>'#10b981'],
];

require_once __DIR__ . '/../../includes/header.php';

// Build query string for pagination (preserve filters)
$qs = http_build_query(array_filter([
    'product_id'=>$filter_product,'type'=>$filter_type,
    'direction'=>$filter_dir,'date_from'=>$filter_from,'date_to'=>$filter_to
]));
?>

<style>
.sm-stat{background:var(--card-bg);border:1px solid var(--border-color);border-radius:16px;padding:20px;height:100%;position:relative;overflow:hidden;}
.sm-stat::before{content:'';position:absolute;top:0;left:0;right:0;height:3px;border-radius:16px 16px 0 0;}
.ss-in::before  {background:linear-gradient(90deg,#10b981,#06b6d4);}
.ss-out::before {background:linear-gradient(90deg,#ef4444,#ec4899);}
.ss-net::before {background:linear-gradient(90deg,#6366f1,#8b5cf6);}
.ss-tot::before {background:linear-gradient(90deg,#f59e0b,#f97316);}
.sm-icon{width:44px;height:44px;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0;}
.dir-badge{display:inline-flex;align-items:center;gap:5px;font-size:11px;font-weight:700;padding:4px 11px;border-radius:20px;}
.dir-in {background:rgba(16,185,129,.12);color:#059669;}
.dir-out{background:rgba(239,68,68,.12);color:#dc2626;}
.type-badge{display:inline-flex;align-items:center;gap:5px;font-size:11px;font-weight:700;padding:4px 10px;border-radius:20px;}
.sm-row:hover{background:var(--hover-bg);}
.filter-pill{display:inline-flex;align-items:center;gap:5px;padding:6px 14px;border-radius:50px;border:2px solid var(--border-color);font-size:12px;font-weight:600;color:var(--text-muted);text-decoration:none;transition:all .2s;background:var(--card-bg);}
.filter-pill:hover,.filter-pill.fp-active{border-color:#6366f1;color:#4f46e5;background:rgba(99,102,241,.08);}
.filter-pill.fp-in:hover,.filter-pill.fp-in.fp-active{border-color:#10b981;color:#059669;background:rgba(16,185,129,.08);}
.filter-pill.fp-out:hover,.filter-pill.fp-out.fp-active{border-color:#ef4444;color:#dc2626;background:rgba(239,68,68,.08);}
</style>

<!-- Header -->
<div class="d-flex align-items-center justify-content-between mb-4">
    <div>
        <h4 class="mb-1">📦 Stock Movement Log</h4>
        <p class="text-muted mb-0" style="font-size:14px;">
            Every stock change tracked — sales, purchases, manual edits
        </p>
    </div>
    <a href="index.php" class="btn btn-light"><i class="bi bi-arrow-left me-2"></i>Products</a>
</div>

<!-- Summary Stats -->
<div class="row g-4 mb-4">
    <div class="col-lg-3 col-md-6"><div class="sm-stat ss-in">
        <div class="d-flex align-items-center gap-3">
            <div class="sm-icon" style="background:rgba(16,185,129,.12);color:#10b981;"><i class="bi bi-arrow-down-circle-fill"></i></div>
            <div>
                <div style="font-size:22px;font-weight:800;color:var(--text-main);"><?= $stats_in['qty'] ?></div>
                <div style="font-size:12px;color:var(--text-muted);">Units In (<?= $stats_in['cnt'] ?> events)</div>
            </div>
        </div>
    </div></div>
    <div class="col-lg-3 col-md-6"><div class="sm-stat ss-out">
        <div class="d-flex align-items-center gap-3">
            <div class="sm-icon" style="background:rgba(239,68,68,.12);color:#ef4444;"><i class="bi bi-arrow-up-circle-fill"></i></div>
            <div>
                <div style="font-size:22px;font-weight:800;color:var(--text-main);"><?= $stats_out['qty'] ?></div>
                <div style="font-size:12px;color:var(--text-muted);">Units Out (<?= $stats_out['cnt'] ?> events)</div>
            </div>
        </div>
    </div></div>
    <div class="col-lg-3 col-md-6"><div class="sm-stat ss-net">
        <div class="d-flex align-items-center gap-3">
            <div class="sm-icon" style="background:rgba(99,102,241,.12);color:#6366f1;"><i class="bi bi-arrows-collapse"></i></div>
            <div>
                <?php $net = $stats_in['qty'] - $stats_out['qty']; ?>
                <div style="font-size:22px;font-weight:800;color:<?= $net >= 0 ? '#10b981' : '#ef4444' ?>;">
                    <?= $net >= 0 ? '+' : '' ?><?= $net ?>
                </div>
                <div style="font-size:12px;color:var(--text-muted);">Net Change</div>
            </div>
        </div>
    </div></div>
    <div class="col-lg-3 col-md-6"><div class="sm-stat ss-tot">
        <div class="d-flex align-items-center gap-3">
            <div class="sm-icon" style="background:rgba(245,158,11,.12);color:#f59e0b;"><i class="bi bi-clock-history"></i></div>
            <div>
                <div style="font-size:22px;font-weight:800;color:var(--text-main);"><?= $total_rows ?></div>
                <div style="font-size:12px;color:var(--text-muted);">Total Events</div>
            </div>
        </div>
    </div></div>
</div>

<!-- Filters -->
<div class="card mb-4">
    <div class="card-body">
        <form method="GET" class="row g-3 align-items-end">
            <div class="col-md-3">
                <label class="form-label">Product</label>
                <select name="product_id" class="form-select">
                    <option value="0">All Products</option>
                    <?php while($p=mysqli_fetch_assoc($all_products)): ?>
                    <option value="<?= $p['id'] ?>" <?= $filter_product==$p['id']?'selected':'' ?>>
                        <?= htmlspecialchars($p['product_name']) ?>
                    </option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label">Type</label>
                <select name="type" class="form-select">
                    <option value="">All Types</option>
                    <?php foreach($type_cfg as $k=>$tc): ?>
                    <option value="<?=$k?>" <?= $filter_type===$k?'selected':'' ?>><?= $tc['label'] ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label">Direction</label>
                <select name="direction" class="form-select">
                    <option value="">Both</option>
                    <option value="in"  <?= $filter_dir==='in' ?'selected':'' ?>>Stock In</option>
                    <option value="out" <?= $filter_dir==='out'?'selected':'' ?>>Stock Out</option>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label">From</label>
                <input type="date" name="date_from" class="form-control" value="<?= $filter_from ?>">
            </div>
            <div class="col-md-2">
                <label class="form-label">To</label>
                <input type="date" name="date_to" class="form-control" value="<?= $filter_to ?>">
            </div>
            <div class="col-md-1 d-flex gap-1">
                <button type="submit" class="btn btn-primary flex-fill"><i class="bi bi-funnel"></i></button>
                <a href="stock_log.php" class="btn btn-light"><i class="bi bi-x"></i></a>
            </div>
        </form>
    </div>
</div>

<!-- Direction quick filter pills -->
<div class="d-flex gap-2 mb-4 flex-wrap">
    <a href="?<?= http_build_query(array_merge(array_filter(['product_id'=>$filter_product,'type'=>$filter_type,'date_from'=>$filter_from,'date_to'=>$filter_to]),[]) ) ?>" 
       class="filter-pill <?= empty($filter_dir)?'fp-active':'' ?>">All Movements</a>
    <a href="?<?= http_build_query(array_filter(['product_id'=>$filter_product,'type'=>$filter_type,'direction'=>'in','date_from'=>$filter_from,'date_to'=>$filter_to])) ?>"
       class="filter-pill fp-in <?= $filter_dir==='in'?'fp-active':'' ?>">
        <i class="bi bi-arrow-down-circle-fill"></i> Stock In
    </a>
    <a href="?<?= http_build_query(array_filter(['product_id'=>$filter_product,'type'=>$filter_type,'direction'=>'out','date_from'=>$filter_from,'date_to'=>$filter_to])) ?>"
       class="filter-pill fp-out <?= $filter_dir==='out'?'fp-active':'' ?>">
        <i class="bi bi-arrow-up-circle-fill"></i> Stock Out
    </a>
</div>

<!-- Movement Table -->
<div class="card">
    <div class="card-header d-flex align-items-center justify-content-between">
        <span><i class="bi bi-list-ul me-2 text-primary"></i>Movement Log (<?= $total_rows ?> records)</span>
        <span style="font-size:12px;color:var(--text-muted);">
            Page <?= $page_num ?> of <?= $total_pages ?>
        </span>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table mb-0">
                <thead>
                    <tr>
                        <th>Date & Time</th>
                        <th>Product</th>
                        <th>Type</th>
                        <th>Direction</th>
                        <th>Qty</th>
                        <th>Before</th>
                        <th>After</th>
                        <th>Note</th>
                        <th>By</th>
                    </tr>
                </thead>
                <tbody>
                <?php if ($total_rows > 0 && mysqli_num_rows($movements) > 0) :
                    while ($m = mysqli_fetch_assoc($movements)) :
                        $tc  = $type_cfg[$m['type']] ?? ['label'=>ucfirst($m['type']),'icon'=>'bi-question-circle','col'=>'#64748b'];
                        $is_in = $m['direction'] === 'in';
                ?>
                <tr class="sm-row">
                    <td style="white-space:nowrap;">
                        <div style="font-size:13px;font-weight:600;color:var(--text-main);">
                            <?= date('d M Y', strtotime($m['created_at'])) ?>
                        </div>
                        <div style="font-size:11px;color:var(--text-muted);">
                            <?= date('h:i A', strtotime($m['created_at'])) ?>
                        </div>
                    </td>
                    <td>
                        <div style="font-size:13px;font-weight:600;color:var(--text-main);">
                            <?= htmlspecialchars($m['product_name'] ?? 'Deleted Product') ?>
                        </div>
                        <?php if ($m['reference_id']): ?>
                        <div style="font-size:11px;color:var(--text-muted);">Ref #<?= $m['reference_id'] ?></div>
                        <?php endif; ?>
                    </td>
                    <td>
                        <span class="type-badge" style="background:<?= $tc['col'] ?>15;color:<?= $tc['col'] ?>;">
                            <i class="bi <?= $tc['icon'] ?>"></i>
                            <?= $tc['label'] ?>
                        </span>
                    </td>
                    <td>
                        <span class="dir-badge <?= $is_in ? 'dir-in' : 'dir-out' ?>">
                            <i class="bi bi-arrow-<?= $is_in ? 'down' : 'up' ?>-circle-fill"></i>
                            <?= $is_in ? 'In' : 'Out' ?>
                        </span>
                    </td>
                    <td>
                        <strong style="font-size:15px;color:<?= $is_in ? '#10b981' : '#ef4444' ?>;">
                            <?= $is_in ? '+' : '-' ?><?= $m['quantity'] ?>
                        </strong>
                    </td>
                    <td style="font-size:13px;color:var(--text-muted);"><?= $m['stock_before'] ?></td>
                    <td>
                        <strong style="color:<?= $m['stock_after'] < 5 ? '#ef4444' : 'var(--text-main)' ?>;">
                            <?= $m['stock_after'] ?>
                            <?php if ($m['stock_after'] == 0): ?>
                                <span style="font-size:9px;background:#fee2e2;color:#991b1b;padding:1px 6px;border-radius:10px;margin-left:4px;">OUT</span>
                            <?php elseif ($m['stock_after'] < 5): ?>
                                <span style="font-size:9px;background:#fef3c7;color:#92400e;padding:1px 6px;border-radius:10px;margin-left:4px;">LOW</span>
                            <?php endif; ?>
                        </strong>
                    </td>
                    <td style="font-size:12px;color:var(--text-muted);max-width:180px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">
                        <?= htmlspecialchars($m['note'] ?? '—') ?>
                    </td>
                    <td style="font-size:12px;color:var(--text-muted);">
                        <?= htmlspecialchars($m['user_name'] ?? 'System') ?>
                    </td>
                </tr>
                <?php endwhile;
                else: ?>
                <tr>
                    <td colspan="9" class="text-center py-5" style="color:var(--text-muted);">
                        <i class="bi bi-clock-history" style="font-size:48px;opacity:.2;"></i>
                        <p class="mt-3 mb-0">No stock movements found for this filter.</p>
                        <small>Movements are recorded automatically when bills, purchases or product edits happen.</small>
                    </td>
                </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Pagination -->
    <?php if ($total_pages > 1) : ?>
    <div class="card-footer">
        <nav>
            <ul class="pagination justify-content-center mb-0" style="gap:4px;">
                <?php if ($page_num > 1): ?>
                <li class="page-item">
                    <a class="page-link" href="?<?= $qs ?>&page=<?= $page_num-1 ?>" style="border-radius:8px;">
                        <i class="bi bi-chevron-left"></i>
                    </a>
                </li>
                <?php endif; ?>
                <?php
                $start = max(1, $page_num-2);
                $end   = min($total_pages, $page_num+2);
                for ($p = $start; $p <= $end; $p++): ?>
                <li class="page-item <?= $p==$page_num?'active':'' ?>">
                    <a class="page-link" href="?<?= $qs ?>&page=<?= $p ?>" style="border-radius:8px;"><?= $p ?></a>
                </li>
                <?php endfor; ?>
                <?php if ($page_num < $total_pages): ?>
                <li class="page-item">
                    <a class="page-link" href="?<?= $qs ?>&page=<?= $page_num+1 ?>" style="border-radius:8px;">
                        <i class="bi bi-chevron-right"></i>
                    </a>
                </li>
                <?php endif; ?>
            </ul>
        </nav>
    </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
