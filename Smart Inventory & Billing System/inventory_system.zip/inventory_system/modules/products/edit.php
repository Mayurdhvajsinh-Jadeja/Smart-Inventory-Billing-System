<?php
// modules/products/edit.php
$page_title = "Edit Product";
session_start();
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../includes/stock_helper.php';


$pid = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if (!$pid) { header("Location: index.php"); exit(); }

$product = mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM products WHERE id=$pid"));
if (!$product) { $_SESSION['error']="❌ Product not found!"; header("Location: index.php"); exit(); }

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name    = trim($_POST['product_name']);
    $cat_id  = (int)$_POST['category_id'];
    $price   = (float)$_POST['price'];
    $cost    = (float)$_POST['cost_price'];
    $qty     = (int)$_POST['quantity'];
    $barcode = trim($_POST['barcode'] ?? '');

    if (empty($name) || $cat_id == 0 || $price <= 0) {
        $_SESSION['error'] = "⚠️ Please fill all required fields!";
    } else {
        // Get old quantity before update for movement log
        $old_qty_r = mysqli_fetch_assoc(mysqli_query($conn,"SELECT quantity FROM products WHERE id=$pid"));
        $old_qty   = $old_qty_r ? (int)$old_qty_r['quantity'] : 0;
        $stmt = mysqli_prepare($conn,"UPDATE products SET product_name=?,category_id=?,price=?,cost_price=?,quantity=?,barcode=? WHERE id=?");
        mysqli_stmt_bind_param($stmt,"siddisi",$name,$cat_id,$price,$cost,$qty,$barcode,$pid);
        if (mysqli_stmt_execute($stmt)) {
            // Log manual stock adjustment if quantity changed
            if ($qty != $old_qty) {
                $diff = abs($qty - $old_qty);
                $dir  = $qty > $old_qty ? 'in' : 'out';
                log_stock($conn, $pid, 'manual_edit', $diff, $dir, null, 'Manual adjustment: '.$old_qty.' → '.$qty);
            }
            $_SESSION['success']="✅ Product updated!"; header("Location: index.php"); exit();
        } else $_SESSION['error']="❌ Failed to update!";
    }
}

$categories = mysqli_query($conn,"SELECT * FROM categories ORDER BY category_name");
$cats_arr   = [];
while($c=mysqli_fetch_assoc($categories)) $cats_arr[]=$c;

// Sales stats for this product
$sold_total = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COALESCE(SUM(bi.quantity),0) as t FROM bill_items bi JOIN bills b ON bi.bill_id=b.id WHERE bi.product_id=$pid"))['t'];
$revenue    = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COALESCE(SUM(bi.quantity*bi.price),0) as t FROM bill_items bi JOIN bills b ON bi.bill_id=b.id WHERE bi.product_id=$pid"))['t'];

require_once __DIR__ . '/../../includes/header.php';
?>
<style>
.field-card{background:var(--card-bg);border:1px solid var(--border-color);border-radius:16px;padding:20px 22px;height:100%;transition:border-color .2s;}
.field-card:focus-within{border-color:#6366f1;}
.field-label{font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:var(--text-muted);margin-bottom:8px;display:flex;align-items:center;gap:6px;}
.field-card .form-control,.field-card .form-select{border:none;background:transparent;padding:0;font-size:16px;font-weight:600;color:var(--text-main);box-shadow:none !important;}
.field-card .form-control::placeholder{color:var(--text-muted);font-weight:400;}
.field-card .input-group .form-control{font-size:14px;}
.profit-preview{background:linear-gradient(135deg,rgba(16,185,129,.1),rgba(6,182,212,.1));border:1px solid rgba(16,185,129,.2);border-radius:12px;padding:14px 18px;margin-top:4px;}
.cat-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(120px,1fr));gap:8px;}
.cat-opt{display:flex;flex-direction:column;align-items:center;gap:6px;padding:10px 6px;border-radius:12px;border:2px solid var(--border-color);cursor:pointer;transition:all .2s;text-align:center;background:var(--card-bg);}
.cat-opt input{display:none;}
.cat-opt span{font-size:11px;font-weight:600;color:var(--text-muted);}
.cat-opt:has(input:checked){border-color:#6366f1;background:rgba(99,102,241,.08);}
.cat-opt:has(input:checked) span{color:#4f46e5;}
.cat-opt .cico{width:34px;height:34px;border-radius:9px;background:var(--hover-bg);display:flex;align-items:center;justify-content:center;font-size:15px;transition:background .2s;}
.cat-opt:has(input:checked) .cico{background:linear-gradient(135deg,#6366f1,#8b5cf6);color:white;}
</style>

<div class="d-flex align-items-center justify-content-between mb-4">
    <div>
        <h4 class="mb-1">✏️ Edit Product</h4>
        <p class="text-muted mb-0" style="font-size:14px;"><?=htmlspecialchars($product['product_name'])?></p>
    </div>
    <a href="index.php" class="btn btn-light"><i class="bi bi-arrow-left me-2"></i>Back</a>
</div>

<!-- Product stats bar -->
<?php if($sold_total>0):?>
<div class="card mb-4" style="background:linear-gradient(135deg,#0f172a,#1e293b);border:none;">
    <div class="card-body py-3">
        <div class="row g-3 text-center">
            <div class="col-4"><div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:rgba(255,255,255,.5);margin-bottom:4px;">Units Sold</div><div style="font-size:22px;font-weight:800;color:white;"><?=$sold_total?></div></div>
            <div class="col-4"><div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:rgba(255,255,255,.5);margin-bottom:4px;">Revenue</div><div style="font-size:22px;font-weight:800;color:#10b981;">₹<?=number_format($revenue,0)?></div></div>
            <div class="col-4"><div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:rgba(255,255,255,.5);margin-bottom:4px;">In Stock</div><div style="font-size:22px;font-weight:800;color:<?=$product['quantity']<5?'#ef4444':'#6ee7b7'?>;"><?=$product['quantity']?></div></div>
        </div>
    </div>
</div>
<?php endif;?>

<form method="POST" id="editForm">
<div class="row g-4">
    <div class="col-lg-8">
        <div class="row g-4">
            <div class="col-12">
                <div class="field-card">
                    <div class="field-label"><i class="bi bi-box-seam-fill text-primary"></i>Product Name <span class="text-danger">*</span></div>
                    <input type="text" name="product_name" class="form-control" value="<?=htmlspecialchars($product['product_name'])?>" required>
                </div>
            </div>
            <div class="col-md-6">
                <div class="field-card">
                    <div class="field-label"><i class="bi bi-upc-scan text-warning"></i>Barcode / SKU</div>
                    <div class="input-group">
                        <input type="text" name="barcode" id="barcodeField" class="form-control" value="<?=htmlspecialchars($product['barcode']??'')?>" placeholder="Scan or type...">
                        <button type="button" class="btn btn-outline-secondary btn-sm" onclick="genBarcode()" title="Generate"><i class="bi bi-magic"></i></button>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="field-card">
                    <div class="field-label"><i class="bi bi-layers-fill" style="color:#06b6d4;"></i>Stock Quantity</div>
                    <input type="number" name="quantity" class="form-control" value="<?=$product['quantity']?>" min="0">
                </div>
            </div>
            <div class="col-md-6">
                <div class="field-card">
                    <div class="field-label"><i class="bi bi-tag-fill text-success"></i>Selling Price (₹) <span class="text-danger">*</span></div>
                    <div class="input-group"><span class="input-group-text" style="background:transparent;border:none;padding:0 8px 0 0;font-size:18px;font-weight:700;color:#10b981;">₹</span><input type="number" name="price" id="sellPrice" class="form-control" value="<?=$product['price']?>" step="0.01" min="0" required oninput="calcMargin()"></div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="field-card">
                    <div class="field-label"><i class="bi bi-receipt text-muted"></i>Cost Price (₹)</div>
                    <div class="input-group"><span class="input-group-text" style="background:transparent;border:none;padding:0 8px 0 0;font-size:18px;font-weight:700;color:#64748b;">₹</span><input type="number" name="cost_price" id="costPrice" class="form-control" value="<?=$product['cost_price']?>" step="0.01" min="0" oninput="calcMargin()"></div>
                </div>
            </div>
            <div class="col-12">
                <div class="profit-preview" id="profitPreview">
                    <div class="row g-3 text-center">
                        <div class="col-4"><div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:#0f766e;">Profit/Unit</div><div style="font-size:22px;font-weight:800;color:#10b981;" id="profitAmt">—</div></div>
                        <div class="col-4"><div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:#0f766e;">Margin %</div><div style="font-size:22px;font-weight:800;color:#10b981;" id="profitPct">—</div></div>
                        <div class="col-4"><div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:#0f766e;">Rating</div><div style="font-size:18px;font-weight:800;" id="profitRating">—</div></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="card" style="border-radius:16px;position:sticky;top:90px;">
            <div class="card-header" style="border-radius:16px 16px 0 0;"><i class="bi bi-tags-fill me-2 text-primary"></i>Category <span class="text-danger">*</span></div>
            <div class="card-body">
                <?php $cat_icons=['Groceries'=>'bi-basket-fill','Beverages'=>'bi-cup-straw','Snacks'=>'bi-cookie','Dairy Products'=>'bi-droplet-fill','Personal Care'=>'bi-heart-fill','Stationary Items'=>'bi-pencil-fill','cloths'=>'bi-bag-fill'];
                $cat_colors=['#6366f1','#10b981','#f59e0b','#ef4444','#06b6d4','#8b5cf6','#ec4899'];?>
                <input type="hidden" name="category_id" id="catInput" value="<?=$product['category_id']?>" required>
                <div class="cat-grid" id="catGrid">
                <?php foreach($cats_arr as $i=>$cat):
                    $icon=$cat_icons[$cat['category_name']]??'bi-tag-fill';
                    $col=$cat_colors[$i%count($cat_colors)];
                    $checked=$product['category_id']==$cat['id']?'checked':'';
                ?>
                <label class="cat-opt" onclick="selectCat(<?=$cat['id']?>)">
                    <input type="radio" name="_cv" value="<?=$cat['id']?>" <?=$checked?>>
                    <div class="cico"><i class="bi <?=$icon?>" style="color:<?=$col?>;"></i></div>
                    <span><?=htmlspecialchars($cat['category_name'])?></span>
                </label>
                <?php endforeach;?>
                </div>
            </div>
            <div class="card-footer" style="border-radius:0 0 16px 16px;background:transparent;">
                <button type="submit" class="btn btn-primary w-100 btn-lg"><i class="bi bi-check-circle me-2"></i>Update Product</button>
                <a href="index.php" class="btn btn-light w-100 mt-2">Cancel</a>
            </div>
        </div>
    </div>
</div>
</form>

<script>
function genBarcode(){document.getElementById('barcodeField').value=Math.floor(100000000000+Math.random()*900000000000);}
function selectCat(id){document.getElementById('catInput').value=id;}
function calcMargin(){
    var sell=parseFloat(document.getElementById('sellPrice').value)||0;
    var cost=parseFloat(document.getElementById('costPrice').value)||0;
    if(sell>0&&cost>0){
        var p=sell-cost,pct=(p/cost)*100;
        document.getElementById('profitAmt').textContent='₹'+p.toFixed(2);
        document.getElementById('profitPct').textContent=pct.toFixed(1)+'%';
        document.getElementById('profitRating').textContent=pct>=30?'🟢 High':pct>=15?'🟡 Medium':'🔴 Low';
        document.getElementById('profitAmt').style.color=pct>=15?'#10b981':'#ef4444';
        document.getElementById('profitPct').style.color=pct>=15?'#10b981':'#ef4444';
    }
}
// Init profit on load
calcMargin();
// Init category highlight
(function(){var cats=document.querySelectorAll('.cat-opt');cats.forEach(function(c){if(c.querySelector('input').checked){c.style.borderColor='#6366f1';c.style.background='rgba(99,102,241,.08)';}});})();
</script>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
