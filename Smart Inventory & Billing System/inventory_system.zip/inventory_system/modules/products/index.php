<?php
// modules/products/index.php

$page_title = "Products";

// Database connection
require_once __DIR__ . '/../../config/db.php';

// ── Handle Delete ──
if (isset($_GET['delete'])) {
    $delete_id = (int) $_GET['delete'];
    
    // Check if product is used in any bill
    $check = mysqli_query($conn, "SELECT COUNT(*) as count FROM bill_items WHERE product_id = $delete_id");
    $row   = mysqli_fetch_assoc($check);
    
    if ($row['count'] > 0) {
        $_SESSION['error'] = "❌ Cannot delete! This product is used in " . $row['count'] . " bills.";
    } else {
        $delete_query = mysqli_query($conn, "DELETE FROM products WHERE id = $delete_id");
        if ($delete_query) {
            $_SESSION['success'] = "✅ Product deleted successfully!";
        } else {
            $_SESSION['error'] = "❌ Failed to delete product!";
        }
    }
    header("Location: index.php");
    exit();
}

// ── Filter by Category ──
$filter_category = isset($_GET['category']) ? (int) $_GET['category'] : 0;
$search          = isset($_GET['search']) ? trim($_GET['search']) : '';

// ── Build Query ──
$sql = "SELECT p.*, c.category_name 
        FROM products p 
        LEFT JOIN categories c ON p.category_id = c.id 
        WHERE 1=1";

if ($filter_category > 0) {
    $sql .= " AND p.category_id = $filter_category";
}

if (!empty($search)) {
    $sql .= " AND p.product_name LIKE '%" . mysqli_real_escape_string($conn, $search) . "%'";
}

$sql .= " ORDER BY p.id DESC";

$products       = mysqli_query($conn, $sql);
$total_products = mysqli_num_rows($products);

// Get categories for filter dropdown
$categories = mysqli_query($conn, "SELECT * FROM categories ORDER BY category_name");

// ── Get Profit Statistics ──
$profit_stats = mysqli_query($conn, 
    "SELECT 
        COUNT(*) as total_products,
        AVG((price - cost_price) / NULLIF(cost_price, 0) * 100) as avg_margin,
        SUM(CASE WHEN (price - cost_price) / NULLIF(cost_price, 0) * 100 >= 30 THEN 1 ELSE 0 END) as high_profit,
        SUM(CASE WHEN (price - cost_price) / NULLIF(cost_price, 0) * 100 < 15 THEN 1 ELSE 0 END) as low_profit
     FROM products"
);
$stats = mysqli_fetch_assoc($profit_stats);

// Include Header
require_once __DIR__ . '/../../includes/header.php';
?>

<!-- ══════════════ PRODUCTS PAGE ══════════════ -->

<!-- Page Header -->
<div class="d-flex align-items-center justify-content-between mb-4">
    <div>
        <h4 class="mb-1">📦 Products & Inventory</h4>
        <p class="text-muted mb-0" style="font-size:14px;">
            Manage your inventory with profit tracking
        </p>
    </div>
    <div class="d-flex gap-2">
        <a href="<?= $base_url ?>/exports/products_excel.php" 
           class="btn btn-success">
            <i class="bi bi-file-excel me-2"></i>Export to Excel
        </a>
        <a href="barcode_generator.php" class="btn btn-outline-primary">
            <i class="bi bi-upc-scan me-2"></i>Barcodes
        </a>
        <a href="add.php" class="btn btn-primary">
            <i class="bi bi-plus-circle me-2"></i>Add Product
        </a>
    </div>
</div>
<!-- Alerts -->




<!-- Profit Statistics Cards -->
<div class="row g-4 mb-4">
    
    <!-- Total Products -->
    <div class="col-lg-3 col-md-6">
        <div class="card h-100">
            <div class="card-body">
                <div class="d-flex align-items-center gap-3">
                    <div style="width:55px; height:55px; border-radius:12px; 
                                background:linear-gradient(135deg, rgba(99,102,241,0.15), rgba(139,92,246,0.15));
                                display:flex; align-items:center; justify-content:center;">
                        <i class="bi bi-box-seam" style="font-size:24px; color:#6366f1;"></i>
                    </div>
                    <div>
                        <h4 class="mb-0" style="font-weight:800; font-size:26px;">
                            <?= $stats['total_products'] ?>
                        </h4>
                        <p class="mb-0 text-muted" style="font-size:12px;">Total Products</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Average Margin -->
    <div class="col-lg-3 col-md-6">
        <div class="card h-100">
            <div class="card-body">
                <div class="d-flex align-items-center gap-3">
                    <div style="width:55px; height:55px; border-radius:12px; 
                                background:linear-gradient(135deg, rgba(16,185,129,0.15), rgba(6,182,212,0.15));
                                display:flex; align-items:center; justify-content:center;">
                        <i class="bi bi-percent" style="font-size:24px; color:#10b981;"></i>
                    </div>
                    <div>
                        <h4 class="mb-0" style="font-weight:800; font-size:26px; color:#10b981;">
                            <?= number_format($stats['avg_margin'], 1) ?>%
                        </h4>
                        <p class="mb-0 text-muted" style="font-size:12px;">Avg. Profit Margin</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- High Profit Products -->
    <div class="col-lg-3 col-md-6">
        <div class="card h-100">
            <div class="card-body">
                <div class="d-flex align-items-center gap-3">
                    <div style="width:55px; height:55px; border-radius:12px; 
                                background:linear-gradient(135deg, rgba(34,197,94,0.15), rgba(22,163,74,0.15));
                                display:flex; align-items:center; justify-content:center;">
                        <i class="bi bi-arrow-up-circle" style="font-size:24px; color:#22c55e;"></i>
                    </div>
                    <div>
                        <h4 class="mb-0" style="font-weight:800; font-size:26px;">
                            <?= $stats['high_profit'] ?>
                        </h4>
                        <p class="mb-0 text-muted" style="font-size:12px;">High Profit (>30%)</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Low Profit Products -->
    <div class="col-lg-3 col-md-6">
        <div class="card h-100">
            <div class="card-body">
                <div class="d-flex align-items-center gap-3">
                    <div style="width:55px; height:55px; border-radius:12px; 
                                background:linear-gradient(135deg, rgba(239,68,68,0.15), rgba(220,38,38,0.15));
                                display:flex; align-items:center; justify-content:center;">
                        <i class="bi bi-arrow-down-circle" style="font-size:24px; color:#ef4444;"></i>
                    </div>
                    <div>
                        <h4 class="mb-0" style="font-weight:800; font-size:26px;">
                            <?= $stats['low_profit'] ?>
                        </h4>
                        <p class="mb-0 text-muted" style="font-size:12px;">Low Profit (<15%)</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
</div>

<!-- Info Alert -->
<div class="alert" style="background:linear-gradient(135deg, #f0f9ff, #e0f2fe); border:none; border-left:4px solid #06b6d4; margin-bottom:20px;">
    <div class="d-flex align-items-center gap-3">
        <i class="bi bi-info-circle" style="font-size:28px; color:#06b6d4;"></i>
        <div>
            <strong style="color:#0c4a6e;">Profit Margin Color Code:</strong>
            <p class="mb-0" style="color:#164e63; font-size:13px; margin-top:5px;">
                <span style="color:#10b981; font-weight:700;">● Green</span> = High Profit (≥30%) &nbsp;|&nbsp; 
                <span style="color:#f59e0b; font-weight:700;">● Orange</span> = Medium Profit (15-30%) &nbsp;|&nbsp; 
                <span style="color:#ef4444; font-weight:700;">● Red</span> = Low Profit (<15%)
            </p>
        </div>
    </div>
</div>

<!-- Search & Filter -->
<div class="card mb-4">
    <div class="card-body">
        <form method="GET" action="">
            <div class="row g-3 align-items-end">
                
                <!-- Search -->
                <div class="col-md-5">
                    <label class="form-label" style="font-weight:500; font-size:13px;">
                        🔍 Search Product
                    </label>
                    <input 
                        type="text" 
                        name="search" 
                        class="form-control" 
                        placeholder="Type product name..."
                        value="<?= htmlspecialchars($search) ?>"
                        style="border-radius:10px; padding:10px 15px;"
                    >
                </div>

                <!-- Category Filter -->
                <div class="col-md-4">
                    <label class="form-label" style="font-weight:500; font-size:13px;">
                        📂 Filter by Category
                    </label>
                    <select name="category" class="form-select" style="border-radius:10px; padding:10px 15px;">
                        <option value="0">All Categories</option>
                        <?php 
                        mysqli_data_seek($categories, 0);
                        while ($cat = mysqli_fetch_assoc($categories)) : 
                        ?>
                            <option value="<?= $cat['id'] ?>" <?= ($filter_category == $cat['id']) ? 'selected' : '' ?>>
                                <?= htmlspecialchars($cat['category_name']) ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>

                <!-- Buttons -->
                <div class="col-md-3">
                    <button type="submit" class="btn btn-primary" style="border-radius:10px; padding:10px 20px;">
                        <i class="bi bi-search me-1"></i> Search
                    </button>
                    <a href="index.php" class="btn btn-light" style="border-radius:10px; padding:10px 20px;">
                        <i class="bi bi-arrow-counterclockwise me-1"></i> Reset
                    </a>
                </div>

            </div>
        </form>
    </div>
</div>

<!-- Products Table -->
<div class="card">
    <div class="card-header d-flex align-items-center justify-content-between">
        <span><i class="bi bi-box-seam-fill me-2 text-primary"></i>All Products (<?= $total_products ?>)</span>
        <a href="<?= $base_url ?>/modules/reports/profit.php" class="btn btn-sm btn-success">
            <i class="bi bi-graph-up me-1"></i>View Profit Report
        </a>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table mb-0">
                <thead>
                    <tr>
                        <th width="4%">#</th>
                        <th width="22%">Product Name</th>
                        <th width="10%">Category</th>
                        <th width="10%">Barcode</th>
                        <th width="9%">Cost Price</th>
                        <th width="9%">Selling Price</th>
                        <th width="9%">Profit Margin</th>
                        <th width="7%">Stock</th>
                        <th width="9%">Status</th>
                        <th width="9%">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($total_products > 0) : ?>
                        <?php 
                        $sr = 1; 
                        mysqli_data_seek($products, 0);
                        while ($product = mysqli_fetch_assoc($products)) : 
                            // Calculate profit
                            $profit = $product['price'] - $product['cost_price'];
                            $profit_percent = $product['cost_price'] > 0 
                                ? ($profit / $product['cost_price']) * 100 
                                : 0;
                            
                            // Determine profit color
                            if ($profit_percent >= 30) {
                                $profit_color = '#10b981';
                                $profit_badge = 'High';
                                $profit_badge_bg = 'rgba(16,185,129,0.1)';
                            } elseif ($profit_percent >= 15) {
                                $profit_color = '#f59e0b';
                                $profit_badge = 'Medium';
                                $profit_badge_bg = 'rgba(245,158,11,0.1)';
                            } else {
                                $profit_color = '#ef4444';
                                $profit_badge = 'Low';
                                $profit_badge_bg = 'rgba(239,68,68,0.1)';
                            }
                        ?>
                            <tr>
                                <td><strong><?= $sr++ ?></strong></td>
                                <td>
                                    <div class="d-flex align-items-center gap-2">
                                        <div style="width:35px; height:35px; border-radius:8px; 
                                                    background:linear-gradient(135deg, rgba(99,102,241,0.1), rgba(139,92,246,0.1));
                                                    display:flex; align-items:center; justify-content:center;">
                                            <i class="bi bi-box" style="font-size:16px; color:#6366f1;"></i>
                                        </div>
                                        <strong><?= htmlspecialchars($product['product_name']) ?></strong>
                                    </div>
                                </td>
                                <td>
                                    <span class="badge bg-info bg-opacity-10 text-info" 
                                          style="border-radius:20px; padding:6px 12px; font-weight:600;">
                                        <?= htmlspecialchars($product['category_name']) ?>
                                    </span>
                                </td>
                                <td>
                                    <?php if (!empty($product['barcode'])) : ?>
                                        <span style="font-size:11px;font-weight:600;color:var(--text-main);background:var(--hover-bg);padding:3px 8px;border-radius:6px;font-family:monospace;">
                                            <?= htmlspecialchars($product['barcode']) ?>
                                        </span>
                                    <?php else : ?>
                                        <a href="barcode_generator.php" style="font-size:11px;color:#f59e0b;font-weight:600;text-decoration:none;">
                                            <i class="bi bi-plus-circle me-1"></i>Assign
                                        </a>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span style="color:#64748b; font-size:14px;">
                                        ₹<?= number_format($product['cost_price'], 2) ?>
                                    </span>
                                </td>
                                <td>
                                    <strong style="color:#10b981; font-size:15px;">
                                        ₹<?= number_format($product['price'], 2) ?>
                                    </strong>
                                </td>
                                <td>
                                    <div class="d-flex flex-column">
                                        <strong style="color:<?= $profit_color ?>; font-size:16px;">
                                            <?= number_format($profit_percent, 1) ?>%
                                        </strong>
                                        <small style="color:#64748b; font-size:11px;">
                                            (₹<?= number_format($profit, 2) ?>)
                                        </small>
                                    </div>
                                </td>
                                <td>
                                    <strong style="color: <?php
                                        if ($product['quantity'] == 0) echo '#dc3545';
                                        elseif ($product['quantity'] < 5) echo '#f8961e';
                                        else echo '#198754';
                                    ?>; font-size:16px;">
                                        <?= $product['quantity'] ?>
                                    </strong>
                                </td>
                                <td>
                                    <?php if ($product['quantity'] == 0) : ?>
                                        <span class="badge" style="background:#f72585; color:white; border-radius:20px; padding:5px 12px; font-size:11px;">
                                            Out of Stock
                                        </span>
                                    <?php elseif ($product['quantity'] < 5) : ?>
                                        <span class="badge" style="background:#fef3c7; color:#92400e; border-radius:20px; padding:5px 12px; font-size:11px; font-weight:600;">
                                            ⚠️ Low Stock
                                        </span>
                                    <?php else : ?>
                                        <span class="badge" style="background:#d1fae5; color:#065f46; border-radius:20px; padding:5px 12px; font-size:11px; font-weight:600;">
                                            ✅ In Stock
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="d-flex gap-1">
                                        <a href="edit.php?id=<?= $product['id'] ?>" 
                                           class="btn btn-sm btn-outline-primary" 
                                           title="Edit Product">
                                            <i class="bi bi-pencil"></i>
                                        </a>
                                        <a href="index.php?delete=<?= $product['id'] ?>" 
                                           class="btn btn-sm btn-outline-danger"
                                           onclick="return confirm('Are you sure you want to delete this product?');"
                                           title="Delete Product">
                                            <i class="bi bi-trash"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else : ?>
                        <tr>
                            <td colspan="9" class="text-center py-5" style="color:#aaa;">
                                <i class="bi bi-box-seam" style="font-size:60px; opacity:0.3;"></i>
                                <p class="mt-3 mb-0" style="font-size:15px;">No products found!</p>
                                <a href="add.php" class="btn btn-primary btn-sm mt-3">
                                    <i class="bi bi-plus-circle me-1"></i>Add Your First Product
                                </a>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Profit Legend Card -->
<div class="card mt-4" style="border:2px dashed #e2e8f0;">
    <div class="card-body">
        <div class="row g-3 align-items-center">
            <div class="col-md-3">
                <strong style="color:#0f172a; font-size:14px;">
                    <i class="bi bi-lightbulb me-2" style="color:#f59e0b;"></i>
                    Quick Guide:
                </strong>
            </div>
            <div class="col-md-9">
                <div class="d-flex flex-wrap gap-4" style="font-size:13px;">
                    <div>
                        <strong style="color:#10b981;">High Profit:</strong>
                        <span class="text-muted">30% or more margin</span>
                    </div>
                    <div>
                        <strong style="color:#f59e0b;">Medium Profit:</strong>
                        <span class="text-muted">15-30% margin</span>
                    </div>
                    <div>
                        <strong style="color:#ef4444;">Low Profit:</strong>
                        <span class="text-muted">Less than 15% margin</span>
                    </div>
                    <div>
                        <strong style="color:#6366f1;">Formula:</strong>
                        <span class="text-muted">Profit % = (Selling - Cost) / Cost × 100</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>