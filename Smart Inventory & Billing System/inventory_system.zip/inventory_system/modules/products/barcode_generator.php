<?php
// modules/products/barcode_generator.php
$page_title = "Barcode Generator";
session_start();
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../includes/auth_check.php';
requireManager();

// Handle assign-barcode POST (for products without one)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['assign_barcode'])) {
    $pid  = (int)$_POST['product_id'];
    $code = mysqli_real_escape_string($conn, trim($_POST['barcode_code']));
    if ($pid && $code) {
        // Check duplicate
        $dup = mysqli_query($conn, "SELECT id FROM products WHERE barcode='$code' AND id!=$pid");
        if (mysqli_num_rows($dup) > 0) {
            $_SESSION['error'] = "⚠️ Barcode '$code' already assigned to another product!";
        } else {
            mysqli_query($conn, "UPDATE products SET barcode='$code' WHERE id=$pid");
            $_SESSION['success'] = "✅ Barcode assigned successfully!";
        }
    }
    header("Location: barcode_generator.php"); exit();
}

// Fetch filter
$filter    = isset($_GET['filter']) ? $_GET['filter'] : 'all'; // all | with | without
$search    = isset($_GET['search']) ? trim($_GET['search']) : '';
$selected  = isset($_GET['ids'])    ? array_map('intval', explode(',', $_GET['ids'])) : [];

$where = "WHERE 1=1";
if ($filter === 'with')    $where .= " AND (p.barcode IS NOT NULL AND p.barcode != '')";
if ($filter === 'without') $where .= " AND (p.barcode IS NULL  OR  p.barcode = '')";
if (!empty($search))       $where .= " AND p.product_name LIKE '%" . mysqli_real_escape_string($conn,$search) . "%'";

$products = mysqli_query($conn,
    "SELECT p.*, c.category_name FROM products p
     LEFT JOIN categories c ON p.category_id = c.id
     $where ORDER BY p.product_name ASC"
);
$products_arr = [];
while ($r = mysqli_fetch_assoc($products)) $products_arr[] = $r;

$with_count    = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as t FROM products WHERE barcode IS NOT NULL AND barcode!=''"))['t'];
$without_count = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as t FROM products WHERE barcode IS NULL OR barcode=''"))['t'];

require_once __DIR__ . '/../../includes/header.php';
?>

<!-- JsBarcode library -->
<script src="https://cdn.jsdelivr.net/npm/jsbarcode@3.11.6/dist/JsBarcode.all.min.js"></script>

<style>
.bc-stat{background:var(--card-bg);border:1px solid var(--border-color);border-radius:14px;padding:18px 20px;}
.bc-stat::before{content:'';display:block;height:3px;border-radius:14px 14px 0 0;margin:-18px -20px 14px;border-radius:14px 14px 0 0;}
.bcs1::before{background:linear-gradient(90deg,#6366f1,#8b5cf6);}
.bcs2::before{background:linear-gradient(90deg,#10b981,#06b6d4);}
.bcs3::before{background:linear-gradient(90deg,#f59e0b,#f97316);}

.fp{display:inline-flex;align-items:center;gap:6px;padding:6px 16px;border-radius:50px;border:2px solid var(--border-color);font-size:12px;font-weight:600;color:var(--text-muted);text-decoration:none;transition:all .2s;background:var(--card-bg);}
.fp:hover,.fp.fa{border-color:#6366f1;color:#4f46e5;background:rgba(99,102,241,.08);}
.fp.fw:hover,.fp.fw.fa{border-color:#10b981;color:#059669;background:rgba(16,185,129,.08);}
.fp.fo:hover,.fp.fo.fa{border-color:#f59e0b;color:#d97706;background:rgba(245,158,11,.08);}

.prod-row{display:flex;align-items:center;gap:12px;padding:12px 16px;border-radius:12px;border:2px solid var(--border-color);background:var(--card-bg);cursor:pointer;transition:all .2s;margin-bottom:8px;}
.prod-row:hover{border-color:#6366f1;background:rgba(99,102,241,.04);}
.prod-row.selected{border-color:#6366f1;background:rgba(99,102,241,.08);}
.prod-row.no-barcode{border-color:var(--border-color);border-style:dashed;}
.prod-av{width:40px;height:40px;border-radius:10px;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:15px;flex-shrink:0;}
.prod-check{width:20px;height:20px;border-radius:6px;border:2px solid var(--border-color);display:flex;align-items:center;justify-content:center;flex-shrink:0;transition:all .2s;}
.prod-row.selected .prod-check{background:#6366f1;border-color:#6366f1;color:white;}

/* Print area */
.barcode-sheet{display:none;}
.barcode-label{display:inline-block;padding:8px 12px;border:1px solid #ddd;border-radius:6px;text-align:center;margin:4px;background:white;page-break-inside:avoid;}
.barcode-label .prod-title{font-size:10px;font-weight:700;color:#0f172a;margin-top:6px;max-width:120px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
.barcode-label .prod-price{font-size:11px;font-weight:800;color:#10b981;}
.barcode-label .prod-code{font-size:8px;color:#64748b;margin-top:1px;}

@media print {
    body > *:not(#printArea) { display: none !important; }
    #printArea {
        display: block !important;
        padding: 10mm;
    }
    .barcode-sheet { display: flex !important; flex-wrap: wrap; gap: 4mm; }
    .barcode-label { border: 1px solid #ccc; break-inside: avoid; }
    @page { margin: 10mm; size: A4; }
}

/* Assign modal */
.assign-modal{position:fixed;inset:0;z-index:10000;background:rgba(0,0,0,.5);display:flex;align-items:center;justify-content:center;backdrop-filter:blur(4px);}
.assign-box{background:var(--card-bg);border-radius:20px;padding:28px;width:420px;max-width:90vw;box-shadow:0 20px 60px rgba(0,0,0,.3);}
</style>

<!-- Header -->
<div class="d-flex align-items-center justify-content-between mb-4">
    <div>
        <h4 class="mb-1">🔲 Barcode Generator</h4>
        <p class="text-muted mb-0" style="font-size:14px;">Generate, assign and print barcodes for your products</p>
    </div>
    <div class="d-flex gap-2">
        <button class="btn btn-outline-primary" onclick="selectAll()"><i class="bi bi-check-all me-1"></i>Select All</button>
        <button class="btn btn-primary" onclick="printSelected()" id="printBtn" disabled>
            <i class="bi bi-printer me-2"></i>Print Selected (<span id="selCount">0</span>)
        </button>
        <a href="index.php" class="btn btn-light"><i class="bi bi-arrow-left me-2"></i>Back</a>
    </div>
</div>

<!-- Stats -->
<div class="row g-4 mb-4">
    <div class="col-md-4"><div class="bc-stat bcs1">
        <div class="d-flex align-items-center gap-3">
            <div style="width:42px;height:42px;border-radius:11px;background:rgba(99,102,241,.12);color:#6366f1;display:flex;align-items:center;justify-content:center;font-size:18px;"><i class="bi bi-boxes"></i></div>
            <div><div style="font-size:22px;font-weight:800;color:var(--text-main);"><?= count($products_arr) ?></div><div style="font-size:12px;color:var(--text-muted);">Total Products</div></div>
        </div>
    </div></div>
    <div class="col-md-4"><div class="bc-stat bcs2">
        <div class="d-flex align-items-center gap-3">
            <div style="width:42px;height:42px;border-radius:11px;background:rgba(16,185,129,.12);color:#10b981;display:flex;align-items:center;justify-content:center;font-size:18px;"><i class="bi bi-upc-scan"></i></div>
            <div><div style="font-size:22px;font-weight:800;color:var(--text-main);"><?= $with_count ?></div><div style="font-size:12px;color:var(--text-muted);">Have Barcodes</div></div>
        </div>
    </div></div>
    <div class="col-md-4"><div class="bc-stat bcs3">
        <div class="d-flex align-items-center gap-3">
            <div style="width:42px;height:42px;border-radius:11px;background:rgba(245,158,11,.12);color:#f59e0b;display:flex;align-items:center;justify-content:center;font-size:18px;"><i class="bi bi-exclamation-circle"></i></div>
            <div><div style="font-size:22px;font-weight:800;color:var(--text-main);"><?= $without_count ?></div><div style="font-size:12px;color:var(--text-muted);">Need Barcodes</div></div>
        </div>
    </div></div>
</div>

<!-- Filter + Search -->
<div class="card mb-4">
    <div class="card-body">
        <form method="GET" class="row g-3 align-items-end">
            <div class="col-md-5">
                <label class="form-label">Search Product</label>
                <input type="text" name="search" class="form-control" placeholder="Product name..." value="<?= htmlspecialchars($search) ?>">
                <input type="hidden" name="filter" value="<?= htmlspecialchars($filter) ?>">
            </div>
            <div class="col-md-5">
                <label class="form-label">Filter</label>
                <div class="d-flex gap-2 flex-wrap">
                    <a href="?filter=all&search=<?= urlencode($search) ?>"     class="fp    <?= $filter==='all'?'fa':'' ?>">All Products</a>
                    <a href="?filter=with&search=<?= urlencode($search) ?>"    class="fp fw <?= $filter==='with'?'fa':'' ?>"><i class="bi bi-check-circle"></i> Has Barcode</a>
                    <a href="?filter=without&search=<?= urlencode($search) ?>" class="fp fo <?= $filter==='without'?'fa':'' ?>"><i class="bi bi-exclamation-circle"></i> No Barcode</a>
                </div>
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-primary w-100"><i class="bi bi-search me-1"></i>Search</button>
            </div>
        </form>
    </div>
</div>

<!-- Product List -->
<div class="card">
    <div class="card-header d-flex align-items-center justify-content-between">
        <span><i class="bi bi-list-ul me-2 text-primary"></i>Products (<?= count($products_arr) ?>)</span>
        <small class="text-muted">Click a product to select it for printing</small>
    </div>
    <div class="card-body">
        <?php if (count($products_arr) > 0) :
            $av_cols=['#6366f1','#10b981','#f59e0b','#ef4444','#06b6d4','#8b5cf6','#ec4899'];
            foreach ($products_arr as $i => $p) :
                $has_bc = !empty($p['barcode']);
                $col    = $av_cols[$i % count($av_cols)];
        ?>
        <div class="prod-row <?= !$has_bc ? 'no-barcode' : '' ?>"
             id="row-<?= $p['id'] ?>"
             onclick="toggleSelect(<?= $p['id'] ?>, <?= $has_bc ? 'true' : 'false' ?>, '<?= addslashes(htmlspecialchars($p['product_name'])) ?>', '<?= addslashes($p['barcode'] ?? '') ?>', '<?= $p['price'] ?>')"
             data-id="<?= $p['id'] ?>"
             data-name="<?= htmlspecialchars($p['product_name'], ENT_QUOTES) ?>"
             data-barcode="<?= htmlspecialchars($p['barcode'] ?? '', ENT_QUOTES) ?>"
             data-price="<?= $p['price'] ?>">

            <!-- Checkbox -->
            <div class="prod-check" id="chk-<?= $p['id'] ?>">
                <i class="bi bi-check2" style="font-size:13px;display:none;" id="chkicon-<?= $p['id'] ?>"></i>
            </div>

            <!-- Avatar -->
            <div class="prod-av" style="background:<?= $col ?>20;color:<?= $col ?>;">
                <?= strtoupper(substr($p['product_name'], 0, 1)) ?>
            </div>

            <!-- Info -->
            <div style="flex:1;min-width:0;">
                <div style="font-size:14px;font-weight:700;color:var(--text-main);"><?= htmlspecialchars($p['product_name']) ?></div>
                <div style="font-size:12px;color:var(--text-muted);"><?= htmlspecialchars($p['category_name'] ?? '') ?> · ₹<?= number_format($p['price'], 2) ?></div>
            </div>

            <!-- Barcode preview or assign -->
            <div style="text-align:right;flex-shrink:0;">
                <?php if ($has_bc) : ?>
                    <div style="font-size:11px;font-weight:700;color:#10b981;margin-bottom:2px;">
                        <i class="bi bi-upc-scan me-1"></i><?= htmlspecialchars($p['barcode']) ?>
                    </div>
                    <svg id="bcsvg-<?= $p['id'] ?>" style="display:block;"></svg>
                <?php else : ?>
                    <button type="button"
                            class="btn btn-sm btn-outline-warning"
                            onclick="event.stopPropagation(); openAssign(<?= $p['id'] ?>, '<?= addslashes(htmlspecialchars($p['product_name'])) ?>')"
                            style="font-size:11px;">
                        <i class="bi bi-plus me-1"></i>Assign Barcode
                    </button>
                <?php endif; ?>
            </div>

            <!-- Stock badge -->
            <div style="flex-shrink:0;">
                <span style="font-size:11px;font-weight:700;padding:3px 10px;border-radius:20px;
                    background:<?= $p['quantity']==0?'rgba(239,68,68,.12)':($p['quantity']<5?'rgba(245,158,11,.12)':'rgba(16,185,129,.12)') ?>;
                    color:<?= $p['quantity']==0?'#dc2626':($p['quantity']<5?'#d97706':'#059669') ?>;">
                    <?= $p['quantity'] ?> units
                </span>
            </div>
        </div>
        <?php endforeach; else : ?>
        <div class="text-center py-5 text-muted">
            <i class="bi bi-box-seam" style="font-size:48px;opacity:.2;"></i>
            <p class="mt-3 mb-0">No products found</p>
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- Hidden print area -->
<div id="printArea">
    <div class="barcode-sheet" id="barcodeSheet"></div>
</div>

<!-- Assign Barcode Modal -->
<div id="assignModal" style="display:none;" class="assign-modal" onclick="if(event.target===this)closeAssign()">
    <div class="assign-box">
        <h5 style="font-weight:700;margin-bottom:4px;">Assign Barcode</h5>
        <p id="assignProductName" style="font-size:13px;color:var(--text-muted);margin-bottom:18px;"></p>
        <form method="POST">
            <input type="hidden" name="assign_barcode" value="1">
            <input type="hidden" name="product_id" id="assignProductId">
            <div class="mb-3">
                <label class="form-label" style="font-weight:600;">Barcode / SKU</label>
                <div class="input-group">
                    <input type="text" name="barcode_code" id="assignBarcodeInput" class="form-control form-control-lg" placeholder="Scan or type code..." required>
                    <button type="button" class="btn btn-outline-secondary" onclick="genCode()" title="Auto-generate">
                        <i class="bi bi-magic"></i>
                    </button>
                </div>
                <div style="font-size:11px;color:var(--text-muted);margin-top:6px;">Use USB scanner to scan physical barcode, or auto-generate a new one</div>
            </div>
            <!-- Live preview -->
            <div id="previewWrap" style="text-align:center;padding:14px;background:white;border-radius:10px;border:1px solid var(--border-color);margin-bottom:16px;min-height:60px;">
                <svg id="previewSvg"></svg>
                <div id="previewEmpty" style="color:#94a3b8;font-size:13px;padding:10px 0;">Enter a barcode to preview</div>
            </div>
            <div class="d-flex gap-2">
                <button type="submit" class="btn btn-primary flex-fill"><i class="bi bi-check-circle me-2"></i>Save Barcode</button>
                <button type="button" class="btn btn-light" onclick="closeAssign()">Cancel</button>
            </div>
        </form>
    </div>
</div>

<script>
// ── State ──────────────────────────────────────────────
var selectedProducts = []; // [{id, name, barcode, price}]

// ── Render small barcodes inline on page load ──────────
document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('[id^="bcsvg-"]').forEach(function(svg) {
        var row     = svg.closest('.prod-row');
        var barcode = row ? row.getAttribute('data-barcode') : '';
        if (barcode) {
            try {
                JsBarcode(svg, barcode, {
                    format:      'CODE128',
                    width:       1.2,
                    height:      28,
                    displayValue:false,
                    margin:      0,
                    background:  'transparent',
                });
            } catch(e) {
                svg.style.display = 'none';
            }
        }
    });
});

// ── Select / Deselect ─────────────────────────────────
function toggleSelect(id, hasBarcode, name, barcode, price) {
    var idx = selectedProducts.findIndex(function(p){ return p.id === id; });
    if (idx > -1) {
        selectedProducts.splice(idx, 1);
        document.getElementById('row-' + id).classList.remove('selected');
        document.getElementById('chkicon-' + id).style.display = 'none';
    } else {
        // Products without barcodes: auto-generate one
        if (!hasBarcode || !barcode) {
            barcode = String(Math.floor(100000000000 + Math.random() * 900000000000));
        }
        selectedProducts.push({ id: id, name: name, barcode: barcode, price: price });
        document.getElementById('row-' + id).classList.add('selected');
        document.getElementById('chkicon-' + id).style.display = 'block';
    }
    updateUI();
}

function selectAll() {
    selectedProducts = [];
    document.querySelectorAll('.prod-row').forEach(function(row) {
        var id      = parseInt(row.getAttribute('data-id'));
        var name    = row.getAttribute('data-name');
        var barcode = row.getAttribute('data-barcode');
        var price   = row.getAttribute('data-price');
        if (!barcode) barcode = String(Math.floor(100000000000 + Math.random() * 900000000000));
        selectedProducts.push({ id:id, name:name, barcode:barcode, price:price });
        row.classList.add('selected');
        var icon = document.getElementById('chkicon-' + id);
        if (icon) icon.style.display = 'block';
    });
    updateUI();
}

function updateUI() {
    var count = selectedProducts.length;
    document.getElementById('selCount').textContent = count;
    document.getElementById('printBtn').disabled    = (count === 0);
}

// ── Print ─────────────────────────────────────────────
function printSelected() {
    var sheet = document.getElementById('barcodeSheet');
    sheet.innerHTML = '';

    selectedProducts.forEach(function(p) {
        var label    = document.createElement('div');
        label.className = 'barcode-label';

        var svg = document.createElementNS('http://www.w3.org/2000/svg','svg');
        label.appendChild(svg);

        var title = document.createElement('div');
        title.className = 'prod-title';
        title.textContent = p.name;
        label.appendChild(title);

        var price = document.createElement('div');
        price.className = 'prod-price';
        price.textContent = '₹' + parseFloat(p.price).toFixed(2);
        label.appendChild(price);

        var code = document.createElement('div');
        code.className = 'prod-code';
        code.textContent = p.barcode;
        label.appendChild(code);

        sheet.appendChild(label);

        try {
            JsBarcode(svg, p.barcode, {
                format:      'CODE128',
                width:       1.8,
                height:      50,
                displayValue:false,
                margin:      2,
                background:  '#ffffff',
            });
        } catch(e) {}
    });

    window.print();
}

// ── Assign Barcode Modal ──────────────────────────────
function openAssign(id, name) {
    document.getElementById('assignProductId').value  = id;
    document.getElementById('assignProductName').textContent = name;
    document.getElementById('assignBarcodeInput').value = '';
    document.getElementById('previewSvg').innerHTML    = '';
    document.getElementById('previewEmpty').style.display = 'block';
    document.getElementById('assignModal').style.display = 'flex';
    setTimeout(function(){ document.getElementById('assignBarcodeInput').focus(); }, 100);
}

function closeAssign() {
    document.getElementById('assignModal').style.display = 'none';
}

function genCode() {
    var code = String(Math.floor(100000000000 + Math.random() * 900000000000));
    document.getElementById('assignBarcodeInput').value = code;
    renderPreview(code);
}

document.addEventListener('DOMContentLoaded', function() {
    var inp = document.getElementById('assignBarcodeInput');
    if (inp) {
        inp.addEventListener('input', function() { renderPreview(this.value.trim()); });
    }
});

function renderPreview(code) {
    var svg   = document.getElementById('previewSvg');
    var empty = document.getElementById('previewEmpty');
    if (!code || code.length < 3) {
        svg.innerHTML   = '';
        empty.style.display = 'block';
        return;
    }
    try {
        JsBarcode(svg, code, {
            format:       'CODE128',
            width:        2,
            height:       60,
            displayValue: true,
            fontSize:     12,
            margin:       6,
            background:   '#ffffff',
        });
        empty.style.display = 'none';
    } catch(e) {
        svg.innerHTML   = '';
        empty.style.display = 'block';
    }
}
</script>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
