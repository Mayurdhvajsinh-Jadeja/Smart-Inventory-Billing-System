<?php
// modules/billing/list.php
$page_title = "All Bills";
session_start();
require_once __DIR__ . '/../../config/db.php';

if (isset($_GET['delete'])) {
    $del = (int)$_GET['delete'];
    mysqli_query($conn,"DELETE FROM bill_items WHERE bill_id=$del");
    if(mysqli_query($conn,"DELETE FROM bills WHERE id=$del"))
        $_SESSION['success']="✅ Bill deleted!";
    else
        $_SESSION['error']="❌ Failed to delete bill!";
    header("Location: list.php"); exit();
}

$limit=10; $page=isset($_GET['page'])?(int)$_GET['page']:1; $start=($page-1)*$limit;
$search=isset($_GET['search'])?trim($_GET['search']):'';
$status_filter=isset($_GET['status'])?$_GET['status']:'';

$where="WHERE 1=1";
if(!empty($search)) $where.=" AND (customer_name LIKE '%".mysqli_real_escape_string($conn,$search)."%' OR id LIKE '%".mysqli_real_escape_string($conn,$search)."%')";
if(!empty($status_filter)&&in_array($status_filter,['Paid','Partial','Pending'])) $where.=" AND status='".mysqli_real_escape_string($conn,$status_filter)."'";

$bills=mysqli_query($conn,"SELECT * FROM bills $where ORDER BY id DESC LIMIT $start,$limit");
$total_bills=mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as t FROM bills $where"))['t'];
$total_pages=ceil($total_bills/$limit);

$today=date('Y-m-d');
$ts=mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as c,COALESCE(SUM(total_amount),0) as t FROM bills WHERE DATE(bill_date)='$today'"));
$total_revenue=mysqli_fetch_assoc(mysqli_query($conn,"SELECT COALESCE(SUM(total_amount),0) as t FROM bills"))['t'];
$pending_amt  =mysqli_fetch_assoc(mysqli_query($conn,"SELECT COALESCE(SUM(due_amount),0) as t FROM bills WHERE status!='Paid'"))['t'];

require_once __DIR__ . '/../../includes/header.php';
?>
<style>
.bill-stat{background:var(--card-bg);border:1px solid var(--border-color);border-radius:16px;padding:20px;height:100%;position:relative;overflow:hidden;}
.bill-stat::before{content:'';position:absolute;top:0;left:0;right:0;height:3px;border-radius:16px 16px 0 0;}
.bs-blue::before{background:linear-gradient(90deg,#6366f1,#8b5cf6);}
.bs-green::before{background:linear-gradient(90deg,#10b981,#06b6d4);}
.bs-amber::before{background:linear-gradient(90deg,#f59e0b,#f97316);}
.bs-red::before{background:linear-gradient(90deg,#ef4444,#ec4899);}
.bs-icon{width:44px;height:44px;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0;}
.bs-val{font-size:24px;font-weight:800;color:var(--text-main);line-height:1;}
.bs-lbl{font-size:12px;color:var(--text-muted);margin-top:3px;}
.filter-pill{display:inline-flex;align-items:center;gap:6px;padding:7px 16px;border-radius:50px;border:2px solid var(--border-color);font-size:12px;font-weight:600;color:var(--text-muted);text-decoration:none;transition:all .2s;background:var(--card-bg);}
.filter-pill:hover,.filter-pill.active{border-color:var(--primary);color:var(--primary);background:rgba(99,102,241,.08);}
.filter-pill.fp-paid.active{border-color:#10b981;color:#10b981;background:rgba(16,185,129,.08);}
.filter-pill.fp-partial.active{border-color:#f59e0b;color:#f59e0b;background:rgba(245,158,11,.08);}
.filter-pill.fp-pending.active{border-color:#ef4444;color:#ef4444;background:rgba(239,68,68,.08);}
.bill-table-wrap .table tbody tr{transition:all .2s;}
.bill-table-wrap .table tbody tr:hover{background:var(--hover-bg);}
</style>

<!-- Header -->
<div class="d-flex align-items-center justify-content-between mb-4">
    <div>
        <h4 class="mb-1">📋 All Bills</h4>
        <p class="text-muted mb-0" style="font-size:14px;"><?= $total_bills ?> total bills</p>
    </div>
    <div class="d-flex gap-2">
        <a href="<?=$base_url?>/exports/bills_excel.php<?= !empty($search)?'?search='.urlencode($search):'' ?>" class="btn btn-success">
            <i class="bi bi-file-excel me-2"></i>Export Excel
        </a>
        <a href="create.php" class="btn btn-primary">
            <i class="bi bi-plus-circle me-2"></i>New Bill
        </a>
    </div>
</div>

<!-- Stat cards -->
<div class="row g-4 mb-4">
    <div class="col-lg-3 col-md-6"><div class="bill-stat bs-blue">
        <div class="d-flex align-items-center gap-3"><div class="bs-icon" style="background:rgba(99,102,241,.12);color:#6366f1;"><i class="bi bi-receipt-cutoff"></i></div><div><div class="bs-val"><?= $ts['c'] ?></div><div class="bs-lbl">Today's Bills</div></div></div>
    </div></div>
    <div class="col-lg-3 col-md-6"><div class="bill-stat bs-green">
        <div class="d-flex align-items-center gap-3"><div class="bs-icon" style="background:rgba(16,185,129,.12);color:#10b981;"><i class="bi bi-currency-rupee"></i></div><div><div class="bs-val">₹<?= number_format($ts['t'],0) ?></div><div class="bs-lbl">Today's Revenue</div></div></div>
    </div></div>
    <div class="col-lg-3 col-md-6"><div class="bill-stat bs-amber">
        <div class="d-flex align-items-center gap-3"><div class="bs-icon" style="background:rgba(245,158,11,.12);color:#f59e0b;"><i class="bi bi-graph-up-arrow"></i></div><div><div class="bs-val">₹<?= number_format($total_revenue,0) ?></div><div class="bs-lbl">Total Revenue</div></div></div>
    </div></div>
    <div class="col-lg-3 col-md-6"><div class="bill-stat bs-red">
        <div class="d-flex align-items-center gap-3"><div class="bs-icon" style="background:rgba(239,68,68,.12);color:#ef4444;"><i class="bi bi-clock-history"></i></div><div><div class="bs-val">₹<?= number_format($pending_amt,0) ?></div><div class="bs-lbl">Pending Amount</div></div></div>
    </div></div>
</div>

<!-- Search + Filter -->
<div class="card mb-4">
    <div class="card-body">
        <form method="GET">
            <div class="row g-3 align-items-end">
                <div class="col-md-6">
                    <label class="form-label">Search Bills</label>
                    <input type="text" name="search" class="form-control" placeholder="Bill ID or customer name..." value="<?= htmlspecialchars($search) ?>">
                </div>
                <div class="col-md-4">
                    <label class="form-label">Status Filter</label>
                    <div class="d-flex gap-2 flex-wrap">
                        <a href="?search=<?=urlencode($search)?>" class="filter-pill <?= empty($status_filter)?'active':'' ?>">All</a>
                        <a href="?status=Paid&search=<?=urlencode($search)?>" class="filter-pill fp-paid <?= $status_filter==='Paid'?'active':'' ?>"><i class="bi bi-check-circle"></i> Paid</a>
                        <a href="?status=Partial&search=<?=urlencode($search)?>" class="filter-pill fp-partial <?= $status_filter==='Partial'?'active':'' ?>"><i class="bi bi-dash-circle"></i> Partial</a>
                        <a href="?status=Pending&search=<?=urlencode($search)?>" class="filter-pill fp-pending <?= $status_filter==='Pending'?'active':'' ?>"><i class="bi bi-x-circle"></i> Pending</a>
                    </div>
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary w-100"><i class="bi bi-search me-1"></i>Search</button>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- Table -->
<div class="card bill-table-wrap">
    <div class="card-header d-flex align-items-center justify-content-between">
        <span><i class="bi bi-list-check me-2 text-primary"></i>Bills (<?= $total_bills ?>)</span>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table mb-0">
                <thead><tr>
                    <th>Bill</th><th>Customer</th><th>Total</th><th>Paid</th><th>Due</th><th>Status</th><th>Payment</th><th>Date</th><th>Actions</th>
                </tr></thead>
                <tbody>
                <?php if($total_bills>0):
                    $av=['#6366f1','#10b981','#f59e0b','#ef4444','#06b6d4','#8b5cf6','#ec4899']; $i=0;
                    while($b=mysqli_fetch_assoc($bills)):
                        $col=$av[$i%7]; $i++;
                        $sc=$b['status']==='Paid'?'background:#d1fae5;color:#065f46;':($b['status']==='Partial'?'background:#fef3c7;color:#92400e;':'background:#fee2e2;color:#991b1b;');
                ?>
                <tr>
                    <td><strong style="background:linear-gradient(135deg,var(--primary),var(--secondary));-webkit-background-clip:text;-webkit-text-fill-color:transparent;font-size:15px;">#<?= str_pad($b['id'],4,'0',STR_PAD_LEFT) ?></strong></td>
                    <td><div class="d-flex align-items-center gap-2">
                        <div style="width:34px;height:34px;border-radius:10px;background:<?=$col?>22;color:<?=$col?>;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:13px;flex-shrink:0;"><?=strtoupper(substr($b['customer_name'],0,1))?></div>
                        <strong style="font-size:13px;"><?=htmlspecialchars($b['customer_name'])?></strong>
                    </div></td>
                    <td><strong>₹<?=number_format($b['total_amount'],2)?></strong></td>
                    <td style="color:#10b981;font-weight:600;">₹<?=number_format($b['paid_amount'],2)?></td>
                    <td style="color:<?=$b['due_amount']>0?'#ef4444':'var(--text-muted)'?>;font-weight:<?=$b['due_amount']>0?'700':'400'?>;"><?=$b['due_amount']>0?'₹'.number_format($b['due_amount'],2):'-'?></td>
                    <td><span style="font-size:11px;font-weight:700;padding:4px 12px;border-radius:20px;<?=$sc?>"><?=$b['status']?></span></td>
                    <td><span style="font-size:12px;color:var(--text-muted);"><?=$b['payment_mode']?></span></td>
                    <td style="color:var(--text-muted);font-size:13px;"><?=date('d M Y',strtotime($b['bill_date']))?></td>
                    <td><div class="d-flex gap-1">
                        <?php if($b['due_amount']>0&&!empty($b['customer_id'])):?>
                        <button onclick="openPayModal(<?=$b['customer_id']?>,<?=$b['due_amount']?>)" class="btn btn-sm btn-outline-success" title="Collect Payment"><i class="bi bi-cash-coin"></i></button>
                        <?php endif;?>
                        <a href="view.php?id=<?=$b['id']?>" class="btn btn-sm btn-outline-primary" title="View"><i class="bi bi-eye"></i></a>
                        <a href="list.php?delete=<?=$b['id']?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete this bill?')" title="Delete"><i class="bi bi-trash"></i></a>
                    </div></td>
                </tr>
                <?php endwhile; else:?>
                <tr><td colspan="9" class="text-center py-5" style="color:var(--text-muted);"><i class="bi bi-inbox" style="font-size:48px;opacity:.3;"></i><p class="mt-3 mb-0">No bills found!</p></td></tr>
                <?php endif;?>
                </tbody>
            </table>
        </div>
    </div>
    <?php if($total_pages>1):?>
    <div class="card-footer">
        <nav><ul class="pagination justify-content-center mb-0" style="gap:4px;">
            <?php for($p=1;$p<=$total_pages;$p++):?>
            <li class="page-item <?=($p==$page)?'active':''?>">
                <a class="page-link" href="?page=<?=$p?>&search=<?=urlencode($search)?>&status=<?=urlencode($status_filter)?>" style="border-radius:8px;"><?=$p?></a>
            </li>
            <?php endfor;?>
        </ul></nav>
    </div>
    <?php endif;?>
</div>

<!-- Pay Modal -->
<div class="modal fade" id="quickPayModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header" style="background:linear-gradient(135deg,#10b981,#059669);">
                <h5 class="modal-title text-white"><i class="bi bi-cash-stack me-2"></i>Collect Due Payment</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form action="../customers/collect_payment.php" method="POST">
                <input type="hidden" name="customer_id" id="modalCustomerId">
                <input type="hidden" name="redirect_to" value="bills">
                <div class="modal-body p-4">
                    <div class="alert alert-warning d-flex align-items-center gap-3">
                        <i class="bi bi-exclamation-circle-fill" style="font-size:22px;"></i>
                        <div>Outstanding: <h4 class="mb-0 text-danger fw-bold" id="modalDueDisplay">₹0.00</h4></div>
                    </div>
                    <div class="mb-3"><label class="form-label fw-bold">Amount (₹)</label>
                        <div class="input-group"><span class="input-group-text">₹</span><input type="number" name="amount" id="modalAmountInput" class="form-control form-control-lg fw-bold" step="0.01" required></div>
                    </div>
                    <div class="row g-3 mb-3">
                        <div class="col-6"><label class="form-label fw-bold">Date</label><input type="date" name="payment_date" class="form-control" value="<?=date('Y-m-d')?>" required></div>
                        <div class="col-6"><label class="form-label fw-bold">Mode</label><select name="payment_mode" class="form-select"><option value="Cash">💵 Cash</option><option value="UPI">📱 UPI</option><option value="Bank Transfer">🏦 Bank</option></select></div>
                    </div>
                    <div><label class="form-label fw-bold">Note</label><input type="text" name="note" class="form-control" placeholder="Optional..."></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-success px-4"><i class="bi bi-check-lg me-2"></i>Confirm Payment</button>
                </div>
            </form>
        </div>
    </div>
</div>
<script>
function openPayModal(cid,due){
    document.getElementById('modalCustomerId').value=cid;
    document.getElementById('modalDueDisplay').innerText='₹'+parseFloat(due).toFixed(2);
    document.getElementById('modalAmountInput').value=parseFloat(due).toFixed(2);
    new bootstrap.Modal(document.getElementById('quickPayModal')).show();
}
</script>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
