<?php
// modules/billing/view.php

session_start();
require_once __DIR__ . '/../../config/db.php';

$bill_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($bill_id == 0) { header("Location: list.php"); exit(); }

$bill_query = mysqli_query($conn, "SELECT * FROM bills WHERE id = $bill_id");
if (mysqli_num_rows($bill_query) == 0) {
    $_SESSION['error'] = "❌ Bill not found!";
    header("Location: list.php"); exit();
}
$bill = mysqli_fetch_assoc($bill_query);

$items_query = mysqli_query($conn,
    "SELECT bi.*, p.product_name
     FROM bill_items bi
     LEFT JOIN products p ON bi.product_id = p.id
     WHERE bi.bill_id = $bill_id"
);

// Build WhatsApp message
$items_text = "";
$sr = 1;
$items_copy = mysqli_query($conn,
    "SELECT bi.*, p.product_name
     FROM bill_items bi
     LEFT JOIN products p ON bi.product_id = p.id
     WHERE bi.bill_id = $bill_id"
);
while ($item = mysqli_fetch_assoc($items_copy)) {
    $items_text .= $sr++ . ". " . $item['product_name'] .
                   " x" . $item['quantity'] .
                   " = ₹" . number_format($item['quantity'] * $item['price'], 2) . "\n";
}

// GST info for WhatsApp
$gst_line = "";
$has_gst  = isset($bill['gst_type']) && $bill['gst_type'] !== 'none' && $bill['gst_amount'] > 0;
if ($has_gst) {
    if ($bill['gst_type'] === 'intra') {
        $half = $bill['gst_rate'] / 2;
        $gst_line  = "CGST ({$half}%): ₹" . number_format($bill['cgst_amount'], 2) . "\n";
        $gst_line .= "SGST ({$half}%): ₹" . number_format($bill['sgst_amount'], 2) . "\n";
    } else {
        $gst_line = "IGST ({$bill['gst_rate']}%): ₹" . number_format($bill['igst_amount'], 2) . "\n";
    }
}

$subtotal_line = $has_gst ? "Subtotal: ₹" . number_format($bill['subtotal'] ?? $bill['total_amount'], 2) . "\n" : "";

$wa_message = "🧾 *Invoice #{$bill['id']}*\n" .
              "📅 " . date('d M Y', strtotime($bill['bill_date'])) . "\n" .
              "👤 Customer: {$bill['customer_name']}\n\n" .
              "*Items:*\n" . $items_text . "\n" .
              $subtotal_line .
              $gst_line .
              "*Total: ₹" . number_format($bill['total_amount'], 2) . "*\n" .
              "💳 Payment: {$bill['payment_mode']}\n\n" .
              "Thank you for your business! 🙏";

$wa_url = "https://wa.me/?text=" . rawurlencode($wa_message);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invoice #<?= str_pad($bill['id'], 4, '0', STR_PAD_LEFT) ?> | Smart Inventory</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');

        body { font-family: 'Inter', sans-serif; background: #f8f9fa; }

        .invoice-container {
            max-width: 900px; margin: 30px auto; background: white;
            padding: 50px; border-radius: 20px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
        }

        .invoice-header {
            display: flex; justify-content: space-between; align-items: start;
            margin-bottom: 40px; padding-bottom: 30px; border-bottom: 3px solid #6366f1;
        }

        .company-logo {
            font-size: 48px;
            background: linear-gradient(135deg, #6366f1, #ec4899);
            -webkit-background-clip: text; -webkit-text-fill-color: transparent;
        }

        .company-name { font-size: 28px; font-weight: 800; color: #0f172a; margin: 0; }
        .company-tagline { color: #64748b; font-size: 14px; }

        .invoice-number {
            font-size: 36px; font-weight: 800; margin: 0;
            background: linear-gradient(135deg, #6366f1, #ec4899);
            -webkit-background-clip: text; -webkit-text-fill-color: transparent;
        }

        .invoice-date { color: #64748b; font-size: 14px; }

        .invoice-details {
            display: grid; grid-template-columns: 1fr 1fr;
            gap: 20px; margin-bottom: 40px;
        }

        .detail-box {
            background: #f8fafc; padding: 18px; border-radius: 12px;
            border-left: 4px solid #6366f1;
        }

        .detail-label {
            font-size: 11px; color: #64748b; font-weight: 700;
            text-transform: uppercase; letter-spacing: 1px; margin-bottom: 6px;
        }

        .detail-value { font-size: 17px; font-weight: 700; color: #0f172a; }

        .invoice-table { width: 100%; margin-bottom: 20px; }
        .invoice-table thead { background: linear-gradient(135deg, #6366f1, #8b5cf6); color: white; }
        .invoice-table thead th {
            padding: 14px 15px; font-weight: 700; font-size: 12px;
            text-transform: uppercase; letter-spacing: 1px;
        }
        .invoice-table tbody td {
            padding: 14px 15px; border-bottom: 1px solid #e2e8f0; font-size: 14px;
        }
        .invoice-table tbody tr:last-child td { border-bottom: none; }

        /* GST Breakdown Box */
        .gst-breakdown {
            background: #fffbeb; border: 1px solid #fde68a;
            border-radius: 12px; padding: 20px; margin-bottom: 20px;
        }
        .gst-breakdown h6 {
            color: #92400e; font-weight: 700; font-size: 12px;
            text-transform: uppercase; letter-spacing: 1px; margin-bottom: 12px;
        }
        .gst-row { display: flex; justify-content: space-between; font-size: 14px; margin-bottom: 6px; }
        .gst-row span { color: #78350f; }
        .gst-row strong { color: #92400e; }

        .total-section {
            background: linear-gradient(135deg, #0f172a, #1e293b); color: white;
            padding: 28px 30px; border-radius: 12px; margin-top: 10px;
        }

        .total-row { display: flex; justify-content: space-between; align-items: center; }

        .payment-status {
            display: flex; gap: 20px; margin-top: 18px; padding-top: 18px;
            border-top: 1px solid rgba(255,255,255,0.15);
        }

        .pay-item { text-align: center; flex: 1; }
        .pay-item small { color: rgba(255,255,255,0.6); font-size: 11px; text-transform: uppercase; letter-spacing: 1px; }
        .pay-item span { display: block; font-size: 20px; font-weight: 700; margin-top: 4px; }

        .invoice-footer {
            margin-top: 40px; padding-top: 25px;
            border-top: 2px dashed #e2e8f0;
            text-align: center; color: #64748b; font-size: 13px;
        }

        .action-buttons {
            max-width: 900px; margin: 25px auto 0;
            display: flex; justify-content: center; gap: 12px; flex-wrap: wrap;
        }

        .btn-custom {
            padding: 12px 28px; border-radius: 12px; font-weight: 600;
            font-size: 14px; border: none; cursor: pointer;
            transition: all 0.3s ease; display: inline-flex;
            align-items: center; gap: 8px; text-decoration: none;
        }
        .btn-print  { background: linear-gradient(135deg, #6366f1, #8b5cf6); color: white; }
        .btn-print:hover  { transform: translateY(-2px); box-shadow: 0 10px 30px rgba(99,102,241,0.4); color: white; }
        .btn-wa     { background: linear-gradient(135deg, #25D366, #128C7E); color: white; }
        .btn-wa:hover     { transform: translateY(-2px); box-shadow: 0 10px 30px rgba(37,211,102,0.4); color: white; }
        .btn-back   { background: #f1f5f9; color: #0f172a; }
        .btn-back:hover   { background: #e2e8f0; transform: translateY(-2px); color: #0f172a; }

        @media print {
            body { background: white; }
            .invoice-container { box-shadow: none; padding: 20px; margin: 0; }
            .action-buttons { display: none; }
        }
    </style>
</head>
<body>

<!-- Action Buttons -->
<div class="action-buttons">
    <button onclick="window.print()" class="btn-custom btn-print">
        <i class="bi bi-printer"></i> Print Invoice
    </button>
    <a href="<?= $wa_url ?>" target="_blank" class="btn-custom btn-wa">
        <i class="bi bi-whatsapp"></i> Share on WhatsApp
    </a>
    <a href="list.php" class="btn-custom btn-back">
        <i class="bi bi-arrow-left"></i> Back to Bills
    </a>
</div>

<!-- Invoice -->
<div class="invoice-container">

    <!-- Header -->
    <div class="invoice-header">
        <div>
            <i class="bi bi-shop company-logo"></i>
            <h1 class="company-name">Smart Inventory</h1>
            <p class="company-tagline">Billing &amp; Stock Management System</p>
        </div>
        <div style="text-align:right;">
            <h2 class="invoice-number">#<?= str_pad($bill['id'], 4, '0', STR_PAD_LEFT) ?></h2>
            <p class="invoice-date"><i class="bi bi-calendar3 me-1"></i><?= date('d M Y', strtotime($bill['bill_date'])) ?></p>
            <?php
            $status_colors = ['Paid' => '#10b981', 'Partial' => '#f59e0b', 'Pending' => '#ef4444'];
            $sc = $status_colors[$bill['status']] ?? '#6366f1';
            ?>
            <span style="background:<?= $sc ?>20; color:<?= $sc ?>; padding:5px 14px;
                         border-radius:20px; font-size:12px; font-weight:700; letter-spacing:1px;">
                <?= strtoupper($bill['status']) ?>
            </span>
        </div>
    </div>

    <!-- Customer + Payment Info -->
    <div class="invoice-details">
        <div class="detail-box">
            <div class="detail-label"><i class="bi bi-person me-1"></i>Customer Name</div>
            <div class="detail-value"><?= htmlspecialchars($bill['customer_name']) ?></div>
        </div>
        <div class="detail-box">
            <div class="detail-label"><i class="bi bi-credit-card me-1"></i>Payment Mode</div>
            <div class="detail-value"><?= htmlspecialchars($bill['payment_mode']) ?></div>
        </div>
    </div>

    <!-- Items Table -->
    <table class="invoice-table">
        <thead>
            <tr>
                <th width="8%">#</th>
                <th width="48%">Product Name</th>
                <th width="15%">Price</th>
                <th width="14%">Qty</th>
                <th width="15%">Total</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $sr = 1;
            while ($item = mysqli_fetch_assoc($items_query)) :
                $item_total = $item['quantity'] * $item['price'];
            ?>
                <tr>
                    <td><strong><?= $sr++ ?></strong></td>
                    <td><strong><?= htmlspecialchars($item['product_name']) ?></strong></td>
                    <td>₹<?= number_format($item['price'], 2) ?></td>
                    <td><?= $item['quantity'] ?></td>
                    <td><strong>₹<?= number_format($item_total, 2) ?></strong></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <?php if ($has_gst) : ?>
    <!-- GST Breakdown -->
    <div class="gst-breakdown">
        <h6><i class="bi bi-percent me-2"></i>GST Breakdown</h6>

        <div class="gst-row">
            <span>Subtotal (before tax)</span>
            <strong>₹<?= number_format($bill['subtotal'] ?? $bill['total_amount'] - $bill['gst_amount'], 2) ?></strong>
        </div>

        <?php if ($bill['gst_type'] === 'intra') :
            $half = $bill['gst_rate'] / 2; ?>
            <div class="gst-row">
                <span>CGST (<?= $half ?>%)</span>
                <strong>₹<?= number_format($bill['cgst_amount'], 2) ?></strong>
            </div>
            <div class="gst-row">
                <span>SGST (<?= $half ?>%)</span>
                <strong>₹<?= number_format($bill['sgst_amount'], 2) ?></strong>
            </div>
        <?php elseif ($bill['gst_type'] === 'inter') : ?>
            <div class="gst-row">
                <span>IGST (<?= $bill['gst_rate'] ?>%)</span>
                <strong>₹<?= number_format($bill['igst_amount'], 2) ?></strong>
            </div>
        <?php endif; ?>

        <div class="gst-row" style="border-top:1px solid #fde68a; padding-top:10px; margin-top:6px; font-weight:700;">
            <span>Total Tax</span>
            <strong>₹<?= number_format($bill['gst_amount'], 2) ?></strong>
        </div>
    </div>
    <?php endif; ?>

    <!-- Total Section -->
    <div class="total-section">
        <div class="total-row">
            <div>
                <div style="font-size:13px; opacity:0.6; text-transform:uppercase; letter-spacing:1px;">Grand Total</div>
                <div style="font-size:42px; font-weight:800;">₹<?= number_format($bill['total_amount'], 2) ?></div>
                <?php if ($has_gst) : ?>
                    <div style="font-size:12px; opacity:0.6; margin-top:2px;">
                        Incl. GST ₹<?= number_format($bill['gst_amount'], 2) ?>
                        (<?= $bill['gst_type'] === 'intra' ? 'CGST+SGST' : 'IGST' ?> @ <?= $bill['gst_rate'] ?>%)
                    </div>
                <?php endif; ?>
            </div>
            <div style="font-size:60px; opacity:0.2;">
                <i class="bi bi-receipt-cutoff"></i>
            </div>
        </div>

        <!-- Paid / Due breakdown -->
        <?php if (isset($bill['paid_amount'])) : ?>
        <div class="payment-status">
            <div class="pay-item">
                <small>Paid</small>
                <span style="color:#34d399;">₹<?= number_format($bill['paid_amount'], 2) ?></span>
            </div>
            <div class="pay-item">
                <small>Due</small>
                <span style="color:<?= $bill['due_amount'] > 0 ? '#f87171' : '#34d399' ?>;">
                    ₹<?= number_format($bill['due_amount'], 2) ?>
                </span>
            </div>
            <div class="pay-item">
                <small>Status</small>
                <span style="color:<?= $sc ?>;"><?= $bill['status'] ?></span>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <!-- Footer -->
    <div class="invoice-footer">
        <p class="mb-1"><strong>Thank you for your business! 🙏</strong></p>
        <p class="mb-0">This is a computer-generated invoice. No signature required.</p>
        <p class="mb-0 mt-3" style="font-size:12px;">Generated on <?= date('d M Y, h:i A') ?></p>
    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
