<?php
session_start();
require_once __DIR__ . '/../../config/db.php';

header('Content-Type: application/json');

$code = isset($_GET['code']) ? trim($_GET['code']) : '';

if (empty($code)) {
    echo json_encode(['found' => false]);
    exit();
}

$stmt = mysqli_prepare($conn, "SELECT * FROM products WHERE barcode = ? LIMIT 1");
mysqli_stmt_bind_param($stmt, "s", $code);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($result) > 0) {
    echo json_encode(['found' => true, 'product' => mysqli_fetch_assoc($result)]);
} else {
    echo json_encode(['found' => false]);
}
?>
