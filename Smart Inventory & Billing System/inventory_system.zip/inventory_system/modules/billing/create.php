<?php
// modules/billing/create.php

$page_title = "Create New Bill";

session_start();

require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../includes/stock_helper.php';


// Handle Form Submit
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['save_bill'])) {

    // 1. Customer Details
    $customer_phone = trim($_POST['customer_phone']);
    $customer_name  = trim($_POST['customer_name']);
    $customer_email = trim($_POST['customer_email']);
    $customer_id    = !empty($_POST['customer_id']) ? (int)$_POST['customer_id'] : 0;

    // 2. Bill Details
    $payment_mode = $_POST['payment_mode'];
    $bill_date    = $_POST['bill_date'];
    $products     = $_POST['products']   ?? [];
    $quantities   = $_POST['quantities'] ?? [];
    $prices       = $_POST['prices']     ?? [];

    // 3. GST Details
    $gst_type = $_POST['gst_type'] ?? 'none'; // none | intra | inter
    $gst_rate = (float)($_POST['gst_rate'] ?? 0);

    // 4. Validation
    if (empty($customer_name) || empty($customer_phone) || empty($products)) {
        $_SESSION['error'] = "⚠️ Please add customer details and at least one product!";
    } else {

        // 5. Calculate subtotal
        $subtotal = 0;
        foreach ($products as $key => $product_id) {
            $qty   = (int)$quantities[$key];
            $price = (float)$prices[$key];
            $subtotal += ($qty * $price);
        }

        // 6. Calculate GST
        $cgst_amount = 0;
        $sgst_amount = 0;
        $igst_amount = 0;
        $gst_amount  = 0;

        if ($gst_type === 'intra' && $gst_rate > 0) {
            // Intra-state: split equally into CGST + SGST
            $half_rate   = $gst_rate / 2;
            $cgst_amount = round($subtotal * ($half_rate / 100), 2);
            $sgst_amount = round($subtotal * ($half_rate / 100), 2);
            $gst_amount  = $cgst_amount + $sgst_amount;
        } elseif ($gst_type === 'inter' && $gst_rate > 0) {
            // Inter-state: full IGST
            $igst_amount = round($subtotal * ($gst_rate / 100), 2);
            $gst_amount  = $igst_amount;
        }

        $total_amount = $subtotal + $gst_amount;

        // 7. Partial Payment Logic
        if (!isset($_POST['paid_amount']) || $_POST['paid_amount'] === '') {
            $paid_amount = $total_amount;
        } else {
            $paid_amount = (float)$_POST['paid_amount'];
        }

        $due_amount = $total_amount - $paid_amount;

        if ($due_amount > 0 && $paid_amount == 0) {
            $status = 'Pending';
        } elseif ($due_amount > 0) {
            $status = 'Partial';
        } else {
            $status       = 'Paid';
            $paid_amount  = $total_amount;
            $due_amount   = 0;
        }

        mysqli_begin_transaction($conn);

        try {
            // STEP 1: Customer
            if ($customer_id > 0) {
                if (!empty($customer_email)) {
                    $stmt_cust = mysqli_prepare($conn, "UPDATE customers SET email=? WHERE id=?");
                    mysqli_stmt_bind_param($stmt_cust, "si", $customer_email, $customer_id);
                    mysqli_stmt_execute($stmt_cust);
                }
            } else {
                $stmt_check = mysqli_prepare($conn, "SELECT id FROM customers WHERE phone = ?");
                mysqli_stmt_bind_param($stmt_check, "s", $customer_phone);
                mysqli_stmt_execute($stmt_check);
                $result_check = mysqli_stmt_get_result($stmt_check);

                if (mysqli_num_rows($result_check) > 0) {
                    $customer_id = mysqli_fetch_assoc($result_check)['id'];
                } else {
                    $stmt_new = mysqli_prepare($conn, "INSERT INTO customers (name, phone, email) VALUES (?, ?, ?)");
                    mysqli_stmt_bind_param($stmt_new, "sss", $customer_name, $customer_phone, $customer_email);
                    mysqli_stmt_execute($stmt_new);
                    $customer_id = mysqli_insert_id($conn);
                }
            }

            // STEP 2: Insert Bill (with GST columns)
            $bill_sql  = "INSERT INTO bills
                            (customer_id, customer_name, subtotal, cgst_amount, sgst_amount, igst_amount,
                             gst_amount, total_amount, paid_amount, due_amount, status,
                             payment_mode, gst_type, gst_rate, bill_date)
                          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            $bill_stmt = mysqli_prepare($conn, $bill_sql);
            mysqli_stmt_bind_param(
                $bill_stmt, "isddddddddsssds",
                $customer_id, $customer_name, $subtotal,
                $cgst_amount, $sgst_amount, $igst_amount,
                $gst_amount, $total_amount, $paid_amount, $due_amount,
                $status, $payment_mode, $gst_type, $gst_rate, $bill_date
            );
            mysqli_stmt_execute($bill_stmt);
            $bill_id = mysqli_insert_id($conn);

            // STEP 3: Items & Stock
            foreach ($products as $key => $product_id) {
                $qty   = (int)$quantities[$key];
                $price = (float)$prices[$key];

                $item_stmt = mysqli_prepare($conn, "INSERT INTO bill_items (bill_id, product_id, quantity, price) VALUES (?, ?, ?, ?)");
                mysqli_stmt_bind_param($item_stmt, "iiid", $bill_id, $product_id, $qty, $price);
                mysqli_stmt_execute($item_stmt);

                $upd_stmt = mysqli_prepare($conn, "UPDATE products SET quantity = quantity - ? WHERE id = ?");
                mysqli_stmt_bind_param($upd_stmt, "ii", $qty, $product_id);
                mysqli_stmt_execute($upd_stmt);
                // Log stock movement
                log_stock($conn, $product_id, 'sale', $qty, 'out', $bill_id, 'Sold in Bill #'.$bill_id);
            }

            // STEP 4: Payment record
            if ($paid_amount > 0) {
                $note     = "Initial payment for Bill #$bill_id";
                $pay_stmt = mysqli_prepare($conn, "INSERT INTO customer_payments (customer_id, bill_id, amount, payment_date, payment_mode, note) VALUES (?, ?, ?, ?, ?, ?)");
                mysqli_stmt_bind_param($pay_stmt, "iidsss", $customer_id, $bill_id, $paid_amount, $bill_date, $payment_mode, $note);
                mysqli_stmt_execute($pay_stmt);
            }

            mysqli_commit($conn);
            $_SESSION['success'] = "✅ Bill #$bill_id created successfully!";
            header("Location: view.php?id=$bill_id");
            exit();

        } catch (Exception $e) {
            mysqli_rollback($conn);
            $_SESSION['error'] = "❌ Failed: " . $e->getMessage();
        }
    }
}

// Get all products
$products_list = mysqli_query($conn, "SELECT * FROM products WHERE quantity > 0 ORDER BY product_name");

require_once __DIR__ . '/../../includes/header.php';
?>

<div class="d-flex align-items-center justify-content-between mb-4">
    <div>
        <h4 class="mb-1">🧾 Create New Bill</h4>
        <p class="text-muted mb-0" style="font-size:14px;">Generate invoice for customer</p>
    </div>
    <a href="list.php" class="btn btn-light"><i class="bi bi-arrow-left me-2"></i>All Bills</a>
</div>



<form method="POST" action="" id="billingForm">
    <div class="row g-4">

        <!-- ── LEFT COLUMN ── -->
        <div class="col-lg-4">

            <!-- Customer Details -->
            <div class="card mb-4">
                <div class="card-header"><i class="bi bi-person-fill me-2 text-primary"></i>Customer Details</div>
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label">Phone <span class="text-danger">*</span></label>
                        <input type="tel" id="customerPhone" name="customer_phone" class="form-control"
                               placeholder="10-digit number" pattern="[0-9]{10}" maxlength="10"
                               required autocomplete="off" oninput="searchCustomer(this.value)">
                    </div>
                    <div id="customerSearchResult"></div>

                    <div class="mb-3">
                        <label class="form-label">Name <span class="text-danger">*</span></label>
                        <input type="text" id="customerName" name="customer_name" class="form-control" placeholder="Customer name" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Email</label>
                        <input type="email" id="customerEmail" name="customer_email" class="form-control" placeholder="Optional">
                    </div>

                    <input type="hidden" id="customerId" name="customer_id" value="">

                    <div class="mb-3">
                        <label class="form-label">Payment Mode</label>
                        <select name="payment_mode" class="form-select" required>
                            <option value="Cash">💵 Cash</option>
                            <option value="Card">💳 Card</option>
                            <option value="UPI">📱 UPI</option>
                            <option value="Online">🌐 Online</option>
                        </select>
                    </div>

                    <div class="mb-0">
                        <label class="form-label">Date</label>
                        <input type="date" name="bill_date" class="form-control" value="<?= date('Y-m-d') ?>" required>
                    </div>
                </div>
            </div>

            <!-- GST Settings -->
            <div class="card mb-4">
                <div class="card-header">
                    <i class="bi bi-percent me-2 text-warning"></i>GST Settings
                    <span class="badge bg-warning text-dark ms-2" style="font-size:10px;">Optional</span>
                </div>
                <div class="card-body">

                    <!-- GST Type -->
                    <div class="mb-3">
                        <label class="form-label">GST Type</label>
                        <div class="d-flex gap-2 flex-wrap">
                            <label class="gst-option" id="opt-none">
                                <input type="radio" name="gst_type" value="none" checked onchange="updateGST()"> No GST
                            </label>
                            <label class="gst-option" id="opt-intra">
                                <input type="radio" name="gst_type" value="intra" onchange="updateGST()"> Intra-state<br>
                                <small style="font-size:10px;opacity:0.8;">CGST + SGST</small>
                            </label>
                            <label class="gst-option" id="opt-inter">
                                <input type="radio" name="gst_type" value="inter" onchange="updateGST()"> Inter-state<br>
                                <small style="font-size:10px;opacity:0.8;">IGST only</small>
                            </label>
                        </div>
                    </div>

                    <!-- GST Rate -->
                    <div class="mb-3" id="gstRateSection" style="display:none;">
                        <label class="form-label">GST Rate</label>
                        <div class="d-flex gap-2 flex-wrap" id="gstRateBtns">
                            <?php foreach ([5, 12, 18, 28] as $rate) : ?>
                                <button type="button" class="btn btn-sm btn-outline-warning gst-rate-btn"
                                        data-rate="<?= $rate ?>" onclick="selectRate(<?= $rate ?>)">
                                    <?= $rate ?>%
                                </button>
                            <?php endforeach; ?>
                        </div>
                        <input type="hidden" name="gst_rate" id="gstRateInput" value="0">
                    </div>

                    <!-- GST Breakdown Preview -->
                    <div id="gstBreakdown" style="display:none;">
                        <div class="rounded p-3" style="background:var(--hover-bg); font-size:13px;">
                            <div id="cgstRow" class="d-flex justify-content-between mb-1" style="display:none!important;">
                                <span class="text-muted">CGST (<span id="cgstPct">0</span>%)</span>
                                <strong id="cgstAmt">₹0.00</strong>
                            </div>
                            <div id="sgstRow" class="d-flex justify-content-between mb-1" style="display:none!important;">
                                <span class="text-muted">SGST (<span id="sgstPct">0</span>%)</span>
                                <strong id="sgstAmt">₹0.00</strong>
                            </div>
                            <div id="igstRow" class="d-flex justify-content-between mb-1" style="display:none!important;">
                                <span class="text-muted">IGST (<span id="igstPct">0</span>%)</span>
                                <strong id="igstAmt">₹0.00</strong>
                            </div>
                            <div class="d-flex justify-content-between border-top pt-2 mt-1">
                                <span class="fw-bold">Total Tax</span>
                                <strong class="text-warning" id="totalTaxAmt">₹0.00</strong>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Bill Summary -->
            <div class="card" style="position:sticky; top:90px;">
                <div class="card-header"><i class="bi bi-calculator me-2 text-success"></i>Bill Summary</div>
                <div class="card-body">

                    <div class="d-flex justify-content-between mb-2 pb-2 border-bottom">
                        <span class="text-muted fw-bold">Items:</span>
                        <strong id="totalItems">0</strong>
                    </div>

                    <div class="d-flex justify-content-between mb-2">
                        <span class="text-muted">Subtotal:</span>
                        <span id="subtotalDisplay">₹0.00</span>
                    </div>

                    <!-- GST lines (hidden when no GST) -->
                    <div id="summCgst" class="d-flex justify-content-between mb-1" style="display:none!important; font-size:13px;">
                        <span class="text-muted">CGST (<span id="summCgstPct">0</span>%):</span>
                        <span id="summCgstAmt">₹0.00</span>
                    </div>
                    <div id="summSgst" class="d-flex justify-content-between mb-1" style="display:none!important; font-size:13px;">
                        <span class="text-muted">SGST (<span id="summSgstPct">0</span>%):</span>
                        <span id="summSgstAmt">₹0.00</span>
                    </div>
                    <div id="summIgst" class="d-flex justify-content-between mb-1" style="display:none!important; font-size:13px;">
                        <span class="text-muted">IGST (<span id="summIgstPct">0</span>%):</span>
                        <span id="summIgstAmt">₹0.00</span>
                    </div>

                    <div class="d-flex justify-content-between align-items-center mb-4 pt-2 border-top">
                        <h5 class="mb-0">Grand Total:</h5>
                        <h3 class="mb-0 text-success fw-bold" id="grandTotal">₹0.00</h3>
                    </div>

                    <div class="alert alert-light border mb-3">
                        <label class="form-label d-flex justify-content-between mb-1">
                            <span class="fw-bold">Amount Received</span>
                            <small class="text-muted fw-bold" id="dueDisplay">Full Payment</small>
                        </label>
                        <input type="number" name="paid_amount" id="paidAmount"
                               class="form-control form-control-lg text-center fw-bold"
                               placeholder="Enter amount" step="0.01" min="0" oninput="calculateDue()">
                    </div>

                    <button type="submit" name="save_bill" class="btn btn-success w-100 btn-lg" id="saveBillBtn" disabled>
                        <i class="bi bi-check-circle me-2"></i>Generate Bill
                    </button>
                </div>
            </div>
        </div>

        <!-- ── RIGHT COLUMN ── -->
        <div class="col-lg-8">

            <!-- Barcode Scanner — Upgraded -->
            <div class="card mb-3" style="border:2px solid #6366f1;border-radius:18px;overflow:hidden;">
                <div class="card-body p-3">
                    <div class="d-flex align-items-center gap-3 mb-2">
                        <div style="width:36px;height:36px;border-radius:10px;background:linear-gradient(135deg,#6366f1,#8b5cf6);display:flex;align-items:center;justify-content:center;flex-shrink:0;">
                            <i class="bi bi-upc-scan" style="color:white;font-size:16px;"></i>
                        </div>
                        <div style="flex:1;">
                            <input type="text" id="barcodeScanner" class="form-control form-control-lg fw-bold"
                                   placeholder="Scan barcode or type product code..." autofocus
                                   style="border-radius:10px;letter-spacing:1px;">
                        </div>
                        <button type="button" class="btn btn-primary" onclick="openScannerModal()"
                                style="border-radius:10px;padding:10px 16px;white-space:nowrap;flex-shrink:0;">
                            <i class="bi bi-camera-video-fill me-1"></i> Camera
                        </button>
                    </div>
                    <div class="d-flex align-items-center gap-2" style="font-size:12px;color:var(--text-muted);">
                        <i class="bi bi-info-circle"></i>
                        USB scanner: scan directly · Camera: click the Camera button · Manual: type code + Enter
                        <span id="scanStatus" style="margin-left:auto;font-weight:600;"></span>
                    </div>
                </div>
            </div>

            <!-- Camera Scanner Modal -->
            <div class="modal fade" id="scannerModal" tabindex="-1" data-bs-backdrop="static">
                <div class="modal-dialog modal-dialog-centered" style="max-width:420px;">
                    <div class="modal-content" style="border-radius:20px;overflow:hidden;border:none;">
                        <div class="modal-header" style="background:linear-gradient(135deg,#6366f1,#8b5cf6);border:none;padding:18px 22px;">
                            <div class="d-flex align-items-center gap-2">
                                <i class="bi bi-camera-video-fill text-white" style="font-size:20px;"></i>
                                <h5 class="modal-title text-white mb-0 fw-700">Barcode Scanner</h5>
                            </div>
                            <button type="button" class="btn-close btn-close-white" onclick="closeScannerModal()"></button>
                        </div>
                        <div class="modal-body p-0">
                            <!-- Scanner viewport -->
                            <div style="position:relative;background:#0f172a;min-height:300px;">
                                <div id="reader" style="width:100%;"></div>
                                <!-- Scan frame overlay -->
                                <div id="scanOverlay" style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;pointer-events:none;">
                                    <div style="width:200px;height:200px;position:relative;">
                                        <div style="position:absolute;top:0;left:0;width:30px;height:30px;border-top:3px solid #6366f1;border-left:3px solid #6366f1;border-radius:4px 0 0 0;"></div>
                                        <div style="position:absolute;top:0;right:0;width:30px;height:30px;border-top:3px solid #6366f1;border-right:3px solid #6366f1;border-radius:0 4px 0 0;"></div>
                                        <div style="position:absolute;bottom:0;left:0;width:30px;height:30px;border-bottom:3px solid #6366f1;border-left:3px solid #6366f1;border-radius:0 0 0 4px;"></div>
                                        <div style="position:absolute;bottom:0;right:0;width:30px;height:30px;border-bottom:3px solid #6366f1;border-right:3px solid #6366f1;border-radius:0 0 4px 0;"></div>
                                        <!-- Scan line animation -->
                                        <div id="scanLine" style="position:absolute;left:4px;right:4px;height:2px;background:linear-gradient(90deg,transparent,#6366f1,transparent);top:0;animation:scanAnim 2s ease-in-out infinite;"></div>
                                    </div>
                                </div>
                            </div>
                            <!-- Last scanned -->
                            <div id="lastScanned" style="display:none;padding:14px 20px;background:var(--card-bg,#fff);border-top:1px solid #e2e8f0;">
                                <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:#64748b;margin-bottom:4px;">Last Scanned</div>
                                <div id="lastScannedName" style="font-size:15px;font-weight:700;color:#0f172a;"></div>
                                <div id="lastScannedPrice" style="font-size:13px;color:#10b981;"></div>
                            </div>
                            <!-- Instructions -->
                            <div style="padding:14px 20px;background:var(--card-bg,#fff);">
                                <div style="font-size:12px;color:#64748b;text-align:center;">
                                    <i class="bi bi-camera me-1"></i>Point camera at barcode · Auto-scans on detect · Stays open for multi-scan
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer" style="border-top:1px solid #e2e8f0;padding:12px 20px;">
                            <button type="button" class="btn btn-light flex-fill" onclick="closeScannerModal()">
                                <i class="bi bi-x-lg me-1"></i>Done
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Beep audio (inline generated) -->
            <audio id="beepSound" preload="auto"></audio>

            <style>
            @keyframes scanAnim {
                0%   { top: 4px; opacity: 1; }
                48%  { opacity: 1; }
                50%  { top: calc(100% - 6px); opacity: 0.6; }
                52%  { opacity: 1; }
                100% { top: 4px; opacity: 1; }
            }
            #scanStatus.success { color: #10b981; }
            #scanStatus.error   { color: #ef4444; }
            #reader video { border-radius: 0 !important; }
            #reader img   { display: none !important; }
            /* Hide the ugly default Html5QrcodeScanner UI elements */
            #reader__dashboard_section_swaplink,
            #reader__dashboard_section_csr > span:first-child,
            #reader__camera_selection,
            #reader__filescan_input { display: none !important; }
            #reader__scan_region { border: none !important; }
            #reader__dashboard { padding: 0 !important; }
            #reader__dashboard_section { padding: 0 !important; }
            </style>

            <!-- Add Product Manually -->
            <div class="card mb-4">
                <div class="card-header"><i class="bi bi-plus-circle me-2 text-primary"></i>Add Product Manually</div>
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Select Product</label>
                            <select id="productSelect" class="form-select">
                                <option value="">-- Choose Product --</option>
                                <?php while ($p = mysqli_fetch_assoc($products_list)) : ?>
                                    <option value="<?= $p['id'] ?>"
                                            data-name="<?= htmlspecialchars($p['product_name']) ?>"
                                            data-price="<?= $p['price'] ?>"
                                            data-stock="<?= $p['quantity'] ?>">
                                        <?= htmlspecialchars($p['product_name']) ?> (₹<?= number_format($p['price'], 2) ?>)
                                    </option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Quantity</label>
                            <input type="number" id="productQty" class="form-control" min="1" value="1">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">&nbsp;</label>
                            <button type="button" class="btn btn-primary w-100" onclick="addProduct()">Add</button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Items Table -->
            <div class="card">
                <div class="card-header"><i class="bi bi-cart-fill me-2 text-success"></i>Bill Items</div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table mb-0" id="billItemsTable">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Product</th>
                                    <th>Price</th>
                                    <th>Qty</th>
                                    <th>Total</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody id="billItemsBody">
                                <tr id="emptyRow">
                                    <td colspan="6" class="text-center py-5 text-muted">No items added yet.</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

    </div>
</form>

<!-- GST Option Styling -->
<style>
.gst-option {
    display: inline-flex;
    flex-direction: column;
    align-items: center;
    padding: 10px 16px;
    border: 2px solid var(--border-color);
    border-radius: var(--radius);
    cursor: pointer;
    font-size: 13px;
    font-weight: 600;
    transition: all 0.2s ease;
    text-align: center;
    line-height: 1.4;
    background: var(--card-bg);
    color: var(--text-main);
}
.gst-option input[type="radio"] { display: none; }
.gst-option:has(input:checked) {
    border-color: var(--warning);
    background: rgba(245,158,11,0.1);
    color: #b45309;
}
.gst-rate-btn.active {
    background: var(--warning) !important;
    color: white !important;
    border-color: var(--warning) !important;
}
</style>

<script>
let billItems  = [];
let searchTimeout;
let gstType    = 'none';
let gstRate    = 0;

// ── GST LOGIC ──────────────────────────────────────────

function updateGST() {
    gstType = document.querySelector('input[name="gst_type"]:checked').value;
    const rateSection  = document.getElementById('gstRateSection');
    const breakdown    = document.getElementById('gstBreakdown');

    if (gstType === 'none') {
        rateSection.style.display  = 'none';
        breakdown.style.display    = 'none';
        gstRate = 0;
        document.getElementById('gstRateInput').value = 0;
        // clear active rate buttons
        document.querySelectorAll('.gst-rate-btn').forEach(b => b.classList.remove('active'));
        updateSummary();
    } else {
        rateSection.style.display = 'block';
        if (gstRate > 0) breakdown.style.display = 'block';
        updateSummary();
    }
}

function selectRate(rate) {
    gstRate = rate;
    document.getElementById('gstRateInput').value = rate;
    document.querySelectorAll('.gst-rate-btn').forEach(b => {
        b.classList.toggle('active', parseInt(b.dataset.rate) === rate);
    });
    document.getElementById('gstBreakdown').style.display = 'block';
    updateSummary();
}

function calcGST(subtotal) {
    let cgst = 0, sgst = 0, igst = 0, total_tax = 0;
    if (gstType === 'intra' && gstRate > 0) {
        const half = gstRate / 2;
        cgst = +(subtotal * half / 100).toFixed(2);
        sgst = +(subtotal * half / 100).toFixed(2);
        total_tax = cgst + sgst;
    } else if (gstType === 'inter' && gstRate > 0) {
        igst = +(subtotal * gstRate / 100).toFixed(2);
        total_tax = igst;
    }
    return { cgst, sgst, igst, total_tax };
}

// ── BILL ITEMS ──────────────────────────────────────────

function renderBillItems() {
    const tbody = document.getElementById('billItemsBody');
    if (billItems.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" class="text-center py-5 text-muted">No items added yet.</td></tr>';
        return;
    }
    let html = '';
    billItems.forEach((item, index) => {
        html += `<tr>
            <td>${index + 1}</td>
            <td>${item.name}
                <input type="hidden" name="products[]"   value="${item.id}">
                <input type="hidden" name="quantities[]" value="${item.qty}">
                <input type="hidden" name="prices[]"     value="${item.price}">
            </td>
            <td>₹${item.price.toFixed(2)}</td>
            <td>${item.qty}</td>
            <td class="text-success fw-bold">₹${item.total.toFixed(2)}</td>
            <td><button type="button" class="btn btn-sm btn-outline-danger" onclick="removeItem(${index})">
                <i class="bi bi-trash"></i></button></td>
        </tr>`;
    });
    tbody.innerHTML = html;
}

function updateSummary() {
    const subtotal = billItems.reduce((sum, item) => sum + item.total, 0);
    const gst      = calcGST(subtotal);
    const grand    = subtotal + gst.total_tax;
    const half     = gstRate / 2;

    // Subtotal
    document.getElementById('totalItems').textContent     = billItems.length;
    document.getElementById('subtotalDisplay').textContent = '₹' + subtotal.toFixed(2);
    document.getElementById('grandTotal').textContent      = '₹' + grand.toFixed(2);
    document.getElementById('saveBillBtn').disabled        = (billItems.length === 0);

    // GST card breakdown
    const cgstRow = document.getElementById('cgstRow');
    const sgstRow = document.getElementById('sgstRow');
    const igstRow = document.getElementById('igstRow');

    if (gstType === 'intra' && gstRate > 0) {
        cgstRow.style.setProperty('display', 'flex', 'important');
        sgstRow.style.setProperty('display', 'flex', 'important');
        igstRow.style.setProperty('display', 'none', 'important');
        document.getElementById('cgstPct').textContent = half;
        document.getElementById('sgstPct').textContent = half;
        document.getElementById('cgstAmt').textContent = '₹' + gst.cgst.toFixed(2);
        document.getElementById('sgstAmt').textContent = '₹' + gst.sgst.toFixed(2);
    } else if (gstType === 'inter' && gstRate > 0) {
        igstRow.style.setProperty('display', 'flex', 'important');
        cgstRow.style.setProperty('display', 'none', 'important');
        sgstRow.style.setProperty('display', 'none', 'important');
        document.getElementById('igstPct').textContent = gstRate;
        document.getElementById('igstAmt').textContent = '₹' + gst.igst.toFixed(2);
    } else {
        cgstRow.style.setProperty('display', 'none', 'important');
        sgstRow.style.setProperty('display', 'none', 'important');
        igstRow.style.setProperty('display', 'none', 'important');
    }
    document.getElementById('totalTaxAmt').textContent = '₹' + gst.total_tax.toFixed(2);

    // Summary sidebar
    const summCgst = document.getElementById('summCgst');
    const summSgst = document.getElementById('summSgst');
    const summIgst = document.getElementById('summIgst');

    if (gstType === 'intra' && gstRate > 0) {
        summCgst.style.setProperty('display', 'flex', 'important');
        summSgst.style.setProperty('display', 'flex', 'important');
        summIgst.style.setProperty('display', 'none', 'important');
        document.getElementById('summCgstPct').textContent = half;
        document.getElementById('summSgstPct').textContent = half;
        document.getElementById('summCgstAmt').textContent = '₹' + gst.cgst.toFixed(2);
        document.getElementById('summSgstAmt').textContent = '₹' + gst.sgst.toFixed(2);
    } else if (gstType === 'inter' && gstRate > 0) {
        summIgst.style.setProperty('display', 'flex', 'important');
        summCgst.style.setProperty('display', 'none', 'important');
        summSgst.style.setProperty('display', 'none', 'important');
        document.getElementById('summIgstPct').textContent = gstRate;
        document.getElementById('summIgstAmt').textContent = '₹' + gst.igst.toFixed(2);
    } else {
        summCgst.style.setProperty('display', 'none', 'important');
        summSgst.style.setProperty('display', 'none', 'important');
        summIgst.style.setProperty('display', 'none', 'important');
    }

    calculateDue();
}

function calculateDue() {
    const grand     = parseFloat(document.getElementById('grandTotal').textContent.replace('₹', '')) || 0;
    const paidInput = document.getElementById('paidAmount').value;
    const dueEl     = document.getElementById('dueDisplay');

    if (paidInput === '') {
        dueEl.textContent = 'Full Payment';
        dueEl.className   = 'text-muted fw-bold';
        return;
    }
    const due = grand - parseFloat(paidInput);
    if (due > 0) {
        dueEl.textContent = 'Due: ₹' + due.toFixed(2);
        dueEl.className   = 'text-danger fw-bold';
    } else {
        dueEl.textContent = 'Change: ₹' + Math.abs(due).toFixed(2);
        dueEl.className   = 'text-success fw-bold';
    }
}

function addToBill(product) {
    const existing = billItems.find(item => item.id === product.id);
    if (existing) {
        if (existing.qty + 1 > product.stock) { alert('⚠️ Not enough stock!'); return; }
        existing.qty++;
        existing.total = existing.qty * existing.price;
    } else {
        if (product.stock < 1) { alert('⚠️ Out of stock!'); return; }
        billItems.push({ id: product.id, name: product.name, price: product.price, qty: 1, total: product.price, stock: product.stock });
    }
    renderBillItems();
    updateSummary();
}

function removeItem(index) {
    billItems.splice(index, 1);
    renderBillItems();
    updateSummary();
}

// ── MANUAL ADD ──────────────────────────────────────────

function addProduct() {
    const select = document.getElementById('productSelect');
    const qtyInput = document.getElementById('productQty');
    if (!select.value) { alert('⚠️ Select a product!'); return; }

    const qty    = parseInt(qtyInput.value);
    const option = select.options[select.selectedIndex];
    const stock  = parseInt(option.dataset.stock);
    if (qty > stock) { alert('⚠️ Not enough stock!'); return; }

    const product = {
        id: parseInt(select.value), name: option.dataset.name,
        price: parseFloat(option.dataset.price), stock
    };

    const existing = billItems.find(item => item.id === product.id);
    if (existing) {
        if (existing.qty + qty > stock) { alert('⚠️ Not enough stock!'); return; }
        existing.qty  += qty;
        existing.total = existing.qty * existing.price;
    } else {
        billItems.push({ id: product.id, name: product.name, price: product.price, qty, total: product.price * qty, stock });
    }
    renderBillItems();
    updateSummary();
    select.value   = '';
    qtyInput.value = 1;
}

// ── BARCODE SCANNER — UPGRADED ───────────────────────────

// USB/keyboard scanner — fires on Enter
document.getElementById('barcodeScanner').addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
        e.preventDefault();
        const c = this.value.trim();
        if (c) scanProduct(c, false);
    }
});

// Beep sound via Web Audio API
function playBeep(success) {
    try {
        const ctx = new (window.AudioContext || window.webkitAudioContext)();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.type = 'sine';
        osc.frequency.value = success ? 880 : 330;
        gain.gain.setValueAtTime(0.3, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + (success ? 0.15 : 0.4));
        osc.start(ctx.currentTime);
        osc.stop(ctx.currentTime + (success ? 0.15 : 0.4));
    } catch(e) {}
}

// Show status message next to scanner
function setScanStatus(msg, type) {
    const el = document.getElementById('scanStatus');
    el.textContent = msg;
    el.className = type;
    if (type !== '') setTimeout(() => { el.textContent = ''; el.className = ''; }, 2500);
}

// Core scan function — called by USB scanner & camera
function scanProduct(barcode, fromCamera) {
    const input = document.getElementById('barcodeScanner');
    if (!fromCamera) input.disabled = true;

    fetch('get_product_by_barcode.php?code=' + encodeURIComponent(barcode))
        .then(r => r.json())
        .then(data => {
            if (data.found) {
                const product = {
                    id: data.product.id,
                    name: data.product.product_name,
                    price: parseFloat(data.product.price),
                    stock: parseInt(data.product.quantity)
                };
                addToBill(product);
                playBeep(true);
                setScanStatus('✓ ' + product.name, 'success');

                if (fromCamera) {
                    // Update "last scanned" panel in modal
                    const ls = document.getElementById('lastScanned');
                    ls.style.display = 'block';
                    document.getElementById('lastScannedName').textContent = product.name;
                    document.getElementById('lastScannedPrice').textContent = '₹' + product.price.toFixed(2) + ' · Added to bill';
                } else {
                    input.value = '';
                    input.disabled = false;
                    input.focus();
                }
            } else {
                playBeep(false);
                setScanStatus('✗ Not found: ' + barcode, 'error');
                if (!fromCamera) {
                    input.disabled = false;
                    input.focus();
                    input.select();
                }
            }
        })
        .catch(() => {
            setScanStatus('✗ Scan error', 'error');
            if (!fromCamera) { input.disabled = false; input.focus(); }
        });
}

// ── CAMERA SCANNER MODAL ─────────────────────────────────

let html5QrcodeScanner = null;
let scannerModalInst   = null;
let lastScannedCode    = '';
let scanCooldown       = false;

function openScannerModal() {
    scannerModalInst = new bootstrap.Modal(document.getElementById('scannerModal'));
    scannerModalInst.show();

    // Small delay to let modal render before starting camera
    setTimeout(startCamera, 400);
}

function startCamera() {
    if (html5QrcodeScanner) {
        html5QrcodeScanner.clear().catch(() => {});
    }
    html5QrcodeScanner = new Html5QrcodeScanner(
        'reader',
        {
            fps: 15,
            qrbox: { width: 220, height: 120 },
            rememberLastUsedCamera: true,
            showTorchButtonIfSupported: true,
            aspectRatio: 1.0
        },
        false
    );
    html5QrcodeScanner.render(
        function(decodedText) {
            // Cooldown to prevent duplicate scans
            if (scanCooldown || decodedText === lastScannedCode) return;
            lastScannedCode = decodedText;
            scanCooldown = true;
            setTimeout(() => { scanCooldown = false; lastScannedCode = ''; }, 1500);

            // Scan the product
            scanProduct(decodedText, true);
        },
        function(error) { /* silent fail */ }
    );
}

function closeScannerModal() {
    if (html5QrcodeScanner) {
        html5QrcodeScanner.clear().catch(() => {});
        html5QrcodeScanner = null;
    }
    if (scannerModalInst) {
        scannerModalInst.hide();
        scannerModalInst = null;
    }
    document.getElementById('lastScanned').style.display = 'none';
    lastScannedCode = '';
    scanCooldown = false;
    // Refocus USB scanner input
    document.getElementById('barcodeScanner').focus();
}

// Stop camera if modal closed via backdrop/keyboard
document.getElementById('scannerModal').addEventListener('hide.bs.modal', function() {
    if (html5QrcodeScanner) {
        html5QrcodeScanner.clear().catch(() => {});
        html5QrcodeScanner = null;
    }
});

// ── CUSTOMER SEARCH ──────────────────────────────────────

function searchCustomer(phone) {
    clearTimeout(searchTimeout);
    if (phone.length === 0) { resetCustomerFields(); return; }
    if (phone.length === 10) {
        searchTimeout = setTimeout(() => {
            const resultDiv = document.getElementById('customerSearchResult');
            resultDiv.innerHTML = '<div class="text-center text-muted"><div class="spinner-border spinner-border-sm"></div> Searching...</div>';
            fetch('search_customer.php?phone=' + phone)
                .then(r => r.json())
                .then(data => {
                    if (data.found) {
                        resultDiv.innerHTML = `<div class="alert alert-success py-2 mb-3"><i class="bi bi-check-circle-fill"></i> Customer Found!<br><small>Due: ₹${data.total_spent}</small></div>`;
                        document.getElementById('customerId').value             = data.id;
                        document.getElementById('customerName').value           = data.name;
                        document.getElementById('customerEmail').value          = data.email || '';
                        document.getElementById('customerName').readOnly        = true;
                        document.getElementById('customerName').style.background = 'var(--hover-bg)';
                    } else {
                        resultDiv.innerHTML = `<div class="alert alert-info py-2 mb-3"><i class="bi bi-person-plus-fill"></i> New Customer</div>`;
                        document.getElementById('customerId').value             = '';
                        document.getElementById('customerName').readOnly        = false;
                        document.getElementById('customerName').style.background = '';
                        document.getElementById('customerName').focus();
                    }
                });
        }, 500);
    }
}

function resetCustomerFields() {
    document.getElementById('customerSearchResult').innerHTML = '';
    document.getElementById('customerId').value              = '';
    document.getElementById('customerName').value            = '';
    document.getElementById('customerEmail').value           = '';
    document.getElementById('customerName').readOnly         = false;
    document.getElementById('customerName').style.background = '';
}


</script>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
