<?php
// modules/billing/search_customer.php

session_start();
require_once __DIR__ . '/../../config/db.php';

header('Content-Type: application/json');

$phone = isset($_GET['phone']) ? trim($_GET['phone']) : '';

if (empty($phone)) {
    echo json_encode(['found' => false]);
    exit();
}

// Search customer by phone
$sql = "SELECT c.*, 
        COUNT(b.id) as total_bills,
        COALESCE(SUM(b.total_amount), 0) as total_spent
        FROM customers c
        LEFT JOIN bills b ON c.id = b.customer_id
        WHERE c.phone = ?
        GROUP BY c.id";

$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "s", $phone);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($result) > 0) {
    $customer = mysqli_fetch_assoc($result);
    
    echo json_encode([
        'found' => true,
        'id' => $customer['id'],
        'name' => $customer['name'],
        'email' => $customer['email'],
        'phone' => $customer['phone'],
        'total_bills' => $customer['total_bills'],
        'total_spent' => number_format($customer['total_spent'], 2)
    ]);
} else {
    echo json_encode(['found' => false]);
}
?>