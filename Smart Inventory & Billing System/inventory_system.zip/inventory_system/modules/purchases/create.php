<?php
// modules/purchases/create.php

$page_title = "New Purchase Entry";

session_start();

require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../includes/stock_helper.php';


// Handle Form Submit
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['save_purchase'])) {

    $supplier_id  = (int) $_POST['supplier_id'];
    $purchase_date= $_POST['purchase_date'];
    $payment_mode = $_POST['payment_mode'];
    $notes        = trim($_POST['notes']);
    
    // Extra Charge Inputs
    $extra_amount = !empty($_POST['extra_charge_amount']) ? (float)$_POST['extra_charge_amount'] : 0;
    $extra_label  = !empty($_POST['extra_charge_label']) ? trim($_POST['extra_charge_label']) : null;
    $add_expense  = isset($_POST['add_as_expense']) ? 1 : 0;

    $products     = $_POST['products'] ?? [];
    $quantities   = $_POST['quantities'] ?? [];
    $cost_prices  = $_POST['cost_prices'] ?? [];

    if ($supplier_id == 0 || empty($products)) {
        $_SESSION['error'] = "⚠️ Please select a supplier and add at least one product!";
    } else {

        // Calculate total (Items Total + Extra Charge)
        $items_total = 0;
        foreach ($products as $key => $product_id) {
            $qty        = (int) $quantities[$key];
            $cost_price = (float) $cost_prices[$key];
            $items_total += ($qty * $cost_price);
        }
        $grand_total = $items_total + $extra_amount;

        mysqli_begin_transaction($conn);

        try {
            // 1. Insert Purchase
            // FIXED: Type string matches exactly 8 variables ("isdssdsi")
            $purchase_sql  = "INSERT INTO purchases (supplier_id, purchase_date, total_amount, payment_mode, notes, extra_charge_amount, extra_charge_label, add_as_expense)
                               VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            $purchase_stmt = mysqli_prepare($conn, $purchase_sql);
            mysqli_stmt_bind_param($purchase_stmt, "isdssdsi",
                $supplier_id, $purchase_date, $grand_total, $payment_mode, $notes, $extra_amount, $extra_label, $add_expense
            );
            mysqli_stmt_execute($purchase_stmt);

            $purchase_id = mysqli_insert_id($conn);

            // 2. Insert Items & Update Stock
            foreach ($products as $key => $product_id) {
                $qty        = (int) $quantities[$key];
                $cost_price = (float) $cost_prices[$key];

                // Insert purchase item
                $item_sql  = "INSERT INTO purchase_items (purchase_id, product_id, quantity, cost_price)
                               VALUES (?, ?, ?, ?)";
                $item_stmt = mysqli_prepare($conn, $item_sql);
                mysqli_stmt_bind_param($item_stmt, "iiid",
                    $purchase_id, $product_id, $qty, $cost_price
                );
                mysqli_stmt_execute($item_stmt);

                // Update product stock & cost price
                $update_sql  = "UPDATE products SET quantity = quantity + ?, cost_price = ? WHERE id = ?";
                $update_stmt = mysqli_prepare($conn, $update_sql);
                mysqli_stmt_bind_param($update_stmt, "idi", $qty, $cost_price, $product_id);
                mysqli_stmt_execute($update_stmt);
                // Log stock movement
                log_stock($conn, $product_id, 'purchase', $qty, 'in', $purchase_id, 'Purchase #'.$purchase_id);
            }

            // 3. Add to Expenses (if toggle is checked)
            if ($add_expense == 1 && $extra_amount > 0) {
                $exp_desc = "Purchase #$purchase_id Extra Charge (" . ($extra_label ?: 'Misc') . ")";
                $exp_cat  = "Purchase Extra"; // You can change this category name
                
                $exp_sql = "INSERT INTO expenses (expense_date, category, amount, description, payment_mode) 
                            VALUES (?, ?, ?, ?, ?)";
                $exp_stmt = mysqli_prepare($conn, $exp_sql);
                mysqli_stmt_bind_param($exp_stmt, "ssdss", $purchase_date, $exp_cat, $extra_amount, $exp_desc, $payment_mode);
                mysqli_stmt_execute($exp_stmt);
            }

            mysqli_commit($conn);

            $_SESSION['success'] = "✅ Purchase #$purchase_id saved! Stock updated.";
            header("Location: view.php?id=$purchase_id");
            exit();

        } catch (Exception $e) {
            mysqli_rollback($conn);
            $_SESSION['error'] = "❌ Failed: " . $e->getMessage();
        }
    }
}

// Get Suppliers
$suppliers = mysqli_query($conn, "SELECT * FROM suppliers ORDER BY name");

// Get Products with stock
$products_list = mysqli_query($conn,
    "SELECT p.*, c.category_name
     FROM products p
     LEFT JOIN categories c ON p.category_id = c.id
     ORDER BY p.product_name"
);

// Include Header
require_once __DIR__ . '/../../includes/header.php';
?>

<!-- ══════════════ CREATE PURCHASE PAGE ══════════════ -->

<!-- Page Header -->
<div class="d-flex align-items-center justify-content-between mb-4">
    <div>
        <h4 class="mb-1">📦 New Purchase Entry</h4>
        <p class="text-muted mb-0" style="font-size:14px;">
            Record new stock purchase from supplier
        </p>
    </div>
    <a href="index.php" class="btn btn-light">
        <i class="bi bi-arrow-left me-2"></i>Back to Purchases
    </a>
</div>

<!-- Alerts -->


<form method="POST" action="" id="purchaseForm">

    <div class="row g-4">

        <!-- Left Column -->
        <div class="col-lg-4">

            <!-- Purchase Details Card -->
            <div class="card mb-4">
                <div class="card-header">
                    <i class="bi bi-truck me-2 text-primary"></i>Purchase Details
                </div>
                <div class="card-body">

                    <!-- Supplier -->
                    <div class="mb-3">
                        <label class="form-label" style="font-weight:600;">
                            Supplier <span class="text-danger">*</span>
                        </label>
                        <select name="supplier_id" class="form-select" required id="supplierSelect">
                            <option value="">-- Select Supplier --</option>
                            <?php while ($supplier = mysqli_fetch_assoc($suppliers)) : ?>
                                <option value="<?= $supplier['id'] ?>">
                                    <?= htmlspecialchars($supplier['name']) ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                        <a href="suppliers.php" class="btn btn-link btn-sm p-0 mt-2">
                            <i class="bi bi-plus me-1"></i>Add New Supplier
                        </a>
                    </div>

                    <!-- Purchase Date -->
                    <div class="mb-3">
                        <label class="form-label" style="font-weight:600;">
                            Purchase Date <span class="text-danger">*</span>
                        </label>
                        <input type="date" name="purchase_date" class="form-control"
                               value="<?= date('Y-m-d') ?>" max="<?= date('Y-m-d') ?>" required>
                    </div>

                    <!-- Payment Mode -->
                    <div class="mb-3">
                        <label class="form-label" style="font-weight:600;">Payment Mode</label>
                        <select name="payment_mode" class="form-select">
                            <option value="Cash">💵 Cash</option>
                            <option value="Bank Transfer">🏦 Bank Transfer</option>
                            <option value="UPI">📱 UPI</option>
                            <option value="Cheque">📄 Cheque</option>
                            <option value="Credit">💳 Credit (Pay Later)</option>
                        </select>
                    </div>

                    <!-- Notes -->
                    <div class="mb-3">
                        <label class="form-label" style="font-weight:600;">Notes</label>
                        <textarea name="notes" class="form-control" rows="2"
                                  placeholder="Optional notes..."></textarea>
                    </div>

                    <!-- Extra Charge Toggle (NEW FEATURE) -->
                    <hr>
                    <div class="mb-2">
                        <label class="form-label" style="font-weight:600;">
                            <i class="bi bi-truck me-1 text-warning"></i>
                            Extra Charge (Optional)
                        </label>

                        <!-- Toggle -->
                        <div class="form-check form-switch mb-2">
                            <input class="form-check-input" type="checkbox"
                                   id="extraChargeToggle" onchange="toggleExtraCharge()">
                            <label class="form-check-label" style="font-size:13px;">
                                Add extra charge (transport, etc.)
                            </label>
                        </div>

                        <!-- Extra Charge Fields (hidden by default) -->
                        <div id="extraChargeFields" style="display:none;">
                            <div class="row g-2 mb-2">
                                <div class="col-6">
                                    <input type="text" name="extra_charge_label"
                                           class="form-control form-control-sm"
                                           placeholder="Label (e.g. Transport)"
                                           value="Transportation">
                                </div>
                                <div class="col-6">
                                    <input type="number" name="extra_charge_amount"
                                           id="extraChargeAmount"
                                           class="form-control form-control-sm"
                                           placeholder="Amount ₹"
                                           min="0" step="0.01"
                                           onchange="updateExtraCharge()">
                                </div>
                            </div>

                            <!-- Add as Expense Toggle -->
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox"
                                       name="add_as_expense" value="1" id="addAsExpense">
                                <label class="form-check-label" style="font-size:12px;color:#64748b;">
                                    Also record as <strong>Expense</strong>
                                </label>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

            <!-- Purchase Summary -->
            <div class="card" style="position:sticky;top:90px;">
                <div class="card-header">
                    <i class="bi bi-calculator me-2 text-success"></i>Purchase Summary
                </div>
                <div class="card-body">

                    <div class="d-flex justify-content-between mb-3 pb-3 border-bottom">
                        <span style="font-weight:500;color:var(--dark-3);">Items:</span>
                        <strong id="totalItems">0</strong>
                    </div>

                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h5 class="mb-0">Total Cost:</h5>
                        <h3 class="mb-0" style="color:var(--primary);font-weight:800;" id="grandTotal">
                            ₹0.00
                        </h3>
                    </div>

                    <button type="submit" name="save_purchase"
                            class="btn btn-success w-100 btn-lg"
                            style="border-radius:12px;" id="savePurchaseBtn" disabled>
                        <i class="bi bi-check-circle me-2"></i>Save Purchase
                    </button>

                </div>
            </div>

        </div>

        <!-- Right Column -->
        <div class="col-lg-8">

            <!-- Add Product Card -->
            <div class="card mb-4">
                <div class="card-header">
                    <i class="bi bi-plus-circle me-2 text-primary"></i>Add Product
                </div>
                <div class="card-body">
                    <div class="row g-3">

                        <!-- Select Product -->
                        <div class="col-md-5">
                            <label class="form-label" style="font-weight:600;">Select Product</label>
                            <select id="productSelect" class="form-select">
                                <option value="">-- Choose Product --</option>
                                <?php while ($product = mysqli_fetch_assoc($products_list)) : ?>
                                    <option
                                        value="<?= $product['id'] ?>"
                                        data-name="<?= htmlspecialchars($product['product_name']) ?>"
                                        data-cost="<?= $product['cost_price'] ?>"
                                        data-stock="<?= $product['quantity'] ?>"
                                        data-category="<?= htmlspecialchars($product['category_name']) ?>">
                                        <?= htmlspecialchars($product['product_name']) ?>
                                        (Stock: <?= $product['quantity'] ?>)
                                    </option>
                                <?php endwhile; ?>
                            </select>
                        </div>

                        <!-- Quantity -->
                        <div class="col-md-3">
                            <label class="form-label" style="font-weight:600;">Quantity</label>
                            <input type="number" id="productQty" class="form-control"
                                   placeholder="Qty" min="1" value="1">
                        </div>

                        <!-- Cost Price -->
                        <div class="col-md-2">
                            <label class="form-label" style="font-weight:600;">Cost Price</label>
                            <input type="number" id="productCostPrice" class="form-control"
                                   placeholder="₹" min="0.01" step="0.01">
                        </div>

                        <!-- Add Button -->
                        <div class="col-md-2">
                            <label class="form-label" style="font-weight:600;">&nbsp;</label>
                            <button type="button" class="btn btn-primary w-100"
                                    onclick="addProduct()">
                                <i class="bi bi-plus-lg me-1"></i>Add
                            </button>
                        </div>

                    </div>

                    <!-- Selected Product Info -->
                    <div id="productInfo" class="mt-3" style="display:none;">
                        <div class="alert alert-info mb-0">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <strong id="infoName"></strong>
                                    <br>
                                    <small id="infoCategory" class="text-muted"></small>
                                </div>
                                <div class="text-end">
                                    <small id="infoStock" class="text-muted"></small>
                                    <br>
                                    <small id="infoCost" class="text-muted"></small>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

            <!-- Purchase Items Table -->
            <div class="card">
                <div class="card-header">
                    <i class="bi bi-cart-fill me-2 text-success"></i>Purchase Items
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table mb-0">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Product</th>
                                    <th>Current Stock</th>
                                    <th>Cost Price</th>
                                    <th>Qty</th>
                                    <th>Total Cost</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody id="purchaseItemsBody">
                                <tr id="emptyRow">
                                    <td colspan="7" class="text-center py-5" style="color:#aaa;">
                                        <i class="bi bi-box-seam" style="font-size:50px;"></i>
                                        <p class="mt-3 mb-0">
                                            No items added yet. Add products above.
                                        </p>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>

    </div>

</form>

<!-- Purchase JavaScript -->
<script>
let purchaseItems = [];

// Product Select Change
document.getElementById('productSelect').addEventListener('change', function () {
    const option = this.options[this.selectedIndex];

    if (this.value) {
        document.getElementById('productInfo').style.display = 'block';
        document.getElementById('infoName').textContent = option.dataset.name;
        document.getElementById('infoCategory').textContent = option.dataset.category;
        document.getElementById('infoStock').textContent = 'Current Stock: ' + option.dataset.stock;
        document.getElementById('infoCost').textContent = 'Last Cost Price: ₹' + parseFloat(option.dataset.cost).toFixed(2);

        // Auto-fill cost price
        document.getElementById('productCostPrice').value = option.dataset.cost || '';
    } else {
        document.getElementById('productInfo').style.display = 'none';
    }
});

// Add Product
function addProduct() {
    const select       = document.getElementById('productSelect');
    const qtyInput     = document.getElementById('productQty');
    const costInput    = document.getElementById('productCostPrice');

    if (!select.value) {
        alert('⚠️ Please select a product!');
        return;
    }

    const qty       = parseInt(qtyInput.value);
    const costPrice = parseFloat(costInput.value);

    if (qty < 1) {
        alert('⚠️ Quantity must be at least 1!');
        return;
    }

    if (!costPrice || costPrice <= 0) {
        alert('⚠️ Please enter a valid cost price!');
        return;
    }

    const option    = select.options[select.selectedIndex];
    const productId = parseInt(select.value);

    // Check duplicate
    const existing = purchaseItems.find(item => item.id === productId);
    if (existing) {
        alert('⚠️ Product already added! Remove it first to add again.');
        return;
    }

    const item = {
        id       : productId,
        name     : option.dataset.name,
        stock    : parseInt(option.dataset.stock),
        costPrice: costPrice,
        qty      : qty,
        total    : costPrice * qty
    };

    purchaseItems.push(item);
    renderItems();
    updateSummary();

    // Reset
    select.value = '';
    qtyInput.value = 1;
    costInput.value = '';
    document.getElementById('productInfo').style.display = 'none';
}

// Render Items
function renderItems() {
    const tbody = document.getElementById('purchaseItemsBody');

    if (purchaseItems.length === 0) {
        tbody.innerHTML = `
            <tr id="emptyRow">
                <td colspan="7" class="text-center py-5" style="color:#aaa;">
                    <i class="bi bi-box-seam" style="font-size:50px;"></i>
                    <p class="mt-3 mb-0">No items added yet.</p>
                </td>
            </tr>`;
        return;
    }

    let html = '';
    purchaseItems.forEach((item, index) => {
        html += `
            <tr>
                <td><strong>${index + 1}</strong></td>
                <td>
                    <strong>${item.name}</strong>
                    <input type="hidden" name="products[]" value="${item.id}">
                    <input type="hidden" name="quantities[]" value="${item.qty}">
                    <input type="hidden" name="cost_prices[]" value="${item.costPrice}">
                </td>
                <td>
                    <span class="badge bg-info bg-opacity-10 text-info"
                          style="border-radius:20px;padding:5px 12px;">
                        ${item.stock}
                    </span>
                    →
                    <span class="badge bg-success bg-opacity-10 text-success"
                          style="border-radius:20px;padding:5px 12px;">
                        ${item.stock + item.qty}
                    </span>
                </td>
                <td>₹${item.costPrice.toFixed(2)}</td>
                <td><strong>${item.qty}</strong></td>
                <td><strong style="color:var(--primary);">₹${item.total.toFixed(2)}</strong></td>
                <td>
                    <button type="button" class="btn btn-sm btn-outline-danger"
                            onclick="removeItem(${index})">
                        <i class="bi bi-trash"></i>
                    </button>
                </td>
            </tr>`;
    });

    tbody.innerHTML = html;
}

// Remove Item
function removeItem(index) {
    purchaseItems.splice(index, 1);
    renderItems();
    updateSummary();
}

// Toggle Extra Charge Fields
function toggleExtraCharge() {
    const toggle = document.getElementById('extraChargeToggle');
    const fields = document.getElementById('extraChargeFields');
    fields.style.display = toggle.checked ? 'block' : 'none';
    if (!toggle.checked) {
        document.getElementById('extraChargeAmount').value = '';
        updateExtraCharge();
    }
}

// Update Grand Total with Extra Charge
function updateExtraCharge() {
    const extraAmount = parseFloat(document.getElementById('extraChargeAmount').value) || 0;
    const itemsTotal  = purchaseItems.reduce((sum, item) => sum + item.total, 0);
    const grandTotal  = itemsTotal + extraAmount;
    document.getElementById('grandTotal').textContent = '₹' + grandTotal.toFixed(2);
}

// Update Summary (Consolidated Logic)
function updateSummary() {
    const itemsTotal  = purchaseItems.reduce((sum, item) => sum + item.total, 0);
    const extraAmount = parseFloat(document.getElementById('extraChargeAmount').value) || 0;
    const grandTotal  = itemsTotal + extraAmount;

    document.getElementById('totalItems').textContent    = purchaseItems.length;
    document.getElementById('grandTotal').textContent    = '₹' + grandTotal.toFixed(2);
    document.getElementById('savePurchaseBtn').disabled  = (purchaseItems.length === 0);
}
</script>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>