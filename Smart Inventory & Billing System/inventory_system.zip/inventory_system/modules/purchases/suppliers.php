<?php
// modules/purchases/suppliers.php

$page_title = "Suppliers";

session_start();

require_once __DIR__ . '/../../config/db.php';

// Handle Delete
if (isset($_GET['delete'])) {
    $delete_id = (int) $_GET['delete'];

    $check = mysqli_query($conn, "SELECT COUNT(*) as count FROM purchases WHERE supplier_id = $delete_id");
    $row   = mysqli_fetch_assoc($check);

    if ($row['count'] > 0) {
        $_SESSION['error'] = "❌ Cannot delete! Supplier has {$row['count']} purchase records.";
    } else {
        $delete_query = mysqli_query($conn, "DELETE FROM suppliers WHERE id = $delete_id");
        if ($delete_query) {
            $_SESSION['success'] = "✅ Supplier deleted successfully!";
        } else {
            $_SESSION['error'] = "❌ Failed to delete supplier!";
        }
    }

    header("Location: suppliers.php");
    exit();
}

// Handle Add Supplier
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name    = trim($_POST['name']);
    $phone   = trim($_POST['phone']);
    $email   = trim($_POST['email']);
    $address = trim($_POST['address']);

    if (empty($name) || empty($phone)) {
        $_SESSION['error'] = "⚠️ Name and Phone are required!";
    } else {
        $sql  = "INSERT INTO suppliers (name, phone, email, address) VALUES (?, ?, ?, ?)";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "ssss", $name, $phone, $email, $address);

        if (mysqli_stmt_execute($stmt)) {
            $_SESSION['success'] = "✅ Supplier added successfully!";
        } else {
            $_SESSION['error'] = "❌ Failed to add supplier!";
        }
    }

    header("Location: suppliers.php");
    exit();
}

// Get All Suppliers with purchase stats
$suppliers = mysqli_query($conn,
    "SELECT s.*,
        COUNT(p.id) as total_purchases,
        COALESCE(SUM(p.total_amount), 0) as total_spent
     FROM suppliers s
     LEFT JOIN purchases p ON s.id = p.supplier_id
     GROUP BY s.id
     ORDER BY total_spent DESC"
);

require_once __DIR__ . '/../../includes/header.php';
?>

<!-- ══════════════ SUPPLIERS PAGE ══════════════ -->

<!-- Page Header -->
<div class="d-flex align-items-center justify-content-between mb-4">
    <div>
        <h4 class="mb-1">🚚 Supplier Management</h4>
        <p class="text-muted mb-0" style="font-size:14px;">
            Manage your product suppliers
        </p>
    </div>
    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addSupplierModal">
        <i class="bi bi-plus-circle me-2"></i>Add Supplier
    </button>
</div>

<!-- Alerts -->
<?php if (isset($_SESSION['success'])) : ?>
    <div class="alert alert-success alert-dismissible fade show">
        <?= $_SESSION['success'] ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php unset($_SESSION['success']); ?>
<?php endif; ?>

<?php if (isset($_SESSION['error'])) : ?>
    <div class="alert alert-danger alert-dismissible fade show">
        <?= $_SESSION['error'] ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php unset($_SESSION['error']); ?>
<?php endif; ?>

<!-- Suppliers Table -->
<div class="card">
    <div class="card-header">
        <i class="bi bi-truck me-2 text-primary"></i>All Suppliers (<?= mysqli_num_rows($suppliers) ?>)
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table mb-0">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Supplier Name</th>
                        <th>Phone</th>
                        <th>Email</th>
                        <th>Total Purchases</th>
                        <th>Total Spent</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (mysqli_num_rows($suppliers) > 0) : ?>
                        <?php
                        $sr = 1;
                        mysqli_data_seek($suppliers, 0);
                        while ($supplier = mysqli_fetch_assoc($suppliers)) :
                        ?>
                            <tr>
                                <td><strong><?= $sr++ ?></strong></td>
                                <td>
                                    <div class="d-flex align-items-center gap-2">
                                        <div style="width:38px;height:38px;border-radius:8px;
                                                    background:linear-gradient(135deg,rgba(99,102,241,.15),rgba(139,92,246,.15));
                                                    display:flex;align-items:center;justify-content:center;
                                                    font-weight:700;font-size:15px;color:#6366f1;">
                                            <?= strtoupper(substr($supplier['name'], 0, 1)) ?>
                                        </div>
                                        <strong><?= htmlspecialchars($supplier['name']) ?></strong>
                                    </div>
                                </td>
                                <td>
                                    <i class="bi bi-phone me-1" style="color:#64748b;"></i>
                                    <?= htmlspecialchars($supplier['phone']) ?>
                                </td>
                                <td>
                                    <small><?= !empty($supplier['email']) ? htmlspecialchars($supplier['email']) : '-' ?></small>
                                </td>
                                <td>
                                    <span class="badge bg-primary bg-opacity-10 text-primary"
                                          style="border-radius:20px;padding:6px 14px;font-weight:600;">
                                        <?= $supplier['total_purchases'] ?> orders
                                    </span>
                                </td>
                                <td>
                                    <strong style="color:#6366f1;font-size:15px;">
                                        ₹<?= number_format($supplier['total_spent'], 2) ?>
                                    </strong>
                                </td>
                                <td>
                                    <a href="suppliers.php?delete=<?= $supplier['id'] ?>"
                                       class="btn btn-sm btn-outline-danger"
                                       onclick="return confirm('Delete this supplier?');">
                                        <i class="bi bi-trash"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else : ?>
                        <tr>
                            <td colspan="7" class="text-center py-5" style="color:#aaa;">
                                <i class="bi bi-truck" style="font-size:60px;opacity:.3;"></i>
                                <p class="mt-3 mb-0">No suppliers added yet!</p>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Add Supplier Modal -->
<div class="modal fade" id="addSupplierModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content" style="border-radius:20px;">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="bi bi-truck me-2 text-primary"></i>Add New Supplier
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" action="">
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label" style="font-weight:600;">
                                Supplier Name <span class="text-danger">*</span>
                            </label>
                            <input type="text" name="name" class="form-control"
                                   placeholder="Enter supplier name" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label" style="font-weight:600;">
                                Phone <span class="text-danger">*</span>
                            </label>
                            <input type="tel" name="phone" class="form-control"
                                   placeholder="10-digit phone" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label" style="font-weight:600;">Email</label>
                            <input type="email" name="email" class="form-control"
                                   placeholder="Email address">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label" style="font-weight:600;">Address</label>
                            <input type="text" name="address" class="form-control"
                                   placeholder="Shop address">
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-check-circle me-2"></i>Add Supplier
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>