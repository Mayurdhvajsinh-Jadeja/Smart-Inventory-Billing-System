<?php
// modules/purchases/index.php

$page_title = "Purchase Entry";

session_start();

require_once __DIR__ . '/../../config/db.php';

// Handle Delete
if (isset($_GET['delete'])) {
    $delete_id = (int) $_GET['delete'];

    // Get purchase items to reverse stock
    $items = mysqli_query($conn,
        "SELECT * FROM purchase_items WHERE purchase_id = $delete_id"
    );

    mysqli_begin_transaction($conn);

    try {
        // Reverse stock update
        while ($item = mysqli_fetch_assoc($items)) {
            $qty        = $item['quantity'];
            $product_id = $item['product_id'];
            mysqli_query($conn,
                "UPDATE products SET quantity = quantity - $qty WHERE id = $product_id"
            );
        }

        // Delete purchase items
        mysqli_query($conn, "DELETE FROM purchase_items WHERE purchase_id = $delete_id");

        // Delete purchase
        mysqli_query($conn, "DELETE FROM purchases WHERE id = $delete_id");

        mysqli_commit($conn);
        $_SESSION['success'] = "✅ Purchase entry deleted & stock reversed!";

    } catch (Exception $e) {
        mysqli_rollback($conn);
        $_SESSION['error'] = "❌ Failed to delete purchase!";
    }

    header("Location: index.php");
    exit();
}

// Get Date Range
$date_from = isset($_GET['date_from']) ? $_GET['date_from'] : date('Y-m-01');
$date_to   = isset($_GET['date_to']) ? $_GET['date_to'] : date('Y-m-d');

// Get Purchases
$purchases = mysqli_query($conn,
    "SELECT pu.*, s.name as supplier_name
     FROM purchases pu
     LEFT JOIN suppliers s ON pu.supplier_id = s.id
     WHERE pu.purchase_date BETWEEN '$date_from' AND '$date_to'
     ORDER BY pu.id DESC"
);

$total_purchases = mysqli_num_rows($purchases);

// Get Stats
$stats_query = mysqli_query($conn,
    "SELECT
        COUNT(*) as total_entries,
        COALESCE(SUM(total_amount), 0) as total_invested
     FROM purchases
     WHERE purchase_date BETWEEN '$date_from' AND '$date_to'"
);
$stats = mysqli_fetch_assoc($stats_query);

// Get This Month Stats
$this_month = date('Y-m');
$month_query = mysqli_query($conn,
    "SELECT COALESCE(SUM(total_amount), 0) as month_invested
     FROM purchases
     WHERE DATE_FORMAT(purchase_date, '%Y-%m') = '$this_month'"
);
$month_stats = mysqli_fetch_assoc($month_query);

// Get Total Stock Value
$stock_value_query = mysqli_query($conn,
    "SELECT COALESCE(SUM(cost_price * quantity), 0) as stock_value
     FROM products"
);
$stock_value = mysqli_fetch_assoc($stock_value_query)['stock_value'];

// Include Header
require_once __DIR__ . '/../../includes/header.php';
?>

<!-- ══════════════ PURCHASES PAGE ══════════════ -->

<!-- Page Header -->
<div class="d-flex align-items-center justify-content-between mb-4">
    <div>
        <h4 class="mb-1">📦 Purchase Entry</h4>
        <p class="text-muted mb-0" style="font-size:14px;">
            Record stock purchases & manage supplier transactions
        </p>
    </div>
    <div class="d-flex gap-2">
        <a href="suppliers.php" class="btn btn-outline-primary">
            <i class="bi bi-truck me-2"></i>Manage Suppliers
        </a>
        <a href="create.php" class="btn btn-primary">
            <i class="bi bi-plus-circle me-2"></i>New Purchase
        </a>
    </div>
</div>

<!-- Alerts -->
<?php if (isset($_SESSION['success'])) : ?>
    <div class="alert alert-success alert-dismissible fade show">
        <?= $_SESSION['success'] ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php unset($_SESSION['success']); ?>
<?php endif; ?>

<?php if (isset($_SESSION['error'])) : ?>
    <div class="alert alert-danger alert-dismissible fade show">
        <?= $_SESSION['error'] ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php unset($_SESSION['error']); ?>
<?php endif; ?>

<!-- Stats Cards -->
<div class="row g-4 mb-4">

    <!-- Total Invested (Period) -->
    <div class="col-lg-3 col-md-6">
        <div class="card h-100">
            <div class="card-body">
                <div class="d-flex align-items-center gap-3">
                    <div style="width:60px;height:60px;border-radius:12px;
                                background:linear-gradient(135deg,rgba(99,102,241,.15),rgba(139,92,246,.15));
                                display:flex;align-items:center;justify-content:center;">
                        <i class="bi bi-wallet2" style="font-size:26px;color:#6366f1;"></i>
                    </div>
                    <div>
                        <h4 class="mb-0" style="font-weight:800;font-size:22px;color:#6366f1;">
                            ₹<?= number_format($stats['total_invested'], 0) ?>
                        </h4>
                        <p class="mb-0 text-muted" style="font-size:12px;">Period Investment</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- This Month -->
    <div class="col-lg-3 col-md-6">
        <div class="card h-100">
            <div class="card-body">
                <div class="d-flex align-items-center gap-3">
                    <div style="width:60px;height:60px;border-radius:12px;
                                background:linear-gradient(135deg,rgba(245,158,11,.15),rgba(217,119,6,.15));
                                display:flex;align-items:center;justify-content:center;">
                        <i class="bi bi-calendar3" style="font-size:26px;color:#f59e0b;"></i>
                    </div>
                    <div>
                        <h4 class="mb-0" style="font-weight:800;font-size:22px;color:#f59e0b;">
                            ₹<?= number_format($month_stats['month_invested'], 0) ?>
                        </h4>
                        <p class="mb-0 text-muted" style="font-size:12px;">This Month</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Total Entries -->
    <div class="col-lg-3 col-md-6">
        <div class="card h-100">
            <div class="card-body">
                <div class="d-flex align-items-center gap-3">
                    <div style="width:60px;height:60px;border-radius:12px;
                                background:linear-gradient(135deg,rgba(16,185,129,.15),rgba(6,182,212,.15));
                                display:flex;align-items:center;justify-content:center;">
                        <i class="bi bi-receipt" style="font-size:26px;color:#10b981;"></i>
                    </div>
                    <div>
                        <h4 class="mb-0" style="font-weight:800;font-size:22px;">
                            <?= $stats['total_entries'] ?>
                        </h4>
                        <p class="mb-0 text-muted" style="font-size:12px;">Purchase Entries</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Current Stock Value -->
    <div class="col-lg-3 col-md-6">
        <div class="card h-100">
            <div class="card-body">
                <div class="d-flex align-items-center gap-3">
                    <div style="width:60px;height:60px;border-radius:12px;
                                background:linear-gradient(135deg,rgba(239,68,68,.15),rgba(220,38,38,.15));
                                display:flex;align-items:center;justify-content:center;">
                        <i class="bi bi-box-seam" style="font-size:26px;color:#ef4444;"></i>
                    </div>
                    <div>
                        <h4 class="mb-0" style="font-weight:800;font-size:22px;color:#ef4444;">
                            ₹<?= number_format($stock_value, 0) ?>
                        </h4>
                        <p class="mb-0 text-muted" style="font-size:12px;">Current Stock Value</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>

<!-- Date Filter -->
<div class="card mb-4">
    <div class="card-header">
        <i class="bi bi-calendar-range me-2 text-primary"></i>Filter by Date Range
    </div>
    <div class="card-body">
        <form method="GET" action="">
            <div class="row g-3 align-items-end">
                <div class="col-md-4">
                    <label class="form-label" style="font-weight:600;">From Date</label>
                    <input type="date" name="date_from" class="form-control"
                           value="<?= $date_from ?>" max="<?= date('Y-m-d') ?>">
                </div>
                <div class="col-md-4">
                    <label class="form-label" style="font-weight:600;">To Date</label>
                    <input type="date" name="date_to" class="form-control"
                           value="<?= $date_to ?>" max="<?= date('Y-m-d') ?>">
                </div>
                <div class="col-md-4">
                    <button type="submit" class="btn btn-primary me-2">
                        <i class="bi bi-filter me-1"></i> Apply
                    </button>
                    <a href="index.php" class="btn btn-light">
                        <i class="bi bi-arrow-counterclockwise me-1"></i> Reset
                    </a>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- Purchases Table -->
<div class="card">
    <div class="card-header d-flex align-items-center justify-content-between">
        <span>
            <i class="bi bi-list-check me-2 text-primary"></i>
            All Purchase Entries (<?= $total_purchases ?>)
        </span>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table mb-0">
                <thead>
                    <tr>
                        <th>Purchase ID</th>
                        <th>Supplier</th>
                        <th>Date</th>
                        <th>Items</th>
                        <th>Total Amount</th>
                        <th>Payment</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($total_purchases > 0) : ?>
                        <?php while ($purchase = mysqli_fetch_assoc($purchases)) : 
                            // Get items count for this purchase
                            $items_count = mysqli_fetch_assoc(
                                mysqli_query($conn,
                                    "SELECT COUNT(*) as count FROM purchase_items WHERE purchase_id = " . $purchase['id']
                                )
                            )['count'];
                        ?>
                            <tr>
                                <td>
                                    <strong style="background:linear-gradient(135deg,var(--primary),var(--secondary));
                                                   -webkit-background-clip:text;
                                                   -webkit-text-fill-color:transparent;
                                                   font-size:16px;">
                                        #<?= str_pad($purchase['id'], 4, '0', STR_PAD_LEFT) ?>
                                    </strong>
                                </td>
                                <td>
                                    <div class="d-flex align-items-center gap-2">
                                        <div style="width:36px;height:36px;border-radius:8px;
                                                    background:linear-gradient(135deg,rgba(99,102,241,.15),rgba(139,92,246,.15));
                                                    display:flex;align-items:center;justify-content:center;">
                                            <i class="bi bi-truck" style="color:#6366f1;"></i>
                                        </div>
                                        <strong><?= htmlspecialchars($purchase['supplier_name']) ?></strong>
                                    </div>
                                </td>
                                <td style="color:#64748b;">
                                    <?= date('d M Y', strtotime($purchase['purchase_date'])) ?>
                                </td>
                                <td>
                                    <span class="badge bg-info bg-opacity-10 text-info"
                                          style="border-radius:20px;padding:6px 14px;font-weight:600;">
                                        <?= $items_count ?> items
                                    </span>
                                </td>
                                <td>
                                    <strong style="color:#6366f1;font-size:16px;">
                                        ₹<?= number_format($purchase['total_amount'], 2) ?>
                                    </strong>
                                </td>
                                <td>
                                    <span class="badge bg-success bg-opacity-10 text-success"
                                          style="border-radius:20px;padding:6px 14px;font-weight:600;">
                                        <?= htmlspecialchars($purchase['payment_mode']) ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="d-flex gap-1">
                                        <a href="view.php?id=<?= $purchase['id'] ?>"
                                           class="btn btn-sm btn-outline-primary" title="View">
                                            <i class="bi bi-eye"></i>
                                        </a>
                                        <a href="index.php?delete=<?= $purchase['id'] ?>"
                                           class="btn btn-sm btn-outline-danger"
                                           onclick="return confirm('Delete this purchase? Stock will be reversed!');"
                                           title="Delete">
                                            <i class="bi bi-trash"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else : ?>
                        <tr>
                            <td colspan="7" class="text-center py-5" style="color:#aaa;">
                                <i class="bi bi-box-seam" style="font-size:60px;opacity:.3;"></i>
                                <p class="mt-3 mb-0">No purchase entries found!</p>
                                <a href="create.php" class="btn btn-primary btn-sm mt-3">
                                    <i class="bi bi-plus-circle me-1"></i>Create First Purchase
                                </a>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>