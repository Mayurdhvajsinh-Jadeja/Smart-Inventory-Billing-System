<?php
// modules/purchases/view.php

$page_title = "Purchase Details";

session_start();

require_once __DIR__ . '/../../config/db.php';

$purchase_id = isset($_GET['id']) ? (int) $_GET['id'] : 0;

if ($purchase_id == 0) {
    header("Location: index.php");
    exit();
}

// Get Purchase with Supplier
$purchase = mysqli_fetch_assoc(mysqli_query($conn,
    "SELECT pu.*, s.name as supplier_name, s.phone as supplier_phone, s.email as supplier_email
     FROM purchases pu
     LEFT JOIN suppliers s ON pu.supplier_id = s.id
     WHERE pu.id = $purchase_id"
));

if (!$purchase) {
    $_SESSION['error'] = "❌ Purchase not found!";
    header("Location: index.php");
    exit();
}

// Get Purchase Items
$items = mysqli_query($conn,
    "SELECT pi.*, p.product_name, p.price as selling_price
     FROM purchase_items pi
     LEFT JOIN products p ON pi.product_id = p.id
     WHERE pi.purchase_id = $purchase_id"
);

require_once __DIR__ . '/../../includes/header.php';
?>

<!-- ══════════════ VIEW PURCHASE PAGE ══════════════ -->

<!-- Page Header -->
<div class="d-flex align-items-center justify-content-between mb-4">
    <div>
        <h4 class="mb-1">📦 Purchase Details</h4>
        <p class="text-muted mb-0" style="font-size:14px;">
            View purchase entry & stock update details
        </p>
    </div>
    <div class="d-flex gap-2">
        <button onclick="window.print()" class="btn btn-primary">
            <i class="bi bi-printer me-2"></i>Print
        </button>
        <a href="index.php" class="btn btn-light">
            <i class="bi bi-arrow-left me-2"></i>Back
        </a>
    </div>
</div>

<!-- Purchase Info Cards -->
<div class="row g-4 mb-4">

    <!-- Purchase Info -->
    <div class="col-lg-6">
        <div class="card h-100">
            <div class="card-header">
                <i class="bi bi-receipt me-2 text-primary"></i>Purchase Information
            </div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-6">
                        <p class="mb-1 text-muted" style="font-size:11px;font-weight:700;">PURCHASE ID</p>
                        <h5 class="mb-0" style="font-weight:800;color:#6366f1;">
                            #<?= str_pad($purchase['id'], 4, '0', STR_PAD_LEFT) ?>
                        </h5>
                    </div>
                    <div class="col-6">
                        <p class="mb-1 text-muted" style="font-size:11px;font-weight:700;">PURCHASE DATE</p>
                        <h6 class="mb-0" style="font-weight:700;">
                            <?= date('d M Y', strtotime($purchase['purchase_date'])) ?>
                        </h6>
                    </div>
                    <div class="col-6">
                        <p class="mb-1 text-muted" style="font-size:11px;font-weight:700;">PAYMENT MODE</p>
                        <span class="badge bg-success bg-opacity-10 text-success"
                              style="border-radius:20px;padding:6px 14px;font-weight:600;">
                            <?= htmlspecialchars($purchase['payment_mode']) ?>
                        </span>
                    </div>
                    <div class="col-6">
                        <p class="mb-1 text-muted" style="font-size:11px;font-weight:700;">TOTAL AMOUNT</p>
                        <h4 class="mb-0" style="font-weight:800;color:#6366f1;">
                            ₹<?= number_format($purchase['total_amount'], 2) ?>
                        </h4>
                    </div>
                    <?php if (!empty($purchase['notes'])) : ?>
                        <div class="col-12">
                            <p class="mb-1 text-muted" style="font-size:11px;font-weight:700;">NOTES</p>
                            <p class="mb-0"><?= htmlspecialchars($purchase['notes']) ?></p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Supplier Info -->
    <div class="col-lg-6">
        <div class="card h-100">
            <div class="card-header">
                <i class="bi bi-truck me-2 text-success"></i>Supplier Information
            </div>
            <div class="card-body">
                <div class="d-flex align-items-center gap-3 mb-4">
                    <div style="width:60px;height:60px;border-radius:50%;
                                background:linear-gradient(135deg,#6366f1,#8b5cf6);
                                display:flex;align-items:center;justify-content:center;
                                color:white;font-weight:800;font-size:24px;">
                        <?= strtoupper(substr($purchase['supplier_name'], 0, 1)) ?>
                    </div>
                    <div>
                        <h5 class="mb-0" style="font-weight:700;">
                            <?= htmlspecialchars($purchase['supplier_name']) ?>
                        </h5>
                        <small class="text-muted">Supplier</small>
                    </div>
                </div>
                <div class="row g-3">
                    <div class="col-6">
                        <p class="mb-1 text-muted" style="font-size:11px;font-weight:700;">PHONE</p>
                        <p class="mb-0" style="font-weight:600;">
                            <i class="bi bi-phone me-1" style="color:#6366f1;"></i>
                            <?= htmlspecialchars($purchase['supplier_phone']) ?>
                        </p>
                    </div>
                    <div class="col-6">
                        <p class="mb-1 text-muted" style="font-size:11px;font-weight:700;">EMAIL</p>
                        <p class="mb-0" style="font-weight:600;">
                            <i class="bi bi-envelope me-1" style="color:#6366f1;"></i>
                            <?= !empty($purchase['supplier_email']) ? htmlspecialchars($purchase['supplier_email']) : '-' ?>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>

<!-- Purchase Items -->
<div class="card">
    <div class="card-header">
        <i class="bi bi-box-seam me-2 text-primary"></i>Purchased Items & Stock Updated
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table mb-0">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Product Name</th>
                        <th>Cost Price</th>
                        <th>Selling Price</th>
                        <th>Profit/Unit</th>
                        <th>Qty Purchased</th>
                        <th>Total Cost</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $sr = 1;
                    $grand_total = 0;
                    while ($item = mysqli_fetch_assoc($items)) :
                        $line_total  = $item['quantity'] * $item['cost_price'];
                        $profit_unit = $item['selling_price'] - $item['cost_price'];
                        $grand_total += $line_total;
                    ?>
                        <tr>
                            <td><strong><?= $sr++ ?></strong></td>
                            <td>
                                <i class="bi bi-box me-2" style="color:#6366f1;"></i>
                                <strong><?= htmlspecialchars($item['product_name']) ?></strong>
                            </td>
                            <td style="color:#ef4444;">
                                ₹<?= number_format($item['cost_price'], 2) ?>
                            </td>
                            <td style="color:#10b981;">
                                ₹<?= number_format($item['selling_price'], 2) ?>
                            </td>
                            <td>
                                <strong style="color:<?= $profit_unit >= 0 ? '#10b981' : '#ef4444' ?>;">
                                    ₹<?= number_format($profit_unit, 2) ?>
                                </strong>
                            </td>
                            <td>
                                <strong><?= $item['quantity'] ?></strong>
                            </td>
                            <td>
                                <strong style="color:#6366f1;">
                                    ₹<?= number_format($line_total, 2) ?>
                                </strong>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
                <tfoot>
                    <tr style="background:#f8fafc;">
                        <td colspan="6" class="text-end" style="font-weight:800;font-size:16px;">
                            Grand Total:
                        </td>
                        <td style="font-weight:800;font-size:18px;color:#6366f1;">
                            ₹<?= number_format($purchase['total_amount'], 2) ?>
                        </td>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>