<?php
// modules/reports/financial.php

$page_title = "Financial Report";

$path_to_db = __DIR__ . '/../../config/db.php';
if (file_exists($path_to_db)) {
    require_once $path_to_db;
} else {
    // Fallback path
    require_once $_SERVER['DOCUMENT_ROOT'] . '/inventory_system/config/db.php';
}

// Date Range
$date_from = isset($_GET['date_from']) ? $_GET['date_from'] : date('Y-m-01');
$date_to   = isset($_GET['date_to'])   ? $_GET['date_to']   : date('Y-m-d');

// ── REVENUE ──
$revenue_data = mysqli_fetch_assoc(mysqli_query($conn,
    "SELECT COUNT(*) as bills, COALESCE(SUM(total_amount),0) as revenue
     FROM bills WHERE bill_date BETWEEN '$date_from' AND '$date_to'"
));

// ── COGS ──
$cogs = mysqli_fetch_assoc(mysqli_query($conn,
    "SELECT COALESCE(SUM(bi.quantity * p.cost_price),0) as cogs
     FROM bill_items bi
     LEFT JOIN products p ON bi.product_id = p.id
     LEFT JOIN bills b ON bi.bill_id = b.id
     WHERE b.bill_date BETWEEN '$date_from' AND '$date_to'"
))['cogs'];

// ── PURCHASES ──
$purchase_data = mysqli_fetch_assoc(mysqli_query($conn,
    "SELECT COUNT(*) as entries, COALESCE(SUM(total_amount),0) as total
     FROM purchases WHERE purchase_date BETWEEN '$date_from' AND '$date_to'"
));

// ── EXPENSES ──
$expense_data = mysqli_fetch_assoc(mysqli_query($conn,
    "SELECT COUNT(*) as entries, COALESCE(SUM(amount),0) as total
     FROM expenses WHERE expense_date BETWEEN '$date_from' AND '$date_to'"
));

// ── CALCULATIONS ──
$revenue       = $revenue_data['revenue'];
$gross_profit  = $revenue - $cogs;
$net_profit    = $gross_profit - $expense_data['total'];
$gross_margin  = $revenue > 0 ? ($gross_profit / $revenue) * 100 : 0;
$net_margin    = $revenue > 0 ? ($net_profit   / $revenue) * 100 : 0;

// ── MONTH-BY-MONTH (Last 6 months) ──
$monthly_data = [];
for ($i = 5; $i >= 0; $i--) {
    $month     = date('Y-m', strtotime("-$i months"));
    $month_label = date('M Y', strtotime("-$i months"));

    $m_revenue = mysqli_fetch_assoc(mysqli_query($conn,
        "SELECT COALESCE(SUM(total_amount),0) as t FROM bills WHERE DATE_FORMAT(bill_date,'%Y-%m')='$month'"
    ))['t'];

    $m_cogs = mysqli_fetch_assoc(mysqli_query($conn,
        "SELECT COALESCE(SUM(bi.quantity * p.cost_price),0) as t
         FROM bill_items bi
         LEFT JOIN products p ON bi.product_id = p.id
         LEFT JOIN bills b ON bi.bill_id = b.id
         WHERE DATE_FORMAT(b.bill_date,'%Y-%m')='$month'"
    ))['t'];

    $m_expenses = mysqli_fetch_assoc(mysqli_query($conn,
        "SELECT COALESCE(SUM(amount),0) as t FROM expenses WHERE DATE_FORMAT(expense_date,'%Y-%m')='$month'"
    ))['t'];

    $m_purchases = mysqli_fetch_assoc(mysqli_query($conn,
        "SELECT COALESCE(SUM(total_amount),0) as t FROM purchases WHERE DATE_FORMAT(purchase_date,'%Y-%m')='$month'"
    ))['t'];

    $monthly_data[] = [
        'month'     => $month_label,
        'revenue'   => (float)$m_revenue,
        'cogs'      => (float)$m_cogs,
        'expenses'  => (float)$m_expenses,
        'purchases' => (float)$m_purchases,
        'gross'     => (float)($m_revenue - $m_cogs),
        'net'       => (float)($m_revenue - $m_cogs - $m_expenses),
    ];
}

// ── EXPENSE CATEGORIES ──
$expense_cats = mysqli_query($conn,
    "SELECT category, COALESCE(SUM(amount),0) as total
     FROM expenses WHERE expense_date BETWEEN '$date_from' AND '$date_to'
     GROUP BY category ORDER BY total DESC"
);

// ── TOP SUPPLIERS ──
$top_suppliers = mysqli_query($conn,
    "SELECT s.name, COALESCE(SUM(p.total_amount),0) as total, COUNT(p.id) as orders
     FROM suppliers s
     LEFT JOIN purchases p ON s.id = p.supplier_id
     WHERE p.purchase_date BETWEEN '$date_from' AND '$date_to'
     GROUP BY s.id ORDER BY total DESC LIMIT 5"
);

require_once __DIR__ . '/../../includes/header.php';
?>

<!-- ══════════════ FINANCIAL REPORT PAGE ══════════════ -->

<!-- Page Header -->
<div class="d-flex align-items-center justify-content-between mb-4">
    <div>
        <h4 class="mb-1">📊 Combined Financial Report</h4>
        <p class="text-muted mb-0" style="font-size:14px;">
            Complete financial overview — Revenue, Purchases, Expenses & Profits
        </p>
    </div>
    <div class="d-flex gap-2">
        <button onclick="window.print()" class="btn btn-primary">
            <i class="bi bi-printer me-2"></i>Print Report
        </button>
    </div>
</div>

<!-- Date Filter -->
<div class="card mb-4">
    <div class="card-header">
        <i class="bi bi-calendar-range me-2 text-primary"></i>Select Date Range
    </div>
    <div class="card-body">
        <form method="GET" action="">
            <div class="row g-3 align-items-end">
                <div class="col-md-4">
                    <label class="form-label" style="font-weight:600;">From Date</label>
                    <input type="date" name="date_from" class="form-control"
                           value="<?= $date_from ?>" max="<?= date('Y-m-d') ?>">
                </div>
                <div class="col-md-4">
                    <label class="form-label" style="font-weight:600;">To Date</label>
                    <input type="date" name="date_to" class="form-control"
                           value="<?= $date_to ?>" max="<?= date('Y-m-d') ?>">
                </div>
                <div class="col-md-4">
                    <button type="submit" class="btn btn-primary me-2">
                        <i class="bi bi-filter me-1"></i> Apply
                    </button>
                    <a href="financial.php" class="btn btn-light">
                        <i class="bi bi-arrow-counterclockwise me-1"></i> Reset
                    </a>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- COMPLETE P&L STATEMENT -->
<div class="card mb-4"
     style="background:linear-gradient(135deg,#0f172a,#1e1b4b);color:white;">
    <div class="card-body p-4">
        <h5 class="mb-4" style="font-weight:700;opacity:.9;">
            <i class="bi bi-file-earmark-bar-graph me-2"></i>
            Profit & Loss Statement
            <small style="font-size:13px;opacity:.6;margin-left:10px;">
                <?= date('d M Y', strtotime($date_from)) ?> to
                <?= date('d M Y', strtotime($date_to)) ?>
            </small>
        </h5>

        <div class="row g-4">

            <!-- Left: P&L Table -->
            <div class="col-lg-6">
                <table style="width:100%;color:white;">
                    <tr>
                        <td style="padding:10px 0;font-size:14px;opacity:.8;">
                            <i class="bi bi-plus-circle me-2" style="color:#34d399;"></i>
                            Total Revenue (<?= $revenue_data['bills'] ?> bills)
                        </td>
                        <td style="padding:10px 0;text-align:right;font-weight:700;font-size:16px;color:#34d399;">
                            ₹<?= number_format($revenue, 2) ?>
                        </td>
                    </tr>
                    <tr>
                        <td style="padding:10px 0;font-size:14px;opacity:.8;">
                            <i class="bi bi-dash-circle me-2" style="color:#f87171;"></i>
                            Cost of Goods Sold (COGS)
                        </td>
                        <td style="padding:10px 0;text-align:right;font-weight:700;font-size:16px;color:#f87171;">
                            - ₹<?= number_format($cogs, 2) ?>
                        </td>
                    </tr>
                    <tr style="border-top:1px solid rgba(255,255,255,.2);">
                        <td style="padding:12px 0;font-size:15px;font-weight:700;">
                            = GROSS PROFIT
                        </td>
                        <td style="padding:12px 0;text-align:right;font-weight:800;font-size:20px;
                                   color:<?= $gross_profit >= 0 ? '#34d399' : '#f87171' ?>;">
                            ₹<?= number_format($gross_profit, 2) ?>
                        </td>
                    </tr>
                    <tr>
                        <td style="padding:10px 0;font-size:14px;opacity:.8;">
                            <i class="bi bi-dash-circle me-2" style="color:#fcd34d;"></i>
                            Operating Expenses (<?= $expense_data['entries'] ?> entries)
                        </td>
                        <td style="padding:10px 0;text-align:right;font-weight:700;font-size:16px;color:#fcd34d;">
                            - ₹<?= number_format($expense_data['total'], 2) ?>
                        </td>
                    </tr>
                    <tr style="border-top:2px solid rgba(255,255,255,.3);">
                        <td style="padding:15px 0;font-size:18px;font-weight:800;">
                            <i class="bi bi-trophy me-2" style="color:#fbbf24;"></i>
                            NET PROFIT
                        </td>
                        <td style="padding:15px 0;text-align:right;font-weight:900;font-size:28px;
                                   color:<?= $net_profit >= 0 ? '#34d399' : '#f87171' ?>;">
                            ₹<?= number_format($net_profit, 2) ?>
                        </td>
                    </tr>
                </table>
            </div>

            <!-- Right: Margin Indicators -->
            <div class="col-lg-6">
                <div class="row g-3">

                    <!-- Gross Margin -->
                    <div class="col-6">
                        <div style="background:rgba(255,255,255,.08);padding:20px;border-radius:15px;text-align:center;">
                            <div style="font-size:36px;font-weight:900;
                                        color:<?= $gross_margin >= 30 ? '#34d399' : '#fcd34d' ?>;">
                                <?= number_format($gross_margin, 1) ?>%
                            </div>
                            <div style="font-size:12px;opacity:.7;margin-top:5px;">Gross Margin</div>
                            <div style="font-size:11px;opacity:.5;margin-top:3px;">
                                <?= $gross_margin >= 30 ? '✅ Healthy' : '⚠️ Low' ?>
                            </div>
                        </div>
                    </div>

                    <!-- Net Margin -->
                    <div class="col-6">
                        <div style="background:rgba(255,255,255,.08);padding:20px;border-radius:15px;text-align:center;">
                            <div style="font-size:36px;font-weight:900;
                                        color:<?= $net_margin >= 15 ? '#34d399' : ($net_margin >= 0 ? '#fcd34d' : '#f87171') ?>;">
                                <?= number_format($net_margin, 1) ?>%
                            </div>
                            <div style="font-size:12px;opacity:.7;margin-top:5px;">Net Margin</div>
                            <div style="font-size:11px;opacity:.5;margin-top:3px;">
                                <?= $net_margin >= 15 ? '✅ Excellent' : ($net_margin >= 0 ? '⚠️ Average' : '❌ Loss') ?>
                            </div>
                        </div>
                    </div>

                    <!-- Stock Purchased -->
                    <div class="col-6">
                        <div style="background:rgba(255,255,255,.08);padding:20px;border-radius:15px;text-align:center;">
                            <div style="font-size:22px;font-weight:800;color:#818cf8;">
                                ₹<?= number_format($purchase_data['total'], 0) ?>
                            </div>
                            <div style="font-size:12px;opacity:.7;margin-top:5px;">Stock Purchased</div>
                            <div style="font-size:11px;opacity:.5;margin-top:3px;">
                                <?= $purchase_data['entries'] ?> entries
                            </div>
                        </div>
                    </div>

                    <!-- Total Cash Out -->
                    <div class="col-6">
                        <div style="background:rgba(255,255,255,.08);padding:20px;border-radius:15px;text-align:center;">
                            <div style="font-size:22px;font-weight:800;color:#f87171;">
                                ₹<?= number_format($purchase_data['total'] + $expense_data['total'], 0) ?>
                            </div>
                            <div style="font-size:12px;opacity:.7;margin-top:5px;">Total Cash Out</div>
                            <div style="font-size:11px;opacity:.5;margin-top:3px;">
                                Purchases + Expenses
                            </div>
                        </div>
                    </div>

                </div>
            </div>

        </div>
    </div>
</div>

<!-- Month-by-Month Chart -->
<div class="card mb-4">
    <div class="card-header">
        <i class="bi bi-bar-chart me-2 text-primary"></i>Month-by-Month Comparison (Last 6 Months)
    </div>
    <div class="card-body">
        <div style="position:relative;height:300px;">
            <canvas id="monthlyChart"></canvas>
        </div>
    </div>
</div>

<!-- Monthly Table -->
<div class="card mb-4">
    <div class="card-header">
        <i class="bi bi-table me-2 text-success"></i>Monthly Breakdown
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table mb-0">
                <thead>
                    <tr>
                        <th>Month</th>
                        <th>Revenue</th>
                        <th>Purchases</th>
                        <th>Expenses</th>
                        <th>Gross Profit</th>
                        <th>Net Profit</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($monthly_data as $month) : ?>
                        <tr>
                            <td><strong><?= $month['month'] ?></strong></td>
                            <td style="color:#10b981;font-weight:600;">
                                ₹<?= number_format($month['revenue'], 0) ?>
                            </td>
                            <td style="color:#6366f1;">
                                ₹<?= number_format($month['purchases'], 0) ?>
                            </td>
                            <td style="color:#ef4444;">
                                ₹<?= number_format($month['expenses'], 0) ?>
                            </td>
                            <td>
                                <strong style="color:<?= $month['gross'] >= 0 ? '#10b981' : '#ef4444' ?>;">
                                    ₹<?= number_format($month['gross'], 0) ?>
                                </strong>
                            </td>
                            <td>
                                <strong style="color:<?= $month['net'] >= 0 ? '#10b981' : '#ef4444' ?>;font-size:15px;">
                                    ₹<?= number_format($month['net'], 0) ?>
                                </strong>
                            </td>
                            <td>
                                <?php if ($month['net'] > 0) : ?>
                                    <span class="badge"
                                          style="background:rgba(16,185,129,.1);color:#10b981;
                                                 border-radius:20px;padding:5px 12px;font-weight:600;">
                                        ✅ Profit
                                    </span>
                                <?php elseif ($month['net'] == 0) : ?>
                                    <span class="badge"
                                          style="background:rgba(245,158,11,.1);color:#f59e0b;
                                                 border-radius:20px;padding:5px 12px;font-weight:600;">
                                        ➖ Break-even
                                    </span>
                                <?php else : ?>
                                    <span class="badge"
                                          style="background:rgba(239,68,68,.1);color:#ef4444;
                                                 border-radius:20px;padding:5px 12px;font-weight:600;">
                                        ❌ Loss
                                    </span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Two Column: Expense Cats + Top Suppliers -->
<div class="row g-4">

    <!-- Expense Categories -->
    <div class="col-lg-6">
        <div class="card h-100">
            <div class="card-header">
                <i class="bi bi-pie-chart me-2 text-warning"></i>Expense Categories
            </div>
            <div class="card-body">
                <?php if (mysqli_num_rows($expense_cats) > 0) : ?>
                    <?php while ($cat = mysqli_fetch_assoc($expense_cats)) :
                        $pct = $expense_data['total'] > 0 ? ($cat['total'] / $expense_data['total']) * 100 : 0;
                    ?>
                        <div class="mb-3">
                            <div class="d-flex justify-content-between mb-1">
                                <strong style="font-size:14px;"><?= $cat['category'] ?></strong>
                                <strong style="color:#ef4444;">
                                    ₹<?= number_format($cat['total'], 2) ?>
                                </strong>
                            </div>
                            <div class="progress" style="height:8px;border-radius:10px;">
                                <div class="progress-bar"
                                     style="width:<?= $pct ?>%;background:#ef4444;"></div>
                            </div>
                            <small class="text-muted"><?= number_format($pct, 1) ?>% of total expenses</small>
                        </div>
                    <?php endwhile; ?>
                <?php else : ?>
                    <div class="text-center py-4" style="color:#aaa;">
                        <i class="bi bi-inbox" style="font-size:40px;"></i>
                        <p class="mt-3">No expenses in this period</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Top Suppliers -->
    <div class="col-lg-6">
        <div class="card h-100">
            <div class="card-header">
                <i class="bi bi-truck me-2 text-primary"></i>Top Suppliers
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table mb-0">
                        <thead>
                            <tr>
                                <th>Supplier</th>
                                <th>Orders</th>
                                <th>Total Paid</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (mysqli_num_rows($top_suppliers) > 0) : ?>
                                <?php while ($s = mysqli_fetch_assoc($top_suppliers)) : ?>
                                    <tr>
                                        <td>
                                            <div class="d-flex align-items-center gap-2">
                                                <div style="width:32px;height:32px;border-radius:8px;
                                                            background:linear-gradient(135deg,rgba(99,102,241,.15),rgba(139,92,246,.15));
                                                            display:flex;align-items:center;justify-content:center;
                                                            font-weight:700;font-size:13px;color:#6366f1;">
                                                    <?= strtoupper(substr($s['name'], 0, 1)) ?>
                                                </div>
                                                <strong><?= htmlspecialchars($s['name']) ?></strong>
                                            </div>
                                        </td>
                                        <td>
                                            <span class="badge bg-info bg-opacity-10 text-info"
                                                  style="border-radius:20px;padding:5px 12px;">
                                                <?= $s['orders'] ?>
                                            </span>
                                        </td>
                                        <td>
                                            <strong style="color:#6366f1;">
                                                ₹<?= number_format($s['total'], 2) ?>
                                            </strong>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else : ?>
                                <tr>
                                    <td colspan="3" class="text-center py-4" style="color:#aaa;">
                                        No supplier data available
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

</div>

<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
// Monthly Chart
const monthCtx = document.getElementById('monthlyChart').getContext('2d');
const monthlyData = <?= json_encode($monthly_data) ?>;

new Chart(monthCtx, {
    type: 'bar',
    data: {
        labels: monthlyData.map(d => d.month),
        datasets: [
            {
                label: 'Revenue',
                data: monthlyData.map(d => d.revenue),
                backgroundColor: 'rgba(16,185,129,0.7)',
                borderColor: '#10b981',
                borderWidth: 2,
                borderRadius: 6,
            },
            {
                label: 'Purchases',
                data: monthlyData.map(d => d.purchases),
                backgroundColor: 'rgba(99,102,241,0.7)',
                borderColor: '#6366f1',
                borderWidth: 2,
                borderRadius: 6,
            },
            {
                label: 'Expenses',
                data: monthlyData.map(d => d.expenses),
                backgroundColor: 'rgba(239,68,68,0.7)',
                borderColor: '#ef4444',
                borderWidth: 2,
                borderRadius: 6,
            },
            {
                label: 'Net Profit',
                data: monthlyData.map(d => d.net),
                type: 'line',
                backgroundColor: 'rgba(245,158,11,0.1)',
                borderColor: '#f59e0b',
                borderWidth: 3,
                borderDash: [],
                pointBackgroundColor: '#f59e0b',
                pointRadius: 5,
                tension: 0.4,
                fill: false,
            }
        ]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                position: 'top',
                labels: {
                    font: { size: 12, weight: '600' },
                    padding: 20
                }
            },
            tooltip: {
                callbacks: {
                    label: function(context) {
                        return context.dataset.label + ': ₹' +
                               context.raw.toLocaleString('en-IN');
                    }
                }
            }
        },
        scales: {
            x: { grid: { display: false } },
            y: {
                beginAtZero: true,
                ticks: {
                    callback: v => '₹' + v.toLocaleString('en-IN')
                }
            }
        }
    }
});
</script>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>