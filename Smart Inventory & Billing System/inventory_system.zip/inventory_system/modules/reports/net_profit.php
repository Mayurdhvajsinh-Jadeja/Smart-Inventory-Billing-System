<?php
// modules/reports/net_profit.php
$page_title = "Net Profit Report";
session_start();
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../includes/auth_check.php';
requireAdmin();

$date_from = isset($_GET['date_from']) ? $_GET['date_from'] : date('Y-m-01');
$date_to   = isset($_GET['date_to'])   ? $_GET['date_to']   : date('Y-m-d');

$total_rev = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COALESCE(SUM(total_amount),0) as t FROM bills WHERE bill_date BETWEEN '$date_from' AND '$date_to'"))['t'];
$total_cost= mysqli_fetch_assoc(mysqli_query($conn,"SELECT COALESCE(SUM(bi.quantity*p.cost_price),0) as t FROM bill_items bi LEFT JOIN products p ON bi.product_id=p.id LEFT JOIN bills b ON bi.bill_id=b.id WHERE b.bill_date BETWEEN '$date_from' AND '$date_to'"))['t'];
$total_exp = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COALESCE(SUM(amount),0) as t FROM expenses WHERE expense_date BETWEEN '$date_from' AND '$date_to'"))['t'];
$gross     = $total_rev - $total_cost;
$net       = $gross    - $total_exp;
$net_margin= $total_rev > 0 ? ($net/$total_rev)*100 : 0;

$exp_cats = mysqli_query($conn,"SELECT category,COALESCE(SUM(amount),0) as total FROM expenses WHERE expense_date BETWEEN '$date_from' AND '$date_to' GROUP BY category ORDER BY total DESC");
$exp_arr=[]; $exp_max=1;
while($r=mysqli_fetch_assoc($exp_cats)) $exp_arr[]=$r;
if(count($exp_arr)) $exp_max=max(array_column($exp_arr,'total'));

// Monthly net profit trend (6 months)
$ml=[]; $md=[];
for($i=5;$i>=0;$i--){
    $m=date('Y-m',strtotime("-$i months"));
    $ml[]=date('M',strtotime("-$i months"));
    $mr=mysqli_fetch_assoc(mysqli_query($conn,"SELECT COALESCE(SUM(total_amount),0) as t FROM bills WHERE DATE_FORMAT(bill_date,'%Y-%m')='$m'"))['t'];
    $mc=mysqli_fetch_assoc(mysqli_query($conn,"SELECT COALESCE(SUM(bi.quantity*p.cost_price),0) as t FROM bill_items bi LEFT JOIN products p ON bi.product_id=p.id LEFT JOIN bills b ON bi.bill_id=b.id WHERE DATE_FORMAT(b.bill_date,'%Y-%m')='$m'"))['t'];
    $me=mysqli_fetch_assoc(mysqli_query($conn,"SELECT COALESCE(SUM(amount),0) as t FROM expenses WHERE DATE_FORMAT(expense_date,'%Y-%m')='$m'"))['t'];
    $md[]=(float)($mr-$mc-$me);
}

require_once __DIR__ . '/../../includes/header.php';
?>
<style>
.np-hero{background:linear-gradient(135deg,#0f172a 0%,#1e1b4b 50%,<?=$net>=0?'#064e3b':'#450a0a'?> 100%);border-radius:22px;padding:32px 36px;color:white;margin-bottom:24px;position:relative;overflow:hidden;}
.np-hero::before{content:'';position:absolute;top:-40px;right:-40px;width:180px;height:180px;background:radial-gradient(circle,<?=$net>=0?'rgba(16,185,129,.25)':'rgba(239,68,68,.25)'?> 0%,transparent 70%);}
.np-c{position:relative;z-index:1;}
.flow-card{background:var(--card-bg);border:1px solid var(--border-color);border-radius:16px;padding:20px;text-align:center;position:relative;overflow:hidden;}
.flow-card::before{content:'';position:absolute;top:0;left:0;right:0;height:3px;border-radius:16px 16px 0 0;}
.fc-rev::before {background:linear-gradient(90deg,#10b981,#06b6d4);}
.fc-cost::before{background:linear-gradient(90deg,#6366f1,#8b5cf6);}
.fc-exp::before {background:linear-gradient(90deg,#ef4444,#ec4899);}
.fc-grs::before {background:linear-gradient(90deg,#f59e0b,#f97316);}
.eb-wrap{height:8px;background:var(--border-color);border-radius:99px;overflow:hidden;margin-top:5px;}
.eb-fill{height:100%;border-radius:99px;transition:width 1.2s;}
.arrow-down{display:flex;justify-content:center;align-items:center;padding:4px 0;color:var(--text-muted);font-size:20px;}
.dp-pill{display:inline-flex;align-items:center;gap:6px;padding:6px 14px;border-radius:50px;border:2px solid var(--border-color);font-size:12px;font-weight:600;color:var(--text-muted);text-decoration:none;transition:all .2s;background:var(--card-bg);}
.dp-pill:hover,.dp-pill.active{border-color:#6366f1;color:#4f46e5;background:rgba(99,102,241,.08);}
</style>

<div class="d-flex align-items-center justify-content-between mb-4">
    <div>
        <h4 class="mb-1">🏆 Net Profit Report</h4>
        <p class="text-muted mb-0" style="font-size:14px;"><?=date('d M Y',strtotime($date_from))?> → <?=date('d M Y',strtotime($date_to))?></p>
    </div>
    <a href="<?=$base_url?>/exports/profit_report_pdf.php?date_from=<?=$date_from?>&date_to=<?=$date_to?>" class="btn btn-outline-danger"><i class="bi bi-file-pdf me-1"></i>PDF</a>
</div>

<?php $ranges=[['This Month',date('Y-m-01'),date('Y-m-d')],['Last Month',date('Y-m-01',strtotime('first day of last month')),date('Y-m-t',strtotime('last month'))],['Last 3 Months',date('Y-m-01',strtotime('-2 months')),date('Y-m-d')],['This Year',date('Y-01-01'),date('Y-m-d')]];?>
<div class="d-flex gap-2 flex-wrap mb-4">
    <?php foreach($ranges as [$lbl,$f,$t]):$a=($date_from===$f&&$date_to===$t)?'active':'';?>
    <a href="?date_from=<?=$f?>&date_to=<?=$t?>" class="dp-pill <?=$a?>"><?=$lbl?></a>
    <?php endforeach;?>
</div>

<!-- Net Profit Hero -->
<div class="np-hero">
    <div class="np-c">
        <div style="font-size:11px;font-weight:700;letter-spacing:2px;text-transform:uppercase;opacity:.55;margin-bottom:6px;">Net Profit</div>
        <div style="font-size:48px;font-weight:800;letter-spacing:-2px;color:<?=$net>=0?'#6ee7b7':'#fca5a5'?>;">
            <?=$net>=0?'+':'-'?>₹<?=number_format(abs($net),0)?>
        </div>
        <div style="font-size:14px;opacity:.6;margin-top:4px;">
            Margin: <?=number_format($net_margin,1)?>% · <?=$net>=0?'✅ Profitable period':'⚠️ Loss period'?>
        </div>
        <div class="row g-3 mt-3" style="max-width:500px;">
            <div class="col-4"><div style="background:rgba(255,255,255,.1);border-radius:10px;padding:10px;text-align:center;"><div style="font-size:10px;opacity:.6;font-weight:700;text-transform:uppercase;">Revenue</div><div style="font-size:16px;font-weight:800;color:#6ee7b7;">₹<?=number_format($total_rev,0)?></div></div></div>
            <div class="col-4"><div style="background:rgba(255,255,255,.1);border-radius:10px;padding:10px;text-align:center;"><div style="font-size:10px;opacity:.6;font-weight:700;text-transform:uppercase;">COGS</div><div style="font-size:16px;font-weight:800;color:#93c5fd;">₹<?=number_format($total_cost,0)?></div></div></div>
            <div class="col-4"><div style="background:rgba(255,255,255,.1);border-radius:10px;padding:10px;text-align:center;"><div style="font-size:10px;opacity:.6;font-weight:700;text-transform:uppercase;">Expenses</div><div style="font-size:16px;font-weight:800;color:#fca5a5;">₹<?=number_format($total_exp,0)?></div></div></div>
        </div>
    </div>
</div>

<div class="card mb-4"><div class="card-body">
    <form method="GET" class="row g-3 align-items-end">
        <div class="col-md-4"><label class="form-label">From</label><input type="date" name="date_from" class="form-control" value="<?=$date_from?>"></div>
        <div class="col-md-4"><label class="form-label">To</label><input type="date" name="date_to" class="form-control" value="<?=$date_to?>"></div>
        <div class="col-md-4 d-flex gap-2"><button type="submit" class="btn btn-primary flex-fill"><i class="bi bi-funnel me-1"></i>Filter</button><a href="net_profit.php" class="btn btn-light"><i class="bi bi-x"></i></a></div>
    </form>
</div></div>

<!-- P&L Waterfall -->
<div class="row g-4 mb-4">
    <div class="col-lg-7">
        <div class="card">
            <div class="card-header"><i class="bi bi-bar-chart-steps me-2 text-primary"></i>P&L Waterfall</div>
            <div class="card-body">
                <?php
                $steps=[
                    ['Revenue',     $total_rev,  '#10b981','bi-arrow-up-circle-fill'],
                    ['Cost of Goods',-$total_cost,'#6366f1','bi-box-seam-fill'],
                    ['Gross Profit', $gross,      $gross>=0?'#f59e0b':'#ef4444','bi-calculator-fill'],
                    ['Expenses',    -$total_exp,  '#ef4444','bi-wallet2'],
                    ['Net Profit',   $net,         $net>=0?'#10b981':'#ef4444','bi-trophy-fill'],
                ];
                $max_abs=max(array_map(fn($s)=>abs($s[1]),$steps));
                foreach($steps as $i=>$s):
                    $pct=$max_abs>0?round((abs($s[1])/$max_abs)*80):0;
                    $is_total=($i==2||$i==4);
                ?>
                <div style="display:flex;align-items:center;gap:14px;margin-bottom:<?=$i<count($steps)-1?'14':'0'?>px;">
                    <div style="width:32px;height:32px;border-radius:8px;background:<?=$s[2]?>20;color:<?=$s[2]?>;display:flex;align-items:center;justify-content:center;font-size:14px;flex-shrink:0;"><i class="bi <?=$s[3]?>"></i></div>
                    <div style="flex:1;min-width:0;">
                        <div class="d-flex justify-content-between mb-1">
                            <span style="font-size:13px;font-weight:<?=$is_total?'800':'600'?>;color:var(--text-main);"><?=$s[0]?></span>
                            <span style="font-size:13px;font-weight:800;color:<?=$s[2]?>;"><?=$s[1]>=0?'+':''?>₹<?=number_format(abs($s[1]),0)?></span>
                        </div>
                        <div style="height:<?=$is_total?'10':'7'?>px;background:var(--border-color);border-radius:99px;overflow:hidden;"><div style="height:100%;width:0%;background:<?=$s[2]?>;border-radius:99px;transition:width 1.2s cubic-bezier(.4,0,.2,1);" data-w="<?=$pct?>%"></div></div>
                    </div>
                </div>
                <?php endforeach;?>
            </div>
        </div>
    </div>
    <div class="col-lg-5">
        <div class="card h-100">
            <div class="card-header"><i class="bi bi-pie-chart-fill me-2 text-danger"></i>Expense Breakdown</div>
            <div class="card-body">
                <?php if(count($exp_arr)>0):
                    $ecols=['#ef4444','#f59e0b','#8b5cf6','#06b6d4','#ec4899','#6366f1'];
                    foreach($exp_arr as $ei=>$e):
                        $pct=$exp_max>0?round(($e['total']/$exp_max)*100):0;
                        $col=$ecols[$ei%count($ecols)];
                ?>
                <div style="margin-bottom:12px;">
                    <div class="d-flex justify-content-between mb-1">
                        <span style="font-size:13px;font-weight:600;color:var(--text-main);"><?=htmlspecialchars($e['category'])?></span>
                        <span style="font-size:12px;font-weight:700;color:<?=$col?>;">₹<?=number_format($e['total'],0)?></span>
                    </div>
                    <div class="eb-wrap"><div class="eb-fill" style="width:0%;background:<?=$col?>;" data-w="<?=$pct?>%"></div></div>
                </div>
                <?php endforeach; else:?>
                <div class="text-center py-4 text-muted"><i class="bi bi-wallet2" style="font-size:36px;opacity:.3;"></i><p class="mt-2 mb-0" style="font-size:13px;">No expenses in this period</p></div>
                <?php endif;?>
            </div>
        </div>
    </div>
</div>

<!-- 6-month trend -->
<div class="card">
    <div class="card-header"><i class="bi bi-graph-up me-2 text-success"></i>6-Month Net Profit Trend</div>
    <div class="card-body"><div style="position:relative;height:220px;"><canvas id="netChart"></canvas></div></div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
document.addEventListener('DOMContentLoaded',function(){
    setTimeout(function(){document.querySelectorAll('[data-w]').forEach(function(b){b.style.width=b.getAttribute('data-w');});},200);
    var ctx=document.getElementById('netChart');
    if(ctx){
        var data=<?=json_encode($md)?>;
        new Chart(ctx.getContext('2d'),{type:'bar',data:{labels:<?=json_encode($ml)?>,datasets:[{label:'Net Profit',data:data,backgroundColor:data.map(function(v){return v>=0?'rgba(16,185,129,0.85)':'rgba(239,68,68,0.85)';}),borderColor:data.map(function(v){return v>=0?'#10b981':'#ef4444';}),borderWidth:0,borderRadius:8,borderSkipped:false}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false},tooltip:{callbacks:{label:function(c){return(c.raw>=0?' +':' -')+'₹'+Math.abs(c.raw).toLocaleString('en-IN');}}}},scales:{x:{grid:{display:false},ticks:{font:{size:11}}},y:{beginAtZero:false,grid:{color:'rgba(128,128,128,0.08)'},ticks:{callback:function(v){return'₹'+(v>=1000?(v/1000).toFixed(0)+'k':v);}}}}}});
    }
});
</script>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
