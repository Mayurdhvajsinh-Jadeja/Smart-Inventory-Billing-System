<?php
// modules/reports/profit.php
$page_title = "Profit Analysis";
session_start();
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../includes/auth_check.php';
requireAdmin();

$date_from = isset($_GET['date_from']) ? $_GET['date_from'] : date('Y-m-01');
$date_to   = isset($_GET['date_to'])   ? $_GET['date_to']   : date('Y-m-d');

$sd = mysqli_fetch_assoc(mysqli_query($conn,
    "SELECT COALESCE(SUM(bi.quantity*bi.price),0) as rev, COALESCE(SUM(bi.quantity*p.cost_price),0) as cost
     FROM bill_items bi LEFT JOIN products p ON bi.product_id=p.id LEFT JOIN bills b ON bi.bill_id=b.id
     WHERE b.bill_date BETWEEN '$date_from' AND '$date_to'"));
$total_rev    = $sd['rev'];
$total_cost   = $sd['cost'];
$total_profit = $total_rev - $total_cost;
$margin       = $total_rev > 0 ? ($total_profit / $total_rev) * 100 : 0;

$prod_profit = mysqli_query($conn,
    "SELECT p.product_name,p.cost_price,p.price as sell_price,
     COALESCE(SUM(bi.quantity),0) as sold,
     COALESCE(SUM(bi.quantity*bi.price),0) as rev,
     COALESCE(SUM(bi.quantity*p.cost_price),0) as cost,
     COALESCE(SUM(bi.quantity*(bi.price-p.cost_price)),0) as profit
     FROM products p LEFT JOIN bill_items bi ON p.id=bi.product_id LEFT JOIN bills b ON bi.bill_id=b.id
     WHERE b.bill_date BETWEEN '$date_from' AND '$date_to' GROUP BY p.id HAVING sold>0 ORDER BY profit DESC");
$prod_arr=[]; while($r=mysqli_fetch_assoc($prod_profit)) $prod_arr[]=$r;
$max_profit = count($prod_arr)>0 ? max(array_column($prod_arr,'profit')) : 1;

// Quick ranges
$ranges=[
    ['This Month',date('Y-m-01'),date('Y-m-d')],
    ['Last Month',date('Y-m-01',strtotime('first day of last month')),date('Y-m-t',strtotime('last month'))],
    ['Last 3 Months',date('Y-m-01',strtotime('-2 months')),date('Y-m-d')],
    ['This Year',date('Y-01-01'),date('Y-m-d')],
];

require_once __DIR__ . '/../../includes/header.php';
?>
<style>
.rpt-stat{background:var(--card-bg);border:1px solid var(--border-color);border-radius:16px;padding:22px;height:100%;position:relative;overflow:hidden;}
.rpt-stat::before{content:'';position:absolute;top:0;left:0;right:0;height:3px;border-radius:16px 16px 0 0;}
.rs1::before{background:linear-gradient(90deg,#10b981,#06b6d4);}
.rs2::before{background:linear-gradient(90deg,#6366f1,#8b5cf6);}
.rs3::before{background:linear-gradient(90deg,#f59e0b,#f97316);}
.rs4::before{background:linear-gradient(90deg,#ec4899,#8b5cf6);}
.rs-icon{width:46px;height:46px;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:19px;flex-shrink:0;}
.dp-pill{display:inline-flex;align-items:center;gap:6px;padding:6px 14px;border-radius:50px;border:2px solid var(--border-color);font-size:12px;font-weight:600;color:var(--text-muted);text-decoration:none;transition:all .2s;background:var(--card-bg);}
.dp-pill:hover,.dp-pill.active{border-color:#6366f1;color:#4f46e5;background:rgba(99,102,241,.08);}
.pbar-wrap{height:8px;background:var(--border-color);border-radius:99px;overflow:hidden;margin-top:5px;}
.pbar{height:100%;border-radius:99px;transition:width 1.2s cubic-bezier(.4,0,.2,1);}
</style>

<div class="d-flex align-items-center justify-content-between mb-4">
    <div>
        <h4 class="mb-1">💰 Profit Analysis</h4>
        <p class="text-muted mb-0" style="font-size:14px;"><?=date('d M Y',strtotime($date_from))?> → <?=date('d M Y',strtotime($date_to))?></p>
    </div>
    <a href="<?=$base_url?>/exports/profit_report_pdf.php?date_from=<?=$date_from?>&date_to=<?=$date_to?>" class="btn btn-outline-danger"><i class="bi bi-file-pdf me-1"></i>Export PDF</a>
</div>

<div class="d-flex gap-2 flex-wrap mb-4">
    <?php foreach($ranges as [$lbl,$f,$t]):$a=($date_from===$f&&$date_to===$t)?'active':'';?>
    <a href="?date_from=<?=$f?>&date_to=<?=$t?>" class="dp-pill <?=$a?>"><?=$lbl?></a>
    <?php endforeach;?>
</div>

<div class="card mb-4"><div class="card-body">
    <form method="GET" class="row g-3 align-items-end">
        <div class="col-md-4"><label class="form-label">From</label><input type="date" name="date_from" class="form-control" value="<?=$date_from?>"></div>
        <div class="col-md-4"><label class="form-label">To</label><input type="date" name="date_to" class="form-control" value="<?=$date_to?>"></div>
        <div class="col-md-4 d-flex gap-2"><button type="submit" class="btn btn-primary flex-fill"><i class="bi bi-funnel me-1"></i>Filter</button><a href="profit.php" class="btn btn-light"><i class="bi bi-x"></i></a></div>
    </form>
</div></div>

<div class="row g-4 mb-4">
    <div class="col-lg-3 col-md-6"><div class="rpt-stat rs1">
        <div class="d-flex align-items-center gap-3"><div class="rs-icon" style="background:rgba(16,185,129,.12);color:#10b981;"><i class="bi bi-graph-up-arrow"></i></div><div style="flex:1;"><div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:var(--text-muted);">Total Revenue</div><div style="font-size:24px;font-weight:800;color:var(--text-main);margin-top:4px;">₹<?=number_format($total_rev,0)?></div></div></div>
    </div></div>
    <div class="col-lg-3 col-md-6"><div class="rpt-stat rs2">
        <div class="d-flex align-items-center gap-3"><div class="rs-icon" style="background:rgba(99,102,241,.12);color:#6366f1;"><i class="bi bi-box-seam-fill"></i></div><div><div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:var(--text-muted);">Total Cost</div><div style="font-size:24px;font-weight:800;color:var(--text-main);margin-top:4px;">₹<?=number_format($total_cost,0)?></div></div></div>
    </div></div>
    <div class="col-lg-3 col-md-6"><div class="rpt-stat rs3">
        <div class="d-flex align-items-center gap-3"><div class="rs-icon" style="background:rgba(245,158,11,.12);color:#f59e0b;"><i class="bi bi-trophy-fill"></i></div><div><div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:var(--text-muted);">Gross Profit</div><div style="font-size:24px;font-weight:800;color:<?=$total_profit>=0?'#f59e0b':'#ef4444'?>;margin-top:4px;">₹<?=number_format(abs($total_profit),0)?></div></div></div>
    </div></div>
    <div class="col-lg-3 col-md-6"><div class="rpt-stat rs4">
        <div class="d-flex align-items-center gap-3"><div class="rs-icon" style="background:rgba(236,72,153,.12);color:#ec4899;"><i class="bi bi-percent"></i></div><div><div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:var(--text-muted);">Profit Margin</div><div style="font-size:24px;font-weight:800;color:<?=$margin>=20?'#10b981':'#ef4444'?>;margin-top:4px;"><?=number_format($margin,1)?>%</div></div></div>
    </div></div>
</div>

<div class="card">
    <div class="card-header"><i class="bi bi-bar-chart-fill me-2 text-warning"></i>Product-wise Profit Breakdown</div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table mb-0">
                <thead><tr><th>#</th><th>Product</th><th>Cost</th><th>Sell</th><th>Sold</th><th>Revenue</th><th>Profit</th><th>Margin</th><th>Performance</th></tr></thead>
                <tbody>
                <?php if(count($prod_arr)>0):
                    $cols=['#10b981','#6366f1','#f59e0b','#06b6d4','#8b5cf6','#ec4899','#ef4444'];
                    foreach($prod_arr as $i=>$p):
                        $pm=$p['rev']>0?($p['profit']/$p['rev'])*100:0;
                        $col=$pm>=30?'#10b981':($pm>=15?'#f59e0b':'#ef4444');
                        $bar_w=$max_profit>0?round(($p['profit']/$max_profit)*100):0;
                        $bc=$cols[$i%count($cols)];
                ?>
                <tr>
                    <td><span style="width:26px;height:26px;border-radius:8px;background:<?=$bc?>20;color:<?=$bc?>;display:inline-flex;align-items:center;justify-content:center;font-size:12px;font-weight:800;"><?=$i+1?></span></td>
                    <td style="font-weight:600;font-size:13px;"><?=htmlspecialchars($p['product_name'])?></td>
                    <td style="font-size:12px;color:var(--text-muted);">₹<?=number_format($p['cost_price'],2)?></td>
                    <td style="font-size:12px;color:#10b981;font-weight:600;">₹<?=number_format($p['sell_price'],2)?></td>
                    <td style="font-weight:700;"><?=$p['sold']?></td>
                    <td style="font-weight:600;">₹<?=number_format($p['rev'],0)?></td>
                    <td><strong style="color:<?=$col?>;">₹<?=number_format($p['profit'],0)?></strong></td>
                    <td><span style="font-size:11px;font-weight:700;padding:3px 10px;border-radius:20px;background:<?=$col?>15;color:<?=$col?>;"><?=number_format($pm,1)?>%</span></td>
                    <td style="width:120px;"><div class="pbar-wrap"><div class="pbar" style="width:0%;background:<?=$bc?>;" data-w="<?=$bar_w?>%"></div></div></td>
                </tr>
                <?php endforeach; else:?>
                <tr><td colspan="9" class="text-center py-5 text-muted"><i class="bi bi-bar-chart" style="font-size:40px;opacity:.3;"></i><p class="mt-2 mb-0">No sales in this period</p></td></tr>
                <?php endif;?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<script>document.addEventListener('DOMContentLoaded',function(){setTimeout(function(){document.querySelectorAll('.pbar').forEach(function(b){b.style.width=b.getAttribute('data-w');});},200);});</script>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
