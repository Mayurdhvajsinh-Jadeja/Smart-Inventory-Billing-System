<?php
// modules/reports/index.php
$page_title = "Sales Reports";
session_start();
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../includes/auth_check.php';
requireManager();

$date_from = isset($_GET['date_from']) ? $_GET['date_from'] : date('Y-m-01');
$date_to   = isset($_GET['date_to'])   ? $_GET['date_to']   : date('Y-m-d');

$sales_data = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as total_bills,COALESCE(SUM(total_amount),0) as total_revenue,COALESCE(SUM(paid_amount),0) as total_paid,COALESCE(SUM(due_amount),0) as total_due FROM bills WHERE bill_date BETWEEN '$date_from' AND '$date_to'"));
$prev_from = date('Y-m-d', strtotime($date_from . ' -1 month'));
$prev_to   = date('Y-m-d', strtotime($date_to   . ' -1 month'));
$prev_rev  = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COALESCE(SUM(total_amount),0) as t FROM bills WHERE bill_date BETWEEN '$prev_from' AND '$prev_to'"))['t'];
$growth    = $prev_rev > 0 ? round((($sales_data['total_revenue'] - $prev_rev)/$prev_rev)*100,1) : 0;

$pay_q = mysqli_query($conn,"SELECT payment_mode,COUNT(*) as cnt,COALESCE(SUM(total_amount),0) as total FROM bills WHERE bill_date BETWEEN '$date_from' AND '$date_to' GROUP BY payment_mode ORDER BY total DESC");
$pay_data=[]; while($r=mysqli_fetch_assoc($pay_q)) $pay_data[]=$r;

$top_q = mysqli_query($conn,"SELECT p.product_name,COALESCE(SUM(bi.quantity),0) as qty,COALESCE(SUM(bi.quantity*bi.price),0) as rev FROM bill_items bi LEFT JOIN products p ON bi.product_id=p.id LEFT JOIN bills b ON bi.bill_id=b.id WHERE b.bill_date BETWEEN '$date_from' AND '$date_to' GROUP BY bi.product_id ORDER BY qty DESC LIMIT 8");
$top_prods=[]; $top_max=1; while($r=mysqli_fetch_assoc($top_q)) $top_prods[]=$r;
if(count($top_prods)) $top_max=max(array_column($top_prods,'qty'));

// Daily chart (range period)
$daily_q=mysqli_query($conn,"SELECT DATE(bill_date) as d,COUNT(*) as bills,COALESCE(SUM(total_amount),0) as rev FROM bills WHERE bill_date BETWEEN '$date_from' AND '$date_to' GROUP BY DATE(bill_date) ORDER BY d ASC");
$chart_labels=[]; $chart_data=[];
while($r=mysqli_fetch_assoc($daily_q)){$chart_labels[]=date('d M',strtotime($r['d']));$chart_data[]=(float)$r['rev'];}

$recent = mysqli_query($conn,"SELECT * FROM bills WHERE bill_date BETWEEN '$date_from' AND '$date_to' ORDER BY id DESC LIMIT 10");

require_once __DIR__ . '/../../includes/header.php';
?>
<style>
.rpt-stat{background:var(--card-bg);border:1px solid var(--border-color);border-radius:16px;padding:22px;height:100%;position:relative;overflow:hidden;}
.rpt-stat::before{content:'';position:absolute;top:0;left:0;right:0;height:3px;border-radius:16px 16px 0 0;}
.rs1::before{background:linear-gradient(90deg,#6366f1,#8b5cf6);}
.rs2::before{background:linear-gradient(90deg,#10b981,#06b6d4);}
.rs3::before{background:linear-gradient(90deg,#f59e0b,#f97316);}
.rs4::before{background:linear-gradient(90deg,#ef4444,#ec4899);}
.rs-icon{width:46px;height:46px;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:19px;flex-shrink:0;}
.rs-val{font-size:24px;font-weight:800;color:var(--text-main);line-height:1;margin-top:10px;}
.rs-lbl{font-size:12px;color:var(--text-muted);margin-top:4px;}
.rs-growth{font-size:11px;font-weight:700;padding:2px 8px;border-radius:20px;display:inline-flex;align-items:center;gap:3px;margin-top:6px;}
.pay-card{display:flex;align-items:center;gap:12px;padding:12px 14px;border-radius:12px;background:var(--hover-bg);border:1px solid var(--border-color);margin-bottom:8px;}
.tp-wrap{height:7px;background:var(--border-color);border-radius:99px;overflow:hidden;margin-top:4px;}
.tp-fill{height:100%;border-radius:99px;transition:width 1s cubic-bezier(.4,0,.2,1);}
.dp-pill{display:flex;align-items:center;gap:6px;padding:5px 12px;border-radius:20px;font-size:11px;font-weight:700;cursor:pointer;border:2px solid var(--border-color);background:var(--card-bg);text-decoration:none;color:var(--text-muted);transition:all .2s;}
.dp-pill:hover,.dp-pill.active{border-color:#6366f1;color:#4f46e5;background:rgba(99,102,241,.08);}
</style>

<!-- Header -->
<div class="d-flex align-items-center justify-content-between mb-4">
    <div>
        <h4 class="mb-1">📊 Sales Reports</h4>
        <p class="text-muted mb-0" style="font-size:14px;"><?=date('d M Y',strtotime($date_from))?> → <?=date('d M Y',strtotime($date_to))?></p>
    </div>
    <div class="d-flex gap-2">
        <a href="<?=$base_url?>/exports/sales_report_pdf.php?date_from=<?=$date_from?>&date_to=<?=$date_to?>" class="btn btn-outline-danger"><i class="bi bi-file-pdf me-1"></i>PDF</a>
        <a href="<?=$base_url?>/exports/bills_excel.php" class="btn btn-outline-success"><i class="bi bi-file-excel me-1"></i>Excel</a>
    </div>
</div>

<!-- Quick date range pills -->
<div class="d-flex gap-2 flex-wrap mb-4">
    <?php
    $ranges=[
        ['Today',date('Y-m-d'),date('Y-m-d')],
        ['This Week',date('Y-m-d',strtotime('monday this week')),date('Y-m-d')],
        ['This Month',date('Y-m-01'),date('Y-m-d')],
        ['Last Month',date('Y-m-01',strtotime('first day of last month')),date('Y-m-t',strtotime('last month'))],
        ['Last 3 Months',date('Y-m-01',strtotime('-2 months')),date('Y-m-d')],
        ['This Year',date('Y-01-01'),date('Y-m-d')],
    ];
    foreach($ranges as [$lbl,$f,$t]):
        $active=($date_from===$f&&$date_to===$t)?'active':'';
    ?>
    <a href="?date_from=<?=$f?>&date_to=<?=$t?>" class="dp-pill <?=$active?>"><?=$lbl?></a>
    <?php endforeach;?>
</div>

<!-- Custom filter -->
<div class="card mb-4">
    <div class="card-body">
        <form method="GET" class="row g-3 align-items-end">
            <div class="col-md-4"><label class="form-label">From Date</label><input type="date" name="date_from" class="form-control" value="<?=$date_from?>"></div>
            <div class="col-md-4"><label class="form-label">To Date</label><input type="date" name="date_to" class="form-control" value="<?=$date_to?>"></div>
            <div class="col-md-4 d-flex gap-2"><button type="submit" class="btn btn-primary flex-fill"><i class="bi bi-funnel me-1"></i>Filter</button><a href="index.php" class="btn btn-light"><i class="bi bi-x"></i></a></div>
        </form>
    </div>
</div>

<!-- Stat cards -->
<div class="row g-4 mb-4">
    <div class="col-lg-3 col-md-6"><div class="rpt-stat rs1">
        <div class="d-flex align-items-center justify-content-between">
            <div class="rs-icon" style="background:rgba(99,102,241,.12);color:#6366f1;"><i class="bi bi-receipt-cutoff"></i></div>
            <span class="rs-growth" style="background:rgba(99,102,241,.1);color:#4f46e5;"><?=$sales_data['total_bills']?> bills</span>
        </div>
        <div class="rs-val">₹<?=number_format($sales_data['total_revenue'],0)?></div>
        <div class="rs-lbl">Total Revenue</div>
        <div class="rs-growth" style="background:<?=$growth>=0?'rgba(16,185,129,.1)':'rgba(239,68,68,.1)';?>;color:<?=$growth>=0?'#059669':'#dc2626'?>;">
            <i class="bi bi-arrow-<?=$growth>=0?'up':'down'?>"></i> <?=abs($growth)?>% vs prev period
        </div>
    </div></div>
    <div class="col-lg-3 col-md-6"><div class="rpt-stat rs2">
        <div class="rs-icon" style="background:rgba(16,185,129,.12);color:#10b981;"><i class="bi bi-check-circle-fill"></i></div>
        <div class="rs-val">₹<?=number_format($sales_data['total_paid'],0)?></div>
        <div class="rs-lbl">Amount Collected</div>
    </div></div>
    <div class="col-lg-3 col-md-6"><div class="rpt-stat rs3">
        <div class="rs-icon" style="background:rgba(245,158,11,.12);color:#f59e0b;"><i class="bi bi-clock-history"></i></div>
        <div class="rs-val">₹<?=number_format($sales_data['total_due'],0)?></div>
        <div class="rs-lbl">Pending Due</div>
    </div></div>
    <div class="col-lg-3 col-md-6"><div class="rpt-stat rs4">
        <div class="rs-icon" style="background:rgba(239,68,68,.12);color:#ef4444;"><i class="bi bi-receipt"></i></div>
        <div class="rs-val"><?=$sales_data['total_bills']?></div>
        <div class="rs-lbl">Total Bills</div>
        <div class="rs-lbl" style="margin-top:2px;">Avg: ₹<?=$sales_data['total_bills']>0?number_format($sales_data['total_revenue']/$sales_data['total_bills'],0):0?>/bill</div>
    </div></div>
</div>

<div class="row g-4 mb-4">
    <!-- Sales trend chart -->
    <div class="col-lg-8">
        <div class="card h-100">
            <div class="card-header"><i class="bi bi-bar-chart-fill me-2 text-primary"></i>Daily Sales</div>
            <div class="card-body">
                <?php if(count($chart_labels)>0):?>
                <div style="position:relative;height:260px;"><canvas id="salesChart"></canvas></div>
                <?php else:?>
                <div class="text-center py-5 text-muted"><i class="bi bi-bar-chart" style="font-size:40px;opacity:.3;"></i><p class="mt-2 mb-0">No sales in this period</p></div>
                <?php endif;?>
            </div>
        </div>
    </div>

    <!-- Payment mode breakdown -->
    <div class="col-lg-4">
        <div class="card h-100">
            <div class="card-header"><i class="bi bi-credit-card-2-front-fill me-2 text-success"></i>Payment Methods</div>
            <div class="card-body">
                <?php
                $pay_icons=['Cash'=>'bi-cash-coin','UPI'=>'bi-phone-fill','Card'=>'bi-credit-card-fill','Online'=>'bi-globe'];
                $pay_cols=['#10b981','#6366f1','#f59e0b','#06b6d4'];
                $pay_total=array_sum(array_column($pay_data,'total'));
                if(count($pay_data)>0):
                    foreach($pay_data as $pi=>$pm):
                        $pct=$pay_total>0?round(($pm['total']/$pay_total)*100):0;
                        $col=$pay_cols[$pi%count($pay_cols)];
                        $icon=$pay_icons[$pm['payment_mode']]??'bi-cash';
                ?>
                <div class="pay-card">
                    <div style="width:38px;height:38px;border-radius:10px;background:<?=$col?>20;color:<?=$col?>;display:flex;align-items:center;justify-content:center;font-size:16px;flex-shrink:0;"><i class="bi <?=$icon?>"></i></div>
                    <div style="flex:1;min-width:0;">
                        <div class="d-flex justify-content-between mb-1">
                            <span style="font-size:13px;font-weight:600;color:var(--text-main);"><?=$pm['payment_mode']?></span>
                            <span style="font-size:12px;font-weight:700;color:<?=$col?>;"><?=$pct?>%</span>
                        </div>
                        <div class="tp-wrap"><div class="tp-fill" style="width:0%;background:<?=$col?>;" data-w="<?=$pct?>%"></div></div>
                        <div style="font-size:11px;color:var(--text-muted);margin-top:2px;"><?=$pm['cnt']?> bills · ₹<?=number_format($pm['total'],0)?></div>
                    </div>
                </div>
                <?php endforeach; else:?>
                <div class="text-center py-4 text-muted"><p class="mb-0" style="font-size:13px;">No data in this period</p></div>
                <?php endif;?>
            </div>
        </div>
    </div>
</div>

<!-- Top products -->
<div class="card mb-4">
    <div class="card-header"><i class="bi bi-trophy-fill me-2 text-warning"></i>Top Selling Products</div>
    <div class="card-body">
        <?php
        $tp_cols=['#6366f1','#10b981','#f59e0b','#ef4444','#06b6d4','#8b5cf6','#ec4899','#f97316'];
        if(count($top_prods)>0):?>
        <div class="row g-3">
        <?php foreach($top_prods as $ti=>$tp):
            $pct=$top_max>0?round(($tp['qty']/$top_max)*100):0;
            $col=$tp_cols[$ti%count($tp_cols)];
        ?>
        <div class="col-lg-6">
            <div style="display:flex;align-items:center;gap:10px;padding:10px;border-radius:12px;background:var(--hover-bg);">
                <div style="width:32px;height:32px;border-radius:8px;background:<?=$col?>20;color:<?=$col?>;display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:800;flex-shrink:0;"><?=$ti+1?></div>
                <div style="flex:1;min-width:0;">
                    <div class="d-flex justify-content-between">
                        <span style="font-size:13px;font-weight:600;color:var(--text-main);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:180px;"><?=htmlspecialchars($tp['product_name'])?></span>
                        <span style="font-size:12px;font-weight:700;color:<?=$col?>;flex-shrink:0;margin-left:8px;"><?=$tp['qty']?> sold</span>
                    </div>
                    <div class="tp-wrap" style="margin-top:5px;"><div class="tp-fill" style="width:0%;background:<?=$col?>;" data-w="<?=$pct?>%"></div></div>
                    <div style="font-size:11px;color:var(--text-muted);margin-top:2px;">₹<?=number_format($tp['rev'],0)?> revenue</div>
                </div>
            </div>
        </div>
        <?php endforeach;?>
        </div>
        <?php else:?>
        <div class="text-center py-4 text-muted"><i class="bi bi-bar-chart" style="font-size:36px;opacity:.3;"></i><p class="mt-2 mb-0">No sales data in this period</p></div>
        <?php endif;?>
    </div>
</div>

<!-- Recent bills -->
<div class="card">
    <div class="card-header"><i class="bi bi-list-check me-2 text-primary"></i>Bills in Period (latest 10)</div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table mb-0">
                <thead><tr><th>Bill</th><th>Customer</th><th>Total</th><th>Status</th><th>Payment</th><th>Date</th><th></th></tr></thead>
                <tbody>
                <?php $av=['#6366f1','#10b981','#f59e0b','#ef4444','#06b6d4','#8b5cf6','#ec4899'];$i=0;
                if($recent&&mysqli_num_rows($recent)>0):
                    while($b=mysqli_fetch_assoc($recent)):$col=$av[$i%7];$i++;
                        $sc=$b['status']==='Paid'?'background:#d1fae5;color:#065f46;':($b['status']==='Partial'?'background:#fef3c7;color:#92400e;':'background:#fee2e2;color:#991b1b;');
                ?>
                <tr>
                    <td><strong style="color:#6366f1;">#<?=str_pad($b['id'],4,'0',STR_PAD_LEFT)?></strong></td>
                    <td><div class="d-flex align-items-center gap-2">
                        <div style="width:30px;height:30px;border-radius:8px;background:<?=$col?>22;color:<?=$col?>;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:12px;"><?=strtoupper(substr($b['customer_name'],0,1))?></div>
                        <span style="font-size:13px;font-weight:600;"><?=htmlspecialchars($b['customer_name'])?></span>
                    </div></td>
                    <td><strong>₹<?=number_format($b['total_amount'],0)?></strong></td>
                    <td><span style="font-size:11px;font-weight:700;padding:3px 10px;border-radius:20px;<?=$sc?>"><?=$b['status']?></span></td>
                    <td style="font-size:12px;color:var(--text-muted);"><?=$b['payment_mode']?></td>
                    <td style="font-size:12px;color:var(--text-muted);"><?=date('d M Y',strtotime($b['bill_date']))?></td>
                    <td><a href="<?=$base_url?>/modules/billing/view.php?id=<?=$b['id']?>" class="btn btn-sm btn-outline-primary"><i class="bi bi-eye"></i></a></td>
                </tr>
                <?php endwhile; else:?>
                <tr><td colspan="7" class="text-center py-4 text-muted">No bills in this period</td></tr>
                <?php endif;?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
document.addEventListener('DOMContentLoaded',function(){
    setTimeout(function(){document.querySelectorAll('.tp-fill').forEach(function(b){b.style.width=b.getAttribute('data-w');});},200);
    var ctx=document.getElementById('salesChart');
    if(ctx){
        new Chart(ctx.getContext('2d'),{
            type:'bar',
            data:{labels:<?=json_encode($chart_labels)?>,datasets:[{label:'Revenue',data:<?=json_encode($chart_data)?>,backgroundColor:'rgba(99,102,241,0.85)',borderColor:'#6366f1',borderWidth:0,borderRadius:6,borderSkipped:false}]},
            options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false},tooltip:{callbacks:{label:function(c){return' ₹'+c.raw.toLocaleString('en-IN');}}}},scales:{x:{grid:{display:false},ticks:{font:{size:11},maxTicksLimit:15}},y:{beginAtZero:true,grid:{color:'rgba(128,128,128,0.08)'},ticks:{callback:function(v){return'₹'+(v>=1000?(v/1000).toFixed(0)+'k':v);}}}}}
        });
    }
});
</script>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
