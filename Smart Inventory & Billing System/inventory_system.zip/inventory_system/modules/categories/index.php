<?php
// modules/categories/index.php

$page_title = "Categories";

session_start();
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../includes/auth_check.php';

// ── Handle Delete ──────────────────────────────────────
if (isset($_GET['delete'])) {
    $delete_id = (int)$_GET['delete'];
    $check     = mysqli_query($conn, "SELECT COUNT(*) as c FROM products WHERE category_id = $delete_id");
    $row       = mysqli_fetch_assoc($check);

    if ($row['c'] > 0) {
        $_SESSION['error'] = "❌ Cannot delete! This category has " . $row['c'] . " product(s). Move them first.";
    } else {
        if (mysqli_query($conn, "DELETE FROM categories WHERE id = $delete_id")) {
            $_SESSION['success'] = "✅ Category deleted successfully!";
        } else {
            $_SESSION['error'] = "❌ Failed to delete category!";
        }
    }
    header("Location: index.php"); exit();
}

// ── Handle Edit ────────────────────────────────────────
if (isset($_POST['action']) && $_POST['action'] === 'edit') {
    $edit_id   = (int)$_POST['edit_id'];
    $edit_name = trim($_POST['edit_name']);

    if (empty($edit_name)) {
        $_SESSION['error'] = "⚠️ Category name cannot be empty!";
    } else {
        $dup = mysqli_prepare($conn, "SELECT id FROM categories WHERE category_name = ? AND id != ?");
        mysqli_stmt_bind_param($dup, "si", $edit_name, $edit_id);
        mysqli_stmt_execute($dup);
        if (mysqli_num_rows(mysqli_stmt_get_result($dup)) > 0) {
            $_SESSION['error'] = "⚠️ Category '$edit_name' already exists!";
        } else {
            $upd = mysqli_prepare($conn, "UPDATE categories SET category_name = ? WHERE id = ?");
            mysqli_stmt_bind_param($upd, "si", $edit_name, $edit_id);
            if (mysqli_stmt_execute($upd)) {
                $_SESSION['success'] = "✅ Category renamed to '$edit_name'!";
            } else {
                $_SESSION['error'] = "❌ Failed to update category!";
            }
        }
    }
    header("Location: index.php"); exit();
}

// ── Handle Add ─────────────────────────────────────────
if (isset($_POST['action']) && $_POST['action'] === 'add') {
    $category_name = trim($_POST['category_name']);

    if (empty($category_name)) {
        $_SESSION['error'] = "⚠️ Category name is required!";
    } else {
        $chk = mysqli_prepare($conn, "SELECT id FROM categories WHERE category_name = ?");
        mysqli_stmt_bind_param($chk, "s", $category_name);
        mysqli_stmt_execute($chk);
        if (mysqli_num_rows(mysqli_stmt_get_result($chk)) > 0) {
            $_SESSION['error'] = "⚠️ Category '$category_name' already exists!";
        } else {
            $ins = mysqli_prepare($conn, "INSERT INTO categories (category_name) VALUES (?)");
            mysqli_stmt_bind_param($ins, "s", $category_name);
            if (mysqli_stmt_execute($ins)) {
                $_SESSION['success'] = "✅ Category '$category_name' added successfully!";
            } else {
                $_SESSION['error'] = "❌ Failed to add category!";
            }
        }
    }
    header("Location: index.php"); exit();
}

// ── Fetch all categories with product count ────────────
$categories_result = mysqli_query($conn,
    "SELECT c.*, COUNT(p.id) as product_count
     FROM categories c
     LEFT JOIN products p ON c.id = p.category_id
     GROUP BY c.id
     ORDER BY c.category_name ASC"
);
$categories = [];
while ($row = mysqli_fetch_assoc($categories_result)) {
    $categories[] = $row;
}
$total = count($categories);

// Color palette cycling for category cards
$card_colors = [
    ['bg' => 'rgba(99,102,241,0.1)',  'icon' => '#6366f1', 'border' => '#6366f1'],
    ['bg' => 'rgba(16,185,129,0.1)',  'icon' => '#10b981', 'border' => '#10b981'],
    ['bg' => 'rgba(245,158,11,0.1)',  'icon' => '#f59e0b', 'border' => '#f59e0b'],
    ['bg' => 'rgba(239,68,68,0.1)',   'icon' => '#ef4444', 'border' => '#ef4444'],
    ['bg' => 'rgba(6,182,212,0.1)',   'icon' => '#06b6d4', 'border' => '#06b6d4'],
    ['bg' => 'rgba(236,72,153,0.1)',  'icon' => '#ec4899', 'border' => '#ec4899'],
    ['bg' => 'rgba(139,92,246,0.1)',  'icon' => '#8b5cf6', 'border' => '#8b5cf6'],
];

require_once __DIR__ . '/../../includes/header.php';
?>

<!-- Page Header -->
<div class="d-flex align-items-center justify-content-between mb-4">
    <div>
        <h4 class="mb-1">📂 Categories</h4>
        <p class="text-muted mb-0" style="font-size:14px;">
            <?= $total ?> categories · Organise your products
        </p>
    </div>
    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addCategoryModal">
        <i class="bi bi-plus-circle me-2"></i>Add Category
    </button>
</div>

<!-- ── Category Cards Grid ───────────────────────────── -->
<?php if ($total > 0) : ?>
<div class="row g-4 mb-4">
    <?php foreach ($categories as $i => $cat) :
        $clr = $card_colors[$i % count($card_colors)];
    ?>
    <div class="col-xl-3 col-lg-4 col-md-6">
        <div class="card h-100 category-card" style="border-top: 3px solid <?= $clr['border'] ?>; transition: all 0.3s ease;">
            <div class="card-body">

                <!-- Icon + Name -->
                <div class="d-flex align-items-center gap-3 mb-3">
                    <div style="width:48px;height:48px;border-radius:12px;
                                background:<?= $clr['bg'] ?>;
                                display:flex;align-items:center;justify-content:center;
                                flex-shrink:0;">
                        <i class="bi bi-tags-fill" style="font-size:22px;color:<?= $clr['icon'] ?>;"></i>
                    </div>
                    <div class="flex-grow-1 min-w-0">
                        <!-- Display mode -->
                        <div class="cat-display-<?= $cat['id'] ?>">
                            <h6 class="mb-0 fw-700" style="font-size:15px; word-break:break-word;">
                                <?= htmlspecialchars($cat['category_name']) ?>
                            </h6>
                            <small class="text-muted">
                                Added <?= date('d M Y', strtotime($cat['created_at'])) ?>
                            </small>
                        </div>
                        <!-- Edit mode (hidden by default) -->
                        <div class="cat-edit-<?= $cat['id'] ?>" style="display:none;">
                            <form method="POST" action="">
                                <input type="hidden" name="action"  value="edit">
                                <input type="hidden" name="edit_id" value="<?= $cat['id'] ?>">
                                <div class="input-group input-group-sm">
                                    <input type="text" name="edit_name" class="form-control"
                                           value="<?= htmlspecialchars($cat['category_name']) ?>"
                                           id="editInput<?= $cat['id'] ?>" required>
                                    <button type="submit" class="btn btn-success btn-sm px-2">
                                        <i class="bi bi-check-lg"></i>
                                    </button>
                                    <button type="button" class="btn btn-light btn-sm px-2"
                                            onclick="cancelEdit(<?= $cat['id'] ?>)">
                                        <i class="bi bi-x-lg"></i>
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- Product Count Badge -->
                <a href="<?= $base_url ?>/modules/products/index.php?category=<?= $cat['id'] ?>"
                   class="d-flex align-items-center justify-content-between p-2 rounded mb-3 text-decoration-none"
                   style="background:<?= $clr['bg'] ?>; border:1px solid <?= $clr['border'] ?>22;">
                    <span style="font-size:13px; color:<?= $clr['icon'] ?>; font-weight:600;">
                        <i class="bi bi-box-seam me-1"></i>View Products
                    </span>
                    <span class="fw-bold" style="color:<?= $clr['icon'] ?>; font-size:18px;">
                        <?= $cat['product_count'] ?>
                    </span>
                </a>

                <!-- Action Buttons -->
                <div class="d-flex gap-2">
                    <button class="btn btn-sm btn-outline-primary flex-fill"
                            onclick="startEdit(<?= $cat['id'] ?>)">
                        <i class="bi bi-pencil me-1"></i>Rename
                    </button>
                    <?php if ($cat['product_count'] == 0) : ?>
                        <a href="index.php?delete=<?= $cat['id'] ?>"
                           class="btn btn-sm btn-outline-danger"
                           onclick="return confirm('Delete \'<?= htmlspecialchars($cat['category_name']) ?>\'?')">
                            <i class="bi bi-trash"></i>
                        </a>
                    <?php else : ?>
                        <button class="btn btn-sm btn-outline-secondary" disabled
                                title="Move products before deleting">
                            <i class="bi bi-trash"></i>
                        </button>
                    <?php endif; ?>
                </div>

            </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<?php else : ?>
<!-- Empty State -->
<div class="card">
    <div class="card-body text-center py-5">
        <i class="bi bi-tags" style="font-size:60px; color:#cbd5e1;"></i>
        <h5 class="mt-3 mb-2" style="color:var(--text-muted);">No categories yet</h5>
        <p class="text-muted mb-4">Add your first category to start organising products.</p>
        <button class="btn btn-primary px-4" data-bs-toggle="modal" data-bs-target="#addCategoryModal">
            <i class="bi bi-plus-circle me-2"></i>Add First Category
        </button>
    </div>
</div>
<?php endif; ?>

<!-- ── Summary Row ───────────────────────────────────── -->
<?php if ($total > 0) :
    $total_products_q = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as t FROM products"));
    $empty_cats       = array_filter($categories, fn($c) => $c['product_count'] == 0);
?>
<div class="row g-4">
    <div class="col-md-4">
        <div class="card text-center">
            <div class="card-body py-4">
                <div style="font-size:32px; font-weight:800; color:var(--primary);"><?= $total ?></div>
                <div class="text-muted" style="font-size:13px;">Total Categories</div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card text-center">
            <div class="card-body py-4">
                <div style="font-size:32px; font-weight:800; color:var(--success);"><?= $total_products_q['t'] ?></div>
                <div class="text-muted" style="font-size:13px;">Total Products</div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card text-center">
            <div class="card-body py-4">
                <div style="font-size:32px; font-weight:800; color:<?= count($empty_cats) > 0 ? 'var(--warning)' : 'var(--success)' ?>;">
                    <?= count($empty_cats) ?>
                </div>
                <div class="text-muted" style="font-size:13px;">Empty Categories</div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- ── Add Category Modal ───────────────────────────── -->
<div class="modal fade" id="addCategoryModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="bi bi-plus-circle me-2 text-primary"></i>Add New Category
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" action="">
                <input type="hidden" name="action" value="add">
                <div class="modal-body">
                    <label class="form-label">Category Name <span class="text-danger">*</span></label>
                    <input type="text" name="category_name" class="form-control"
                           placeholder="e.g. Groceries, Beverages, Snacks..."
                           required autofocus id="addCategoryInput">
                    <div class="mt-3 p-3 rounded" style="background:var(--hover-bg); font-size:13px; color:var(--text-muted);">
                        <i class="bi bi-lightbulb me-1 text-warning"></i>
                        Categories help you organise products and filter reports by type.
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-check-circle me-2"></i>Add Category
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<style>
.category-card:hover {
    transform: translateY(-4px);
    box-shadow: var(--shadow-md);
}
</style>

<script>
function startEdit(id) {
    document.querySelector('.cat-display-' + id).style.display = 'none';
    document.querySelector('.cat-edit-'    + id).style.display = 'block';
    const inp = document.getElementById('editInput' + id);
    if (inp) { inp.focus(); inp.select(); }
}

function cancelEdit(id) {
    document.querySelector('.cat-display-' + id).style.display = 'block';
    document.querySelector('.cat-edit-'    + id).style.display = 'none';
}

// Clear modal input when closed
document.getElementById('addCategoryModal').addEventListener('hidden.bs.modal', function() {
    document.getElementById('addCategoryInput').value = '';
});
</script>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
