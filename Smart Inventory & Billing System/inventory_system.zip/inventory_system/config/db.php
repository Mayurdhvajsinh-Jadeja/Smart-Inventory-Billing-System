<?php
// config/db.php

$host     = "localhost";
$username = "root";
$password = "";
$database = "inventory_billing_db";

// Create Connection
$conn = mysqli_connect($host, $username, $password, $database);

// Check Connection
if (!$conn) {
    die("Database Connection Failed: " . mysqli_connect_error());
}

// Set Character Set
mysqli_set_charset($conn, "utf8");

// ── ADD THIS LINE (Base URL) ──
$base_url = "/inventory_system";
?>